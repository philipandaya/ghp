<?php
/* Silence is tranquility for the soul. */
?>