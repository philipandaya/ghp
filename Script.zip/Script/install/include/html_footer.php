<?php

$footer	= 
'
                </div>

				<div id="space-foot" class="centered">
					<span style="color:#888;">
						<span>Powered by<br></span>
						<a href="https://www.mcodedeveloper.com" target="_blank" style="color:#666;">MCode Developer</a> &middot; 
						<a href="https://codecanyon.net/user/mcodedeveloper?ref=mcodedeveloper" target="_blank" style="color:#666;">On Codecanyon</a>
					</span> 
				</div>

        
            </div>
        
        </div>
        
	</body>
</html>';

?>