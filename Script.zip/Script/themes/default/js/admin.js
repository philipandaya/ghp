/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

_IN_ADMIN_PANEL = true;
_SPACE_FULL = true;

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

function updateGeneralSystem_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateGeneralSystem_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralSystem(diverror, divok, bsubmit) {
    "use strict";
    
	$(bsubmit).attr('disabled','true');

    var name_site = validationInput('empty', '#namesite', diverror, txt_error_name_site, bsubmit, true);
    if (!name_site) return;


    var scompany = validationInput('empty', '#scompany', diverror, txt_error_company, bsubmit, true);
    if (!scompany) return;

    var sstatus = validationInput('zeroandpositive', '#sstatus', diverror, txt_error_option, bsubmit, true);
    if (!sstatus) return;

    var sprivacy = validationInput('zeroandpositive', '#wprivacy', diverror, txt_error_option, bsubmit, true);
    if (!sprivacy) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        sst: sstatus,
        spr: sprivacy,
        scny: scompany,
        nams: name_site,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'system',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralSystem_Ok, updateGeneralSystem_Error);

}

/******************************************************/

function updateGeneralSEO_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateGeneralSEO_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralSEO(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var skeywords = validationInput('empty', '#skeywords', diverror, txt_error_keyword, bsubmit, true);
    if (!skeywords) return;

    var sdescription = validationInput('empty', '#sdescription', diverror, txt_error_description, bsubmit, true);
    if (!sdescription) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        sky: skeywords,
        sdsc: sdescription,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'seo',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralSEO_Ok, updateGeneralSEO_Error);

}

/******************************************************/

function updateTheme_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateTheme_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateTheme(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var thetheme = validationInput('empty', '#thetheme', diverror, txt_error_option, bsubmit, true);
    if (!thetheme) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        them: thetheme,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'theme',
            cancelable: 0,
            data: data
    };

    invoke(params, updateTheme_Ok, updateTheme_Error);

}

/******************************************************/

function updateLanguage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateLanguage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateLanguage(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var thelang = validationInput('empty', '#thelang', diverror, txt_error_option, bsubmit, true);
    if (!thelang) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        lang: thelang,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'language',
            cancelable: 0,
            data: data
    };

    invoke(params, updateLanguage_Ok, updateLanguage_Error);

}

/******************************************************/

function createCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/pages/categories', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function createCategoryPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createCategoryPage(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        ncat: namecat,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, createCategoryPage_Ok, createCategoryPage_Error);

}

/******************************************************/

function deleteCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryPage_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryPage(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletecatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryPage_Ok, deleteCategoryPage_Error);

}

/******************************************************/

function updateCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryPage(idcategory) {
    "use strict";
    diverror = '#msgerrorcat' + idcategory;
    bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatecatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryPage_Ok, updateCategoryPage_Error);

}

/******************************************************/

function createSubCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/pages/subcategories/c:' + paramsArray[3], 'dashboard-main-area-right', 'min');
            break;
    }
}

function createSubCategoryPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createSubCategoryPage(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;

    var idc= $('#idc').val();
    
	paramsArray[0] = diverror;
	paramsArray[1] = divok;
	paramsArray[2] = bsubmit;
	paramsArray[3] = idc;

    var data = {
        ncat: namecat,
        idc : idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addsubcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, createSubCategoryPage_Ok, createSubCategoryPage_Error);

}

/******************************************************/

function deleteSubCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryPage_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryPage(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletesubcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryPage_Ok, deleteSubCategoryPage_Error);

}

/******************************************************/

function updateSubCategoryPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryPage(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
	paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatesubcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryPage_Ok, updateSubCategoryPage_Error);

}

/******************************************************/

function createCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/products/categories', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function createCategoryProduct_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createCategoryProduct(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        ncat: namecat,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, createCategoryProduct_Ok, createCategoryProduct_Error);

}

/******************************************************/

function deleteCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryProduct_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryProduct(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletecatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryProduct_Ok, deleteCategoryProduct_Error);

}

/******************************************************/

function updateCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryProduct_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryProduct(idcategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idcategory;
    var bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatecatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryProduct_Ok, updateCategoryProduct_Error);

}

/******************************************************/

function createSubCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/products/subcategories/c:' + paramsArray[3], 'dashboard-main-area-right', 'min');
            break;
    }
}

function createSubCategoryProduct_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createSubCategoryProduct(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;

    var idc= $('#idc').val();
    
	paramsArray[0] = diverror;
	paramsArray[1] = divok;
	paramsArray[2] = bsubmit;
	paramsArray[3] = idc;

    var data = {
        ncat: namecat,
        idc : idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addsubcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, createSubCategoryProduct_Ok, createSubCategoryProduct_Error);

}

/******************************************************/

function deleteSubCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryProduct_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryProduct(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletesubcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryProduct_Ok, deleteSubCategoryProduct_Error);

}

/******************************************************/

function updateSubCategoryProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryProduct_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryProduct(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
	paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatesubcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryProduct_Ok, updateSubCategoryProduct_Error);

}

/******************************************************/

function createCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/articles/categories', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function createCategoryArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createCategoryArticle(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        ncat: namecat,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, createCategoryArticle_Ok, createCategoryArticle_Error);

}

/******************************************************/

function deleteCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryArticle_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryArticle(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletecatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryArticle_Ok, deleteCategoryArticle_Error);

}

/******************************************************/

function updateCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryArticle(idcategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idcategory;
    var bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatecatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryArticle_Ok, updateCategoryArticle_Error);

}

/******************************************************/

function createSubCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/articles/subcategories/c:' + paramsArray[3], 'dashboard-main-area-right', 'min');
            break;
    }
}

function createSubCategoryArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createSubCategoryArticle(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecat = validationInput('empty', '#namecat', diverror, txt_error_name, bsubmit, true);
    if (!namecat) return;

    var idc= $('#idc').val();
    
	paramsArray[0] = diverror;
	paramsArray[1] = divok;
	paramsArray[2] = bsubmit;
	paramsArray[3] = idc;

    var data = {
        ncat: namecat,
        idc : idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addsubcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, createSubCategoryArticle_Ok, createSubCategoryArticle_Error);

}

/******************************************************/

function deleteSubCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryArticle_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryArticle(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletesubcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryArticle_Ok, deleteSubCategoryArticle_Error);

}

/******************************************************/

function updateSubCategoryArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryArticle(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
	paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatesubcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryArticle_Ok, updateSubCategoryArticle_Error);

}

/******************************************************/

function deleteUser_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#user-' + paramsArray[0]).fadeOut(500, function() { $('#user-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteUser_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteUser(codeuser) {
    "use strict";
    paramsArray[0] = codeuser;
    
    var data = {
        cu: codeuser,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deleteuser',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteUser_Ok, deleteUser_Error);

}

/******************************************************/

function updateUserGeneral_Ok(response) {
    "use strict";
   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
   }
}

function updateUserGeneral_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserGeneral(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var verify = validationInput('zeroandpositive', '#verify', diverror, txt_error_option, bsubmit, true);
    if (!verify) return;

    var status = validationInput('zeroandpositive', '#status', diverror, txt_error_option, bsubmit, true);
    if (!status) return;

    var level = validationInput('zeroandpositive', '#level', diverror, txt_error_option, bsubmit, true);
    if (!level) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ver: verify,
        sta: status,
        lev: level,
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'usergeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserGeneral_Ok, updateUserGeneral_Error);

}

/******************************************************/

function updateUserProfile_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserProfile_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserProfile(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var firstname = validationInput('empty', '#firstname', diverror, txt_error_firstname, bsubmit, true);
    if (!firstname) return;

    var lastname = validationInput('empty', '#lastname', diverror, txt_error_lastname, bsubmit, true);
    if (!lastname) return;

    var  gender = validationInput('positive', '#gender', diverror, txt_error_sex, bsubmit, true);
    if (!gender) return;

	var day = $('#day').val();
	var month = $('#month').val();	
	var year = $('#year').val();
	if (day == 0 || month == 0 || year == 0) {
		openandclose(diverror, txt_error_birthday, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

	var xday = day;
	var xmonth = month;
	if (day<10) xday='0' + day;
	if (month<10) xmonth='0' + month;
	var caddate = xday + '/' + xmonth + '/' + year;
	if (!validateDate(caddate)) {
		openandclose(diverror, txt_error_birthday2, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

    var currentcity = validationInput('empty', '#currentcity', diverror, txt_error_currentcity, bsubmit, true);
    if (!currentcity) return;

    var hometown = validationInput('empty', '#hometown', diverror, txt_error_hometown, bsubmit, true);
    if (!hometown) return;
        
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        fn: firstname,
        ln: lastname,
        ge: gender,
        bi: year + '-' + xmonth + '-' + xday,
        cc: currentcity,
        ht: hometown,
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'userprofile',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserProfile_Ok, updateUserProfile_Error);

}

/******************************************************/

function updateUserEmail_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserEmail_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserEmail(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var email = validationInput('email', '#email', diverror, txt_error_email, bsubmit, true);
    if (!email) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        em: email,
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'useremail',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserEmail_Ok, updateUserEmail_Error);

}

/******************************************************/

function updateUserUsername_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserUsername_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserUsername(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var username = validationInput('empty', '#theusername', diverror, txt_error_username, bsubmit, true);
    if (!username) return;

    var username = validationInput('username', '#theusername', diverror, txt_error_notvalid, bsubmit, true);
    if (!username) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        un: username,
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'userusername',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserUsername_Ok, updateUserUsername_Error);

}

/******************************************************/

function updateUserPassword_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#password').val('');
            $('#password').focus();
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserPassword_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserPassword(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pnew = validationInput('password', '#password', diverror, txt_error_pnew, bsubmit, true);
    if (!pnew) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        pn: '' + CryptoJS.SHA256(pnew) + '',
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'userpassword',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserPassword_Ok, updateUserPassword_Error);

}

/******************************************************/

function updateUserPrivacy_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserPrivacy_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserPrivacy(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pprofile = validationInput('number', '#pprofile', diverror, txt_error_option, bsubmit, false);
    if (!pprofile) return;

    var pwritewall = validationInput('number', '#pwritewall', diverror, txt_error_option, bsubmit, false);
    if (!pwritewall) return;

    var pseefriends = validationInput('number', '#pseefriends', diverror, txt_error_option, bsubmit, false);
    if (!pseefriends) return;

    var pseepages = validationInput('number', '#pseepages', diverror, txt_error_option, bsubmit, false);
    if (!pseepages) return;

    var pseegroups = validationInput('number', '#pseegroups', diverror, txt_error_option, bsubmit, false);
    if (!pseegroups) return;

    var pmessages = validationInput('number', '#pmessages', diverror, txt_error_option, bsubmit, false);
    if (!pmessages) return;

    var pbirthday = validationInput('number', '#pbirthday', diverror, txt_error_option, bsubmit, false);
    if (!pbirthday) return;

    var plocation = validationInput('number', '#plocation', diverror, txt_error_option, bsubmit, false);
    if (!plocation) return;

    var paboutme = validationInput('number', '#paboutme', diverror, txt_error_option, bsubmit, false);
    if (!paboutme) return;

    var pchat = validationInput('number', '#pchat', diverror, txt_error_option, bsubmit, false);
    if (!pchat) return;    

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ppro: pprofile,
        pwri: pwritewall,
        psfr: pseefriends,
        pspa: pseepages,
        psgr: pseegroups,
        pmes: pmessages,
        pbir: pbirthday,
        ploc: plocation,
        pabo: paboutme,
        pcha: pchat,
        cdu: codus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'userprivacy',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserPrivacy_Ok, updateUserPrivacy_Error);

}


/******************************************************/

function deletePage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#page-' + paramsArray[0]).fadeOut(500, function() { $('#page-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deletePage_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deletePage(codepage) {
    "use strict";
    paramsArray[0] = codepage;
    
    var data = {
        cpage: codepage,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletepage',
            cancelable: 0,
            data: data
    };

    invoke(params, deletePage_Ok, deletePage_Error);

}


/******************************************************/

function updatePageGeneral_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePageGeneral_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePageGeneral(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var verify = validationInput('zeroandpositive', '#verify', diverror, txt_error_option, bsubmit, true);
    if (!verify) return;

	var idcategory = validationInput('positive', '#categorypage', diverror, txt_choose_category, bsubmit, true);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategorypage', diverror, txt_choose_subcategory, bsubmit, true);
	if (!idsubcategory) return;

	var titlepage = validationInput('empty', '#titlepage', diverror, txt_enter_title, bsubmit, true);
	if (!titlepage) return;

	var urlpage = validationInput('empty', '#urlpage', diverror, txt_enter_url, bsubmit, true);
	if (!urlpage) return;

	var urlpage = validationInput('pageorgroup', '#urlpage', diverror, txt_url_invalid, bsubmit, true);
	if (!urlpage) return;

	var descriptionpage = validationInput('empty', '#descriptionpage', diverror, txt_enter_description, bsubmit, true);
	if (!descriptionpage) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ver: verify,
        pic: idcategory,
        pisc: idsubcategory,
        pti: titlepage,
        pur: urlpage,
        pds: descriptionpage,
        cdp: cdp,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatepagesgeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updatePageGeneral_Ok, updatePageGeneral_Error);

}


/******************************************************/

function deleteGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#group-' + paramsArray[0]).fadeOut(500, function() { $('#group-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteGroup_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteGroup(cdgroup) {
    "use strict";
    paramsArray[0] = cdgroup;
    
    var data = {
        cdgroup: cdgroup,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletegroup',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteGroup_Ok, deleteGroup_Error);

}

/******************************************************/

function updateGroupGeneral_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGroupGeneral_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGroupGeneral(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var titlegroup = validationInput('empty', '#titlegroup', diverror, txt_enter_title, bsubmit, true);
	if (!titlegroup) return;

	var urlgroup = validationInput('empty', '#urlgroup', diverror, txt_enter_url, bsubmit, true);
	if (!urlgroup) return;

	var urlgroup = validationInput('pageorgroup', '#urlgroup', diverror, txt_url_invalid, bsubmit, true);
	if (!urlgroup) return;

	var descriptiongroup = validationInput('empty', '#descriptiongroup', diverror, txt_enter_description, bsubmit, true);
	if (!descriptiongroup) return;

    var privacygroup = $('#privacygroup').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        gti: titlegroup,
        gur: urlgroup,
        gds: descriptiongroup,
        gpr: privacygroup,
        cdg: cdg,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updategroupsgeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGroupGeneral_Ok, updateGroupGeneral_Error);

}

/******************************************************/

function createStaticPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/static-pages', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createStaticPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createStaticPage(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var urlstatic = validationInput('url_static', '#urlstatic', diverror, txt_error_url, bsubmit, true);
    if (!urlstatic) return;

    var titlestatic = validationInput('empty', '#titlestatic', diverror, txt_error_title, bsubmit, true);
    if (!titlestatic) return;

    var htmlstatic = validationInput('empty', '#htmlstatic', diverror, txt_error_html, bsubmit, true);
    if (!htmlstatic) return;

    var infootstatic = $('#infootstatic').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        us: urlstatic,
        ts: titlestatic,
        hs: htmlstatic,
        ifs : infootstatic,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addstaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, createStaticPage_Ok, createStaticPage_Error);

}

/******************************************************/

function updateStaticPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateStaticPage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateStaticPage(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var urlstatic = validationInput('url_static', '#urlstatic', diverror, txt_error_url, bsubmit, true);
    if (!urlstatic) return;

    var titlestatic = validationInput('empty', '#titlestatic', diverror, txt_error_title, bsubmit, true);
    if (!titlestatic) return;

    var htmlstatic = validationInput('empty', '#htmlstatic', diverror, txt_error_html, bsubmit, true);
    if (!htmlstatic) return;

    var infootstatic = $('#infootstatic').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        csp: code_staticpage,
        us: urlstatic,
        ts: titlestatic,
        hs: htmlstatic,
        ifs : infootstatic,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatestaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateStaticPage_Ok, updateStaticPage_Error);

}

/******************************************************/

function deleteStaticPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#static-' + paramsArray[0]).fadeOut(500, function() { $('#static-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteStaticPage_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteStaticPage(cdsp) {
    "use strict";
    paramsArray[0] = cdsp;
    
    var data = {
        cdsp: cdsp,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletestaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteStaticPage_Ok, deleteStaticPage_Error);

}

/******************************************************/

function createCurrency_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/currencies', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function createCurrency_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createCurrency(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecurrency = validationInput('empty', '#namecurrency', diverror, txt_error_name, bsubmit, true);
    if (!namecurrency) return;

    var codecurrency = validationInput('empty', '#codecurrency', diverror, txt_error_code, bsubmit, true);
    if (!codecurrency) return;

    var symbolcurrency = validationInput('empty', '#symbolcurrency', diverror, txt_error_symbol, bsubmit, true);
    if (!symbolcurrency) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        namec: namecurrency,
        codec: codecurrency,
        symbc: symbolcurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'addcurrency',
            cancelable: 0,
            data: data
    };

    invoke(params, createCurrency_Ok, createCurrency_Error);

}

/******************************************************/

function deleteCurrency_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#onecurrency-' + paramsArray[0]).fadeOut(500, function() { $('#onecurrency-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteCurrency_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteCurrency(idc) {
    "use strict";
    paramsArray[0] = idc;
    
    var data = {
        idc: idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletecurrency',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCurrency_Ok, deleteCurrency_Error);

}

/******************************************************/

function updateCurrency_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/currencies', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function updateCurrency_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCurrency(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecurrency = validationInput('empty', '#namecurrency', diverror, txt_error_name, bsubmit, true);
    if (!namecurrency) return;

    var codecurrency = validationInput('empty', '#codecurrency', diverror, txt_error_code, bsubmit, true);
    if (!codecurrency) return;

    var symbolcurrency = validationInput('empty', '#symbolcurrency', diverror, txt_error_symbol, bsubmit, true);
    if (!symbolcurrency) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        idc: idc,
        namec: namecurrency,
        codec: codecurrency,
        symbc: symbolcurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatecurrency',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCurrency_Ok, updateCurrency_Error);

}

/******************************************************/

function createAds_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            if (paramsArray[2] == 1) actionOnClick(_SITE_URL + 'admin/ads/dashboard', 'dashboard-main-area-right', 'min');
            else actionOnClick(_SITE_URL + 'admin/ads/profile', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createAds_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createAds(diverror, divok, bsubmit, slot) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = slot;
    
	var nameads = validationInput('empty', '#nameads', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;
    
    var thefile = $('#imagenfile').val();
    if (thefile != '') {
        var ext = thefile.split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            openandclose(diverror, txt_error_formatimage, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    } else {
        openandclose(diverror, txt_error_image, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

	var urlads = validationInput('url', '#urlads', diverror, txt_error_url, bsubmit, false);
	if (!urlads) return;
    
	var target = validationInput('zeroandpositive', '#target', diverror, txt_error_target, bsubmit, false);
	if (!target) return;


    var formData = new FormData(document.getElementById("form1"));
    formData.append("namea", nameads);
    formData.append("urla", urlads);
    formData.append("tara", target);
    formData.append("slot", slot);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'admin',
            action: 'createads',
            cancelable: 0,
            data: formData
    }

    invoke(params, createAds_Ok, createAds_Error);

}

/******************************************************/

function deleteAds_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#oneads-' + paramsArray[0]).fadeOut(500, function() { $('#oneads-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteAds_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteAds(codead) {
    "use strict";
	paramsArray[0] = codead;

    var data = {
        codad: codead,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deleteads',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteAds_Ok, deleteAds_Error);

}

/******************************************************/

function updateAds_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateAds_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateAds(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var nameads = validationInput('empty', '#nameads', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;
    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') {
    
        thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_formatimage, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_image, 1700);
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    }

	var urlads = validationInput('url', '#urlads', diverror, txt_error_url, bsubmit, false);
	if (!urlads) return;
    
	var target = validationInput('zeroandpositive', '#target', diverror, txt_error_target, bsubmit, false);
	if (!target) return;
    
	var status = validationInput('zeroandpositive', '#status', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var formData = new FormData(document.getElementById("form1"));
    formData.append("namea", nameads);
    formData.append("urla", urlads);
    formData.append("tara", target);
    formData.append("slot", slot);
    formData.append("idads", idads);
    formData.append("status", status);
    formData.append("chgi", changeimg);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'admin',
            action: 'updateads',
            cancelable: 0,
            data: formData
    }

    invoke(params, updateAds_Ok, updateAds_Error);

}

/******************************************************/

function createGame_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/games', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createGame_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createGame(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var namegame = validationInput('empty', '#namegame', diverror, txt_error_name, bsubmit, false);
	if (!namegame) return;
    
	var urlgame = validationInput('url', '#urlgame', diverror, txt_error_url_game, bsubmit, false);
	if (!urlgame) return;
    
	var urlowner = validationInput('url', '#urlowner', diverror, txt_error_url_owner, bsubmit, false);
	if (!urlowner) return;
    
    var thefile = $('#imagenfile').val();
    if (thefile != '') {
        var ext = thefile.split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            openandclose(diverror, txt_error_thumbnail_format, 1700);
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    } else {
        openandclose(diverror, txt_error_thumbnail, 1700);
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

    var formData = new FormData(document.getElementById("form1"));
    formData.append("nameg", namegame);
    formData.append("urlgm", urlgame);
    formData.append("urlow", urlowner);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'admin',
            action: 'creategame',
            cancelable: 0,
            data: formData
    }

    invoke(params, createGame_Ok, createGame_Error);

}

/******************************************************/

function deleteGame_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#onegame-' + paramsArray[0]).fadeOut(500, function() { $('#onegame-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;            
    }
}

function deleteGame_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteGame(cdgam) {
    "use strict";
	paramsArray[0] = cdgam;

    var data = {
        cdgam: cdgam,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletegame',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteGame_Ok, deleteGame_Error);

}

/******************************************************/

function updateGame_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
        
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGame_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateGame(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var namegame = validationInput('empty', '#namegame', diverror, txt_error_name, bsubmit, false);
	if (!namegame) return;
    
	var urlgame = validationInput('url', '#urlgame', diverror, txt_error_url_game, bsubmit, false);
	if (!urlgame) return;
    
	var urlowner = validationInput('url', '#urlowner', diverror, txt_error_url_owner, bsubmit, false);
	if (!urlowner) return;
    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') {
    
        var thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_thumbnail_format, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_thumbnail, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    }

	var status = validationInput('zeroandpositive', '#status', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var formData = new FormData(document.getElementById("form1"));
    formData.append("nameg", namegame);
    formData.append("urlgm", urlgame);
    formData.append("urlow", urlowner);
    formData.append("cdgam", codegame);
    formData.append("status", status);
    formData.append("chgi", changeimg);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'admin',
            action: 'updategame',
            cancelable: 0,
            data: formData
    }

    invoke(params, updateGame_Ok, updateGame_Error);

}

/******************************************************/

function updateTimezone_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateTimezone_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateTimezone(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var timezone = validationInput('empty', '#timezone', diverror, txt_error_option, bsubmit, true);
    if (!timezone) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        timez: timezone,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'timezone',
            cancelable: 0,
            data: data
    };

    invoke(params, updateTimezone_Ok, updateTimezone_Error);

}

/******************************************************/

function updateProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateProduct_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateProduct(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var nameproduct = validationInput('empty', '#nameproduct', diverror, txt_error_name, bsubmit, false);
	if (!nameproduct) return;

	var descriptionproduct = validationInput('empty', '#descriptionproduct', diverror, txt_error_description, bsubmit, false);
	if (!descriptionproduct) return;

	var idcategory = validationInput('positive', '#categoryproduct', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryproduct', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;
    
	var typeproduct = validationInput('positive', '#typeproduct', diverror, txt_error_type, bsubmit, false);
	if (!typeproduct) return;

	var currencyproduct = validationInput('positive', '#currencyproduct', diverror, txt_error_currency, bsubmit, false);
	if (!currencyproduct) return;
    
	var priceproduct = validationInput('numberpositive', '#priceproduct', diverror, txt_error_price, bsubmit, false);
	if (!priceproduct) return;
    
	var locationproduct = validationInput('empty', '#locationproduct', diverror, txt_error_location, bsubmit, false);
	if (!locationproduct) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        cdpr: codeproduct,
        namp: nameproduct,
        desp: descriptionproduct,
        idcp: idcategory,
        idsp: idsubcategory,
        typp: typeproduct,
        curp: currencyproduct,
        prip: priceproduct,
        locp: locationproduct,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updateproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateProduct_Ok, updateProduct_Error);

}

/******************************************************/

function deleteProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#product-' + paramsArray[0]).fadeOut(500, function() { $('#product-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;            
    }
}

function deleteProduct_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteProduct(codeproduct) {
    "use strict";    
    paramsArray[0] = codeproduct;
    
    var data = {
        cdp: codeproduct,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deleteproduct',
            cancelable: 0,
            data: data
    }

    invoke(params, deleteProduct_Ok, deleteProduct_Error);

}

/******************************************************/


function updateArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateArticle(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var titlearticle = validationInput('empty', '#titlearticle', diverror, txt_error_title, bsubmit, false);
	if (!titlearticle) return;

	var idcategory = validationInput('positive', '#categoryarticle', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryarticle', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var summaryarticle = validationInput('empty', '#summaryarticle', diverror, txt_error_summary, bsubmit, false);
	if (!summaryarticle) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        coda: codearticle,
        tta: titlearticle,
        idca: idcategory,
        idsca: idsubcategory,
        smrya: summaryarticle,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatearticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateArticle_Ok, updateArticle_Error);

}

/******************************************************/


function deleteArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#article-' + paramsArray[0]).fadeOut(500, function() { $('#article-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;            
    }
}

function deleteArticle_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteArticle(codearticle) {
    "use strict";
    paramsArray[0] = codearticle;
    
    var data = {
        cda: codearticle,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deletearticle',
            cancelable: 0,
            data: data
    }

    invoke(params, deleteArticle_Ok, deleteArticle_Error);

}

/******************************************************/

function createAdsHTML_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            if (paramsArray[2] == 1) actionOnClick(_SITE_URL + 'admin/ads/dashboard', 'dashboard-main-area-right', 'min');
            else actionOnClick(_SITE_URL + 'admin/ads/profile', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createAdsHTML_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createAdsHTML(diverror, divok, bsubmit, slot) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = slot;
    
	var nameads = validationInput('empty', '#nameads2', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;

	var codehtml = validationInput('empty', '#codehtml', diverror, txt_error_htmlcode, bsubmit, false);
	if (!codehtml) return;

    var data = {
        namea: nameads,
        chtml: codehtml,
        slot: slot,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'createadshtml',
            cancelable: 0,
            data: data
    }

    invoke(params, createAdsHTML_Ok, createAdsHTML_Error);

}

/******************************************************/

function updateAdsHTML_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateAdsHTML_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateAdsHTML(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var nameads = validationInput('empty', '#nameads2', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;

	var codehtml = validationInput('empty', '#codehtml', diverror, txt_error_htmlcode, bsubmit, false);
	if (!codehtml) return;

	var status = validationInput('zeroandpositive', '#status2', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var data = {
        namea: nameads,
        chtml: codehtml,
        status: status,
        slot: slot,
        idads: idads,
    }

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updateadshtml',
            cancelable: 0,
            data: data
    }

    invoke(params, updateAdsHTML_Ok, updateAdsHTML_Error);

}

/******************************************************/


function updateSidebarUsers_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateSidebarUsers_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateSidebarUsers(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var sidebarusers = validationInput('positive', '#sidebarusers', diverror, txt_error_option, bsubmit, true);
    if (!sidebarusers) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        sbus: sidebarusers,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'sidebarusers',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSidebarUsers_Ok, updateSidebarUsers_Error);

}

/******************************************************/

function adminAddUser_Ok(response) {
    "use strict";
	switch (response.status) {
		case 'ERROR':
			openandclose(paramsArray[0], response.message, 1700);
			setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
			break;
		case 'OK':
            $(paramsArray[1]).html(response.msg_ok);
            $(paramsArray[2]).fadeOut('slow',function(){
                $(paramsArray[2]).hide(function(){
                    $(paramsArray[1]).fadeIn('slow');
                });
            });
			break;
	}
    
}

function adminAddUser_Error(response) {
    "use strict";
	openandclose(paramsArray[0], msg_error_conection, 1700);
	setTimeout(function() {$(paramsArray[3]).removeAttr('disabled');}, 2500); 
}

function adminAddUser(divform, divok, diverror, bsubmit){
    "use strict";
	$(bsubmit).attr('disabled','true');

	var firstname = validationInput('empty', '#firstname', diverror, error_firstname, bsubmit, false);
	if (!firstname) return;

	var lastname = validationInput('empty', '#lastname', diverror, error_lastname, bsubmit, false);
	if (!lastname) return;
    
	var gender = validationInput('positive', '#gender', diverror, error_gender, bsubmit, false);
	if (!gender) return;

	var day = $('#day').val();
	var month = $('#month').val();	
	var year = $('#year').val();
	if (day == 0 || month == 0 || year == 0) {
		openandclose(diverror, error_birthday1, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

	var xday = day;
	var xmonth = month;
	if (day<10) xday='0' + day;
	if (month<10) xmonth='0' + month;
	var caddate = xday + '/' + xmonth + '/' + year;
	if (!validateDate(caddate)) {
		openandclose(diverror, error_birthday2, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

	var email = validationInput('email', '#email', diverror, error_email, bsubmit, false);
	if (!email) return;

	var username = validationInput('username', '#theusername', diverror, error_username, bsubmit, false);
	if (!username) return;

	var password = validationInput('password', '#password', diverror, error_password, bsubmit, false);
	if (!password) return;

	paramsArray[0] = diverror;
	paramsArray[1] = divok;
	paramsArray[2] = divform;
	paramsArray[3] = bsubmit;

    var data = {
        fn: firstname,
        ln: lastname,
        un: username,
        pw: '' + CryptoJS.SHA256(password) + '',
        em: email,
        ge: gender,
        bi: year + '-' + xmonth + '-' + xday,
    }

    var params = {
            type: 'POST',
            withFile: false,
            module:  'admin',
            action: 'adduser',
            cancelable: 0,
            data: data
    };

    invoke(params, adminAddUser_Ok, adminAddUser_Error);
}

/******************************************************/

function payesPaystackA_Ok(response) {
    "use strict";
	switch (response.status) {
		case 'ERROR':
			alert(response.message);
			break;
		case 'OK':
		    location.href = response.info;
			break;
	}

}

function payesPaystackA_Error(response){
    "use strict";
    //alert(msg_error_conection);
}

function payesStripeA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
        case 'OK':

            var stripe = Stripe(the_pk_stripe);
            stripe.redirectToCheckout({
                sessionId: response.sid,
            }).then(function (result) {
                alert(result.error.message);
            });

            break;
    }

}

function payesStripeA_Error(response){
    "use strict";
    alert(msg_error_conection);
}


function payNow(idplan, type_pay) {
    "use strict";
    
    var theamount =  $('#p_p_m_' + thetime_plan + '_' + idplan).val();
    var thenameplan = $('#pm_name_' + idplan).html();

    if (type_pay == 'PayPal') {
        $('#pm-' + idplan).hide();
    	$('#pm-preload-' + idplan).show();
    	
    	$('#formPayPal').attr('action', url_action);
    	$('#cmd').val("_xclick");
    	$('#business').val(empay);
    	$('#return').val(_SITE_URL + 'admin/payment/ok');
    	$('#notify_url').val(_SITE_URL + 'admin/payment/pin');
    	$('#item_name').val(name_item + ' ' + thenameplan);
    	$('#amount').val(theamount);
    	$('#currency_code').val(thecurrency);
    	$('#custom').val(ccompany + ':' + cuser + ':' + idplan + ':' + thetime_plan);
    	$('#formPayPal').submit();
    }

    if (type_pay == 'Paystack') {

        var data = {
            thpln: thenameplan,
            amnt: theamount,
            crcy: thecurrency,
            idpl: idplan,
            tmpl: thetime_plan,
        }

        var params = {
                type: 'POST',
                withFile: false,
                module:  'payes',
                action: 'paystacka',
                cancelable: 0,
                data: data
        };
    
        invoke(params, payesPaystackA_Ok, payesPaystackA_Error);

    }

    if (type_pay == 'Paystack') {

        var data = {
            thpln: thenameplan,
            amnt: theamount,
            crcy: thecurrency,
            idpl: idplan,
            tmpl: thetime_plan,
        }

        var params = {
                type: 'POST',
                withFile: false,
                module:  'payes',
                action: 'paystacka',
                cancelable: 0,
                data: data
        };
    
        invoke(params, payesPaystackA_Ok, payesPaystackA_Error);

    }

    if (type_pay == 'Stripe') {

        var data = {
            thpln: thenameplan,
            amnt: theamount,
            crcy: thecurrency,
            idpl: idplan,
            tmpl: thetime_plan,
        }

        var params = {
                type: 'POST',
                withFile: false,
                module:  'payes',
                action: 'stripea',
                cancelable: 0,
                data: data
        };
    
        invoke(params, payesStripeA_Ok, payesStripeA_Error);

    }


}

/******************************************************/

function updateYourBrand_Ok(response) {
    "use strict";
    $(paramsArray[3]).hide();
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateYourBrand_Error(response) {
    "use strict";
    $(paramsArray[3]).hide();
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateYourBrand(diverror, divok, bsubmit, thepreload, idform) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = thepreload;
    
    var changeimg = $('#changeimg' + idform).val();
    
    if (changeimg == '1') { 

        var thefile = $('#imagenfile' + idform).val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_notformat, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_notimage, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }

    } else {
        openandclose(diverror, txt_error_notimage, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }
    
    $(thepreload).show();

    var formData = new FormData(document.getElementById("form" + idform));
    formData.append("chgi", changeimg);
    formData.append("idform", idform);
    formData.append("codcpny", codcpny);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'admin',
            action: 'updateyourbrand',
            cancelable: 0,
            data: formData
    }

    invoke(params, updateYourBrand_Ok, updateYourBrand_Error);

}

/******************************************************/

function updateCustomDomain_Ok(response) {

   "use strict";

   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            if (paramsArray[3] == 0) {
                $('#yourcdomain').val('');
            }
            
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
   }
}

function updateCustomDomain_Error(response) {
   "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCustomDomain(diverror, divok, bsubmit) {

   "use strict";
    $(bsubmit).attr('disabled','true');
    
    var withcustomdomain = validationInput('zeroandpositive', '#withcustomdomain', diverror, txt_error_option, bsubmit, true);
    if (!withcustomdomain) return;
    
    if (withcustomdomain == 1) {

        var yourcdomain = validationInput('urlwithouthttp', '#yourcdomain', diverror, txt_error_domain, bsubmit, true);
        if (!yourcdomain) return;
        
        yourcdomain = yourcdomain.toLowerCase();
        $('#yourcdomain').val(yourcdomain);
        
        var theposiwww = yourcdomain.indexOf('www.');

        if (theposiwww == 0) {
            openandclose(diverror, txt_error_domain, 1700);
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    
    } else {
        var yourcdomain = '';
    }
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = withcustomdomain;
    
    var data = {
        wcd: withcustomdomain,
        ycd: yourcdomain,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatecustdom',
            cancelable: 0,
            data: data
    };
    
    invoke(params, updateCustomDomain_Ok, updateCustomDomain_Error);

}

/******************************************************/

function updateModules_Ok(response) {

   "use strict";

   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
   }
}

function updateModules_Error(response) {
   "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateModules(diverror, divok, bsubmit) {

   "use strict";
    $(bsubmit).attr('disabled','true');
    
    var modpages = validationInput('zeroandpositive', '#modpages', diverror, txt_error_option, bsubmit, true);
    if (!modpages) return;

    var modgroups = validationInput('zeroandpositive', '#modgroups', diverror, txt_error_option, bsubmit, true);
    if (!modgroups) return;

    var modevents = validationInput('zeroandpositive', '#modevents', diverror, txt_error_option, bsubmit, true);
    if (!modevents) return;

    var modmarket = validationInput('zeroandpositive', '#modmarket', diverror, txt_error_option, bsubmit, true);
    if (!modmarket) return;

    var modlibrary = validationInput('zeroandpositive', '#modlibrary', diverror, txt_error_option, bsubmit, true);
    if (!modlibrary) return;

    var modgames = validationInput('zeroandpositive', '#modgames', diverror, txt_error_option, bsubmit, true);
    if (!modgames) return;


    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        mdp: modpages,
        mdgr: modgroups,
        mde: modevents,
        mdm: modmarket,
        mdl: modlibrary,
        mdgm: modgames,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatemodules',
            cancelable: 0,
            data: data
    };
    
    invoke(params, updateModules_Ok, updateModules_Error);

}

/******************************************************/

function updateRegistrationSettings_Ok(response) {

   "use strict";

   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
   }
}

function updateRegistrationSettings_Error(response) {
   "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateRegistrationSettings(diverror, divok, bsubmit) {

   "use strict";
    $(bsubmit).attr('disabled','true');
    
    var allowregisterdirect = validationInput('zeroandpositive', '#allowregisterdirect', diverror, txt_error_option, bsubmit, true);
    if (!allowregisterdirect) return;

    if (allowregisterdirect == 1) {
        var afterregister = validationInput('zeroandpositive', '#afterregister', diverror, txt_error_option, bsubmit, true);
        if (!afterregister) return;
    
        var minage = validationInput('zeroandpositive', '#minage', diverror, txt_error_min_age, bsubmit, true);
        if (!minage) return;
    
        var maxage = validationInput('zeroandpositive', '#maxage', diverror, txt_error_max_age, bsubmit, true);
        if (!maxage) return;
        
        if (minage != 0 || maxage != 0) {
            if (minage >= maxage) {
                openandclose(diverror, txt_error_mingreatermax, 1700);
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        }
    } else {
        afterregister = 0;
        minage = 0;
        maxage = 0;
    }

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        allre: allowregisterdirect,
        aftre: afterregister,
        rmina: minage,
        rmaxa: maxage,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'registrationsettings',
            cancelable: 0,
            data: data
    };
    
    invoke(params, updateRegistrationSettings_Ok, updateRegistrationSettings_Error);

}

/******************************************************/

function deleteUserPending_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/users/pending', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function deleteUserPending_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteUserPending(codus) {
    "use strict";    
    paramsArray[0] = codus;
    
    var data = {
        cdu: codus,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'deleteuserpending',
            cancelable: 0,
            data: data
    }

    invoke(params, deleteUserPending_Ok, deleteUserPending_Error);

}

/******************************************************/

function approveUserPending_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'admin/users/pending', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function approveUserPending_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
}

function approveUserPending(diverror) {
    "use strict";    
    paramsArray[0] = diverror;
    
    var data = {
        cdu: codus,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'approveuserpending',
            cancelable: 0,
            data: data
    }

    invoke(params, approveUserPending_Ok, approveUserPending_Error);

}

/******************************************************/


function updateMHashtags_Ok(response) {

   "use strict";

   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
   }
}

function updateMHashtags_Error(response) {
   "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateMHashtags(diverror, divok, bsubmit) {

   "use strict";
    $(bsubmit).attr('disabled','true');
    
    hash_status = validationInput('zeroandpositive', '#hash_status', diverror, txt_error_option, bsubmit, true);
    if (!hash_status) return;

    hash_interval = validationInput('zeroandpositive', '#hash_interval', diverror, txt_error_option, bsubmit, true);
    if (!hash_interval) return;

    hash_limit = validationInput('positive', '#hash_limit', diverror, txt_error_hash_limit, bsubmit, true);
    if (!hash_limit) return;

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        hss: hash_status,
        hsi: hash_interval,
        hsl: hash_limit,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'admin',
            action: 'updatemhashtags',
            cancelable: 0,
            data: data
    };
    
    invoke(params, updateMHashtags_Ok, updateMHashtags_Error);

}

/******************************************************/

