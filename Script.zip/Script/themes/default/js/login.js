/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

/**************************************************************/

function login_next_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            location.href = _SITE_URL + response.ucompany + '/l:' + response.theemail;
            break;
    }
}

function login_next_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() {$(paramsArray[1]).removeAttr('disabled');}, 2500);
}

function login_next(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var theemail = validationInput('email', '#theemail', diverror, error_theemail, bsubmit, true);
    if (!theemail) return;

    var data = {
        tem: theemail,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'loginnext',
            action: 'loginnext',
            cancelable: 0,
            data: data
    }

    invoke(params, login_next_Ok, login_next_Error);

}

/**************************************************************/

function login_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            location.href = _SITE_URL + "dashboard";
            break;
    }
}

function login_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() {$(paramsArray[1]).removeAttr('disabled');}, 2500);
}

function login(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var username = $('#username').val();
	if (username.indexOf('@') != -1) {
		username = validationInput('email', '#username', '#alert-username', error_username, bsubmit, true);
		if (!username) return;
	} else {
		username = validationInput('username', '#username', '#alert-username', error_username, bsubmit, true);
		if (!username) return;
	}

	var password = validationInput('password', '#password', '#alert-password', error_password, bsubmit, true);
	if (!password) return;

	var rememberme = 1;

    var data = {
        un: username,
        pw: '' + CryptoJS.SHA256(password) + '',
        cny: ccompany,
        r: rememberme,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'login',
            action: 'login',
            cancelable: 0,
            data: data
    }

    invoke(params, login_Ok, login_Error);

}