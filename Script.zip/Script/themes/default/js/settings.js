/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

_IN_SETTING_PANEL = true;
_SPACE_FULL = true;

/******************************************************/

function updateEmail_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateEmail_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateEmail(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var email = validationInput('email', '#email', diverror, txt_error_email, bsubmit, true);
    if (!email) return;

    var data = {
        em: email,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'email',
            cancelable: 0,
            data: data,
    };

    invoke(params, updateEmail_Ok, updateEmail_Error);

}

/******************************************************/

function updateUsername_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUsername_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUsername(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var username = validationInput('empty', '#theusername', diverror, txt_error_username, bsubmit, true);
    if (!username) return;

    username = validationInput('username', '#theusername', diverror, txt_error_notvalid, bsubmit, true);
    if (!username) return;

    var data = {
        un: username,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'username',
            cancelable: 0,
            data: data,
    };

    invoke(params, updateUsername_Ok, updateUsername_Error);

}

/******************************************************/

function updatePassword_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#pcurrent').val('');
            $('#pnew').val('');
            $('#pnew2').val('');
            $('#pcurrent').focus();
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePassword_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePassword(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pcurrent = validationInput('password', '#pcurrent', diverror, txt_error_pcurrent, bsubmit, true);
    if (!pcurrent) return;

    var pnew = validationInput('password', '#pnew', diverror, txt_error_pnew, bsubmit, true);
    if (!pnew) return;

    var pnew2 = validationInput('password', '#pnew2', diverror, txt_error_pnew2, bsubmit, true);
    if (!pnew2) return;

	if (pnew != pnew2) {
        openandclose(diverror, txt_error_pnomatch, 1700);
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

    var data = {
        pc: '' + CryptoJS.SHA256(pcurrent) + '',
        pn: '' + CryptoJS.SHA256(pnew) + '',
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'password',
            cancelable: 0,
            data: data,
    };

    invoke(params, updatePassword_Ok, updatePassword_Error);

}


/******************************************************/

function updatePersonal_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePersonal_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePersonal(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var firstname = validationInput('empty', '#firstname', diverror, txt_error_firstname, bsubmit, true);
    if (!firstname) return;

    var lastname = validationInput('empty', '#lastname', diverror, txt_error_lastname, bsubmit, true);
    if (!lastname) return;

    var gender = validationInput('positive', '#gender', diverror, txt_error_sex, bsubmit, true);
    if (!gender) return;

	var day = $('#day').val();
	var month = $('#month').val();	
	var year = $('#year').val();
	if (day == 0 || month == 0 || year == 0) {
		openandclose(diverror, txt_error_birthday, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

	var xday = day;
	var xmonth = month;
	if (day<10) xday='0' + day;
	if (month<10) xmonth='0' + month;
	var caddate = xday + '/' + xmonth + '/' + year;
	if (!validateDate(caddate)) {
		openandclose(diverror, txt_error_birthday2, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

    var data = {
        fn: firstname,
        ln: lastname,
        ge: gender,
        bi: year + '-' + xmonth + '-' + xday,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'personal',
            cancelable: 0,
            data: data,
    };

    invoke(params, updatePersonal_Ok, updatePersonal_Error);

}

/******************************************************/

function updateLocation_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateLocation_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateLocation(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var currentcity = validationInput('empty', '#currentcity', diverror, txt_error_currentcity, bsubmit, true);
    if (!currentcity) return;

    var hometown = validationInput('empty', '#hometown', diverror, txt_error_hometown, bsubmit, true);
    if (!hometown) return;

    var data = {
        cc: currentcity,
        ho: hometown,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'location',
            cancelable: 0,
            data: data,
    };

    invoke(params, updateLocation_Ok, updateLocation_Error);

}

/******************************************************/

function updateAboutMe_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateAboutMe_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateAboutMe(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var aboutme = validationInput('empty', '#aboutme', diverror, txt_error_aboutme, bsubmit, true);
    if (!aboutme) return;

    var data = {
        abme: aboutme,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'aboutme',
            cancelable: 0,
            data: data,
    };

    invoke(params, updateAboutMe_Ok, updateAboutMe_Error);

}

/******************************************************/

function updatePrivacyProfile_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePrivacyProfile_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePrivacyProfile(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pprofile = validationInput('number', '#pprofile', diverror, txt_error_option, bsubmit, false);
    if (!pprofile) return;

    var pwritewall = validationInput('number', '#pwritewall', diverror, txt_error_option, bsubmit, false);
    if (!pwritewall) return;

    var pseefriends = validationInput('number', '#pseefriends', diverror, txt_error_option, bsubmit, false);
    if (!pseefriends) return;

    var pseepages = validationInput('number', '#pseepages', diverror, txt_error_option, bsubmit, false);
    if (!pseepages) return;

    var pseegroups = validationInput('number', '#pseegroups', diverror, txt_error_option, bsubmit, false);
    if (!pseegroups) return;

    var pmessages = validationInput('number', '#pmessages', diverror, txt_error_option, bsubmit, false);
    if (!pmessages) return;

    var data = {
        ppro: pprofile,
        pwri: pwritewall,
        psfr: pseefriends,
        pspa: pseepages,
        psgr: pseegroups,
        pmes: pmessages,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'privacyprofile',
            cancelable: 0,
            data: data,
    };

    invoke(params, updatePrivacyProfile_Ok, updatePrivacyProfile_Error);

}

/******************************************************/

function updatePrivacyInfo_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePrivacyInfo_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePrivacyInfo(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pbirthday = validationInput('number', '#pbirthday', diverror, txt_error_option, bsubmit, false);
    if (!pbirthday) return;

    var plocation = validationInput('number', '#plocation', diverror, txt_error_option, bsubmit, false);
    if (!plocation) return;

    var paboutme = validationInput('number', '#paboutme', diverror, txt_error_option, bsubmit, false);
    if (!paboutme) return;

    var data = {
        pbir: pbirthday,
        ploc: plocation,
        pabo: paboutme,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'privacyinfo',
            cancelable: 0,
            data: data,
    };

    invoke(params, updatePrivacyInfo_Ok, updatePrivacyInfo_Error);

}

/******************************************************/

function updatePrivacyChat_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePrivacyChat_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePrivacyChat(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pchat = validationInput('number', '#pchat', diverror, txt_error_option, bsubmit, false);
    if (!pchat) return;

    var pchatmute = validationInput('number', '#pchatmute', diverror, txt_error_option, bsubmit, false);
    if (!pchatmute) return;

    var data = {
        pcha: pchat,
        pchamu: pchatmute,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'privacychat',
            cancelable: 0,
            data: data,
    };

    invoke(params, updatePrivacyChat_Ok, updatePrivacyChat_Error);

}

/******************************************************/

function deleteAccount_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            self.location = _SITE_URL;
            break;
    }
}

function deleteAccount_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function deleteAccount(diverror) {
    "use strict";
    var bsubmit = $('#bsave1');

	$(bsubmit).attr('disabled','true');

    var data = {
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'delete',
            cancelable: 0,
            data: data,
    };

    invoke(params, deleteAccount_Ok, deleteAccount_Error);

}

/******************************************************/


function updateLangTime_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() {
                $(paramsArray[2]).removeAttr('disabled');
                window.location.replace(_SITE_URL + 'settings/account');
            },
            1200);
            break;
    }
}

function updateLangTime_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateLangTime(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var timezone = validationInput('empty', '#timezone', diverror, txt_error_choose_lt, bsubmit, false);
    if (!timezone) return;

    var language = validationInput('empty', '#language', diverror, txt_error_choose_lt, bsubmit, false);
    if (!language) return;

    var data = {
        tztime: timezone,
        tzlang: language,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'timelang',
            cancelable: 0,
            data: data,
    };

    invoke(params, updateLangTime_Ok, updateLangTime_Error);

}

/******************************************************/