/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

function loadcategorymarket_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[0]).html(response.categories);
            $(paramsArray[0]).removeAttr('disabled');
            break;            
    }
}

function loadcategorymarket_Error(response) {
}

function loadcategorymarket(idcat, msgcategory, msgsubcategory, divcategories, divsubcategories, idcompany) {
    "use strict";
	$(divcategories).html('<option value="-1">' + msgcategory + '</option>');
	$(divcategories).attr('disabled','true');
	$(divsubcategories).html('<option value="0">' + msgsubcategory + '</option>');
    
	paramsArray[0] = divcategories;
    
    var data = {
        idc: idcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getcategories',
            action: 'market',
            cancelable: 0,
            data: data
    };

    invoke(params, loadcategorymarket_Ok, loadcategorymarket_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadsubcategorymarket_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.subcategories);
            $(paramsArray[1]).removeAttr('disabled');
            break;            
    }
}

function loadsubcategorymarket_Error(response) {
}

function loadsubcategorymarket(idcat, idsubcat, msgcsubcategory, divsubcategories, idcompany) {	
    "use strict";
	$(divsubcategories).html('<option value="-1">' + msgcsubcategory + '</option>');
	$(divsubcategories).attr('disabled','true');
    
	paramsArray[1] = divsubcategories;
    
    var data = {
        idc: idcat,
        idsc: idsubcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getsubcategories',
            action: 'market',
            cancelable: 0,
            data: data
    };

    invoke(params, loadsubcategorymarket_Ok, loadsubcategorymarket_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/