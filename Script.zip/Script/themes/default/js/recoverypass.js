/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

function resetpass_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.html);
            $(paramsArray[3]).fadeOut('slow',function(){
                $(paramsArray[3]).hide(function(){
                    $(paramsArray[1]).fadeIn('slow');
                });
            });
            break;
    }
}

function resetpass_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() {$(paramsArray[2]).removeAttr('disabled');}, 2500); 
}

function resetpass(divform, divok, diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var email = validationInput('email', '#email_rec', '#alert-email-rec', error_email, bsubmit, true);
	if (!email) return;

    var data = {
        em: email,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = divform;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'recoverypass',
            action: 'recovery',
            cancelable: 0,
            data: data
    };

    invoke(params, resetpass_Ok, resetpass_Error);

}