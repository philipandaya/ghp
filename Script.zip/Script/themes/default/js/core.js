/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

var _SPACE_FULL, _IN_DASHBOARD, _IN_ADMIN_PANEL, _IN_SETTING_PANEL;
_SPACE_FULL = false;
_IN_DASHBOARD = false;
_IN_ADMIN_PANEL = false;
_IN_SETTING_PANEL = false;
var _WIDTH_AREA_WORK;

var httpR;

function startPreloadBar() {
    "use strict";
    $("#preload-bar").show();
    $("#preload-bar").width((50 + Math.random() * 30) + "%");
}

function stopPreloadBar() {
    "use strict";
    $("#preload-bar").width("101%").delay(200).fadeOut(400, function() {
        $(this).width("0");
    });
}

function loadPhantom(source, target, lysize) {
    "use strict";
    startPreloadBar();
	var pageload = source + '/phantom:yes/lysize:' + lysize;
	$.ajax({
        type:'POST',
		url:pageload,
        beforeSend: function(xdatax){
            
            if (httpCancelable.length > 0) {
                for (var i = 0; i < httpCancelable.length; i++) {
                    httpCancelable[i].abort();
                }
                httpCancelable.length = 0;
            }
            
            if (httpR) httpR.abort();
            httpR = xdatax;
        },
        xhrFields: { withCredentials: true },
        crossDomain: 'withCredentials' in new XMLHttpRequest(),
		success: function(response) {
            stopPreloadBar();
			$('#' + target + '').html(response);
            if ( $("#newtitlesite").length > 0 ) document.title = $('#newtitlesite').html();
			$(document).scrollTop(0);
		}
	});
    closeEmerged();
}

/*************************************/

function actionOnClick(sourceURL, target, lysize) {
    "use strict";
    _closeModal();
    
    closeEmerged();

    loadPhantom(sourceURL, target, lysize);
    
    if (sourceURL != window.location) window.history.pushState({"target":target,"size":lysize}, '', sourceURL);    

}

/*************************************/

$(function() {

    $(document).on("click", "a[rel='phantom']", function(e) {
        e.preventDefault();
        actionOnClick($(this).attr('href'), $(this).attr('target'), 'min');
    });
    
    $(document).on("click", "a[rel='phantom-max']", function(e) {
        e.preventDefault();
        the_target = $(this).attr('target');
        lysize = 'max';
        if (_IN_DASHBOARD) {
            if (_SPACE_FULL) {
                _SPACE_FULL = false;
            } else {
                the_target = 'dashboard-main-area-right';
                lysize = 'min';
            }
        }
        actionOnClick($(this).attr('href'), the_target, lysize);
    });
    
    $(document).on("click", "a[rel='phantom-all']", function(e) {
        e.preventDefault();
        if (_IN_DASHBOARD) {
            _SPACE_FULL = true;
        }
        actionOnClick($(this).attr('href'), $(this).attr('target'), 'max');
    });

});


$(window).on('popstate', function(ev) {
	var mobileOs = (navigator.userAgent.match(/(iPad|iPhone|iPod|Android)/g) ? true : false );
	if (mobileOs && !window.history.ready && !ev.originalEvent.state) return;
	
	if (!ev.originalEvent.state) return;

	state = JSON.parse(JSON.stringify(ev.originalEvent.state));
	var pageload = location.href;
	sourceURL = pageload.replace(_SITE_URL, '');
	if (pageload == '') pageload = _SITE_URL;

    if (_IN_DASHBOARD || _IN_SETTING_PANEL || _IN_ADMIN_PANEL) {
        _SPACE_FULL = true;
        state.target = 'dashboard-main-area';
        state.size = 'max';
    }
    
	loadPhantom(pageload, state.target, state.size);
});
