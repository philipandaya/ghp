/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

function registerUserC_Ok(response) {
    "use strict";

	switch (response.status) {
		case 'ERROR':
			openandclose(paramsArray[0], response.message, 1700)
			setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
			break;
		case 'OK':
            if (parseInt(response.with_wait) == 1) {
                $(paramsArray[1]).html(response.msg_ok);
                $(paramsArray[2]).fadeOut('slow',function(){
                    $(paramsArray[2]).hide(function(){
                        $(paramsArray[1]).fadeIn('slow');
                    });
                });
            } else {
    			location.href = _SITE_URL + "dashboard";
            }
			break;
	}
    
}

function registerUserC_Error(response) {
    "use strict";
	openandclose(paramsArray[0], msg_error_conection, 1700)
	setTimeout(function() {$(paramsArray[3]).removeAttr('disabled');}, 2500); 
}

function registerUserC(divform, divok, diverror, bsubmit){
    "use strict";

	$(bsubmit).attr('disabled','true');

	var firstname = validationInput('empty', '#firstname_signup', diverror, error_firstname, bsubmit, false);
	if (!firstname) return;

	var lastname = validationInput('empty', '#lastname_signup', diverror, error_lastname, bsubmit, false);
	if (!lastname) return;

	var email = validationInput('email', '#email_signup', diverror, error_email, bsubmit, false);
	if (!email) return;

	var username = validationInput('username', '#username_signup', diverror, error_username, bsubmit, false);
	if (!username) return;

	var password = validationInput('password', '#password_signup', diverror, error_password, bsubmit, false);
	if (!password) return;

	var bmonth = $('#bmonth_signup').val();
	var bday = $('#bday_signup').val();
	var byear = $('#byear_signup').val();
	if (bmonth == -1 || bday == -1 || byear == -1) {
		openandclose(diverror, error_birthday1, 1700);
		setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
		return;
	}

	var tmpDay = bday;
	var tmpMonth = bmonth;
	if (bday < 10) tmpDay = '0' + bday;
	if (bmonth < 10) tmpMonth = '0' + bmonth;
	var cadDate = tmpDay + '/' + tmpMonth + '/' + byear;

	if (!validateDate(cadDate)) {
		openandclose(diverror, error_birthday2, 1700);
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500);
		return;
	}

	var gender = validationInput('empty', '#valGender', diverror, error_gender, bsubmit, false);
	if (!gender) return;

	paramsArray[0] = diverror;
	paramsArray[1] = divok;
	paramsArray[2] = divform;
	paramsArray[3] = bsubmit;

    var data = {
        fn: firstname,
        ln: lastname,
        un: username,
        pw: '' + CryptoJS.SHA256(password) + '',
        em: email,
        ge: gender,
        bd: bday,
        bm: bmonth,
        by: byear,
        cc: ccpny
    }

    var params = {
            type: 'POST',
            withFile: false,
            module:  'signupuser',
            action: 'signup',
            data: data
    };

    invoke(params, registerUserC_Ok, registerUserC_Error);
}