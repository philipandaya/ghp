/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

_IN_ADMIN_PANEL = true;
_SPACE_FULL = true;

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

function updateGeneralSystemSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateGeneralSystemSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralSystemSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var sstatus = validationInput('zeroandpositive', '#sstatus', diverror, txt_error_option, bsubmit, true);
    if (!sstatus) return;

    var sprivacy = validationInput('zeroandpositive', '#wprivacy', diverror, txt_error_option, bsubmit, true);
    if (!sprivacy) return;

    var scompany = validationInput('empty', '#scompany', diverror, txt_error_company, bsubmit, true);
    if (!scompany) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        sst: sstatus,
        spr: sprivacy,
        scny: scompany,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sasystem',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralSystemSA_Ok, updateGeneralSystemSA_Error);

}

/******************************************************/

function updateGeneralSEOSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateGeneralSEOSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralSEOSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var stitle = validationInput('empty', '#stitle', diverror, txt_error_title, bsubmit, true);
    if (!stitle) return;

    var skeywords = validationInput('empty', '#skeywords', diverror, txt_error_keyword, bsubmit, true);
    if (!skeywords) return;

    var sdescription = validationInput('empty', '#sdescription', diverror, txt_error_description, bsubmit, true);
    if (!sdescription) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        stt: stitle,
        sky: skeywords,
        sdsc: sdescription,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saseo',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralSEOSA_Ok, updateGeneralSEOSA_Error);

}

/******************************************************/

function updateGeneralEmailSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateGeneralEmailSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralEmailSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var fromname = validationInput('empty', '#fromname', diverror, txt_error_fromname, bsubmit, true);
    if (!fromname) return;

    var fromemail = validationInput('email', '#fromemail', diverror, txt_error_fromemail, bsubmit, true);
    if (!fromemail) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        frn: fromname,
        fre: fromemail,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saemail',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralEmailSA_Ok, updateGeneralEmailSA_Error);

}

/******************************************************/

function updateGeneralPHPMAILERSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
        
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGeneralPHPMAILERSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGeneralPHPMAILERSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
    
    var withphpmiler = validationInput('zeroandpositive', '#withphpmail', diverror, txt_error_option, bsubmit, true);
    if (!withphpmiler) return;

    var mailhost = validationInput('empty', '#mailhost', diverror, txt_error_mailhost, bsubmit, true);
    if (!mailhost) return;

    var mailssl = $('#mailssl').val();

    var mailport = validationInput('empty', '#mailport', diverror, txt_error_mailport, bsubmit, true);
    if (!mailport) return;

    var musername = validationInput('email', '#musername', diverror, txt_error_musername, bsubmit, true);
    if (!musername) return;

    var mpassword = validationInput('empty', '#mpassword', diverror, txt_error_mpassword, bsubmit, true);
    if (!mpassword) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        wphpm: withphpmiler,
        mhost: mailhost,
        mssl: mailssl,
        mport: mailport,
        muser: musername,
        mpass: mpassword,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saphpmailer',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGeneralPHPMAILERSA_Ok, updateGeneralPHPMAILERSA_Error);

}

/******************************************************/

function updateThemeSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateThemeSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateThemeSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var thetheme = validationInput('empty', '#thetheme', diverror, txt_error_option, bsubmit, true);
    if (!thetheme) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        them: thetheme,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'satheme',
            cancelable: 0,
            data: data
    };

    invoke(params, updateThemeSA_Ok, updateThemeSA_Error);

}

/******************************************************/

function updateLanguageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateLanguageSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateLanguageSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var thelang = validationInput('empty', '#thelang', diverror, txt_error_option, bsubmit, true);
    if (!thelang) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        lang: thelang,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'salanguage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateLanguageSA_Ok, updateLanguageSA_Error);

}

/******************************************************/

function deleteCategoryPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryPageSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryPageSA(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryPageSA_Ok, deleteCategoryPageSA_Error);

}

/******************************************************/

function updateCategoryPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryPageSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryPageSA(idcategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idcategory;
    var bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryPageSA_Ok, updateCategoryPageSA_Error);

}

/******************************************************/

function deleteSubCategoryPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryPageSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryPageSA(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletesubcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryPageSA_Ok, deleteSubCategoryPageSA_Error);

}

/******************************************************/

function updateSubCategoryPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryPageSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryPageSA(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
    paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatesubcatpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryPageSA_Ok, updateSubCategoryPageSA_Error);

}

/******************************************************/

function deleteCategoryProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryProductSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryProductSA(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryProductSA_Ok, deleteCategoryProductSA_Error);

}

/******************************************************/

function updateCategoryProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryProductSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryProductSA(idcategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idcategory;
    var bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryProductSA_Ok, updateCategoryProductSA_Error);

}

/******************************************************/

function deleteSubCategoryProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryProductSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryProductSA(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletesubcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryProductSA_Ok, deleteSubCategoryProductSA_Error);

}

/******************************************************/

function updateSubCategoryProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryProductSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryProductSA(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
	paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatesubcatproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryProductSA_Ok, updateSubCategoryProductSA_Error);

}

/******************************************************/

function deleteCategoryArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteCategoryArticleSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteCategoryArticleSA(idcategory) {
    "use strict";
	paramsArray[0] = idcategory;

    var data = {
        idcat: idcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCategoryArticleSA_Ok, deleteCategoryArticleSA_Error);

}

/******************************************************/

function updateCategoryArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCategoryArticleSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateCategoryArticleSA(idcategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idcategory;
    var bsubmit = '#bupdate' +  idcategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idcategory, diverror, text_error_name_category, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idcategory;
	paramsArray[3] = namecategory;

    var data = {
        icat: idcategory,
        ncat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCategoryArticleSA_Ok, updateCategoryArticleSA_Error);

}

/******************************************************/

function deleteSubCategoryArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose('#errorcat-' + paramsArray[0], response.message, 1700);
            break;
    
        case 'OK':
            $('#onecat-' + paramsArray[0]).fadeOut(500, function() { $('#onecat-' + paramsArray[0]).remove(); });
            break;
    }
}

function deleteSubCategoryArticleSA_Error(response) {
    "use strict";
    openandclose('#errorcat-' + paramsArray[0], msg_error_conection, 1700);
}

function deleteSubCategoryArticleSA(idsubcategory) {
    "use strict";
	paramsArray[0] = idsubcategory;

    var data = {
        idscat: idsubcategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletesubcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteSubCategoryArticleSA_Ok, deleteSubCategoryArticleSA_Error);

}

/******************************************************/

function updateSubCategoryArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#textname' + paramsArray[2]).html(paramsArray[3]);
            $('#namecategory' + paramsArray[2]).val(paramsArray[3]);
            $('#areaedit-' + paramsArray[2]).slideUp('slow', function(){
                $('#spacecat-' + paramsArray[2]).slideDown('slow');
            });
    
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateSubCategoryArticleSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateSubCategoryArticleSA(idscategory) {
    "use strict";
    var diverror = '#msgerrorcat' + idscategory;
    var bsubmit = '#bupdate' +  idscategory;

	$(bsubmit).attr('disabled','true');

    var namecategory = validationInput('empty', '#namecategory' + idscategory, diverror, text_error_name_subcategory, bsubmit, true);
    if (!namecategory) return;
    
	paramsArray[0] = diverror;
	paramsArray[1] = bsubmit;
	paramsArray[2] = idscategory;
	paramsArray[3] = namecategory;

    var data = {
        iscat: idscategory,
        nscat: namecategory,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatesubcatarticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateSubCategoryArticleSA_Ok, updateSubCategoryArticleSA_Error);

}

/******************************************************/

function deleteUserSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#user-' + paramsArray[0]).fadeOut(500, function() { $('#user-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteUserSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteUserSA(iduser) {
    "use strict";
    paramsArray[0] = iduser;
    
    var data = {
        iduser: iduser,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeleteuser',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteUserSA_Ok, deleteUserSA_Error);

}

/******************************************************/

function updateUserGeneralSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserGeneralSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserGeneralSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var verify = validationInput('zeroandpositive', '#verify', diverror, txt_error_option, bsubmit, true);
    if (!verify) return;

    var status = validationInput('zeroandpositive', '#status', diverror, txt_error_option, bsubmit, true);
    if (!status) return;

    var level = validationInput('zeroandpositive', '#level', diverror, txt_error_option, bsubmit, true);
    if (!level) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ver: verify,
        sta: status,
        lev: level,
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sausergeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserGeneralSA_Ok, updateUserGeneralSA_Error);

}

/******************************************************/

function updateUserProfileSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserProfileSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserProfileSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var firstname = validationInput('empty', '#firstname', diverror, txt_error_firstname, bsubmit, true);
    if (!firstname) return;

    var lastname = validationInput('empty', '#lastname', diverror, txt_error_lastname, bsubmit, true);
    if (!lastname) return;

    var gender = validationInput('positive', '#gender', diverror, txt_error_sex, bsubmit, true);
    if (!gender) return;

	var day = $('#day').val();
	var month = $('#month').val();	
	var year = $('#year').val();
	if (day == 0 || month == 0 || year == 0) {
		openandclose(diverror, txt_error_birthday, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

	var xday = day;
	var xmonth = month;
	if (day<10) xday='0' + day;
	if (month<10) xmonth='0' + month;
	var caddate = xday + '/' + xmonth + '/' + year;
	if (!validateDate(caddate)) {
		openandclose(diverror, txt_error_birthday2, 1700);
		$('#year').focus();
		setTimeout(function() {$(bsubmit).removeAttr('disabled');}, 2500); 
		return;
	}

    var currentcity = validationInput('empty', '#currentcity', diverror, txt_error_currentcity, bsubmit, true);
    if (!currentcity) return;

    var hometown = validationInput('empty', '#hometown', diverror, txt_error_hometown, bsubmit, true);
    if (!hometown) return;
        
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        fn: firstname,
        ln: lastname,
        ge: gender,
        bi: year + '-' + xmonth + '-' + xday,
        cc: currentcity,
        ht: hometown,
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sauserprofile',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserProfileSA_Ok, updateUserProfileSA_Error);

}

/******************************************************/

function updateUserEmailSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserEmailSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserEmailSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var email = validationInput('email', '#email', diverror, txt_error_email, bsubmit, true);
    if (!email) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        em: email,
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sauseremail',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserEmailSA_Ok, updateUserEmailSA_Error);

}

/******************************************************/

function updateUserUsernameSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserUsernameSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserUsernameSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var username = validationInput('empty', '#theusername', diverror, txt_error_username, bsubmit, true);
    if (!username) return;

    username = validationInput('username', '#theusername', diverror, txt_error_notvalid, bsubmit, true);
    if (!username) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        un: username,
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sauserusername',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserUsernameSA_Ok, updateUserUsernameSA_Error);

}

/******************************************************/

function updateUserPasswordSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#password').val('');
            $('#password').focus();
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserPasswordSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserPasswordSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pnew = validationInput('password', '#password', diverror, txt_error_pnew, bsubmit, true);
    if (!pnew) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        pn: '' + CryptoJS.SHA256(pnew) + '',
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sauserpassword',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserPasswordSA_Ok, updateUserPasswordSA_Error);

}

/******************************************************/

function updateUserPrivacySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateUserPrivacySA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateUserPrivacySA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var pprofile = validationInput('number', '#pprofile', diverror, txt_error_option, bsubmit, false);
    if (!pprofile) return;

    var pwritewall = validationInput('number', '#pwritewall', diverror, txt_error_option, bsubmit, false);
    if (!pwritewall) return;

    var pseefriends = validationInput('number', '#pseefriends', diverror, txt_error_option, bsubmit, false);
    if (!pseefriends) return;

    var pseepages = validationInput('number', '#pseepages', diverror, txt_error_option, bsubmit, false);
    if (!pseepages) return;

    var pseegroups = validationInput('number', '#pseegroups', diverror, txt_error_option, bsubmit, false);
    if (!pseegroups) return;

    var pmessages = validationInput('number', '#pmessages', diverror, txt_error_option, bsubmit, false);
    if (!pmessages) return;

    var pbirthday = validationInput('number', '#pbirthday', diverror, txt_error_option, bsubmit, false);
    if (!pbirthday) return;

    var plocation = validationInput('number', '#plocation', diverror, txt_error_option, bsubmit, false);
    if (!plocation) return;

    var paboutme = validationInput('number', '#paboutme', diverror, txt_error_option, bsubmit, false);
    if (!paboutme) return;

    var pchat = validationInput('number', '#pchat', diverror, txt_error_option, bsubmit, false);
    if (!pchat) return;    

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ppro: pprofile,
        pwri: pwritewall,
        psfr: pseefriends,
        pspa: pseepages,
        psgr: pseegroups,
        pmes: pmessages,
        pbir: pbirthday,
        ploc: plocation,
        pabo: paboutme,
        pcha: pchat,
        idu: idu,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sauserprivacy',
            cancelable: 0,
            data: data
    };

    invoke(params, updateUserPrivacySA_Ok, updateUserPrivacySA_Error);

}


/******************************************************/

function deletePageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#page-' + paramsArray[0]).fadeOut(500, function() { $('#page-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deletePageSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deletePageSA(theparam) {
    "use strict";
    var idpage = theparam[0];
    var idcompany = theparam[1];
    
    paramsArray[0] = idpage;
    
    var data = {
        idpage: idpage,
        idcny: idcompany,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletepage',
            cancelable: 0,
            data: data
    };

    invoke(params, deletePageSA_Ok, deletePageSA_Error);

}


/******************************************************/

function updatePageGeneralSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updatePageGeneralSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePageGeneralSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var verify = validationInput('zeroandpositive', '#verify', diverror, txt_error_option, bsubmit, true);
    if (!verify) return;

	var idcategory = validationInput('positive', '#categorypage', diverror, txt_choose_category, bsubmit, true);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategorypage', diverror, txt_choose_subcategory, bsubmit, true);
	if (!idsubcategory) return;

	var titlepage = validationInput('empty', '#titlepage', diverror, txt_enter_title, bsubmit, true);
	if (!titlepage) return;

	var urlpage = validationInput('empty', '#urlpage', diverror, txt_enter_url, bsubmit, true);
	if (!urlpage) return;

	var urlpage = validationInput('pageorgroup', '#urlpage', diverror, txt_url_invalid, bsubmit, true);
	if (!urlpage) return;

	var descriptionpage = validationInput('empty', '#descriptionpage', diverror, txt_enter_description, bsubmit, true);
	if (!descriptionpage) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ver: verify,
        pic: idcategory,
        pisc: idsubcategory,
        pti: titlepage,
        pur: urlpage,
        pds: descriptionpage,
        idp: idp,
        idcpy: idcpy,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatepagesgeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updatePageGeneralSA_Ok, updatePageGeneralSA_Error);

}

/******************************************************/

function deleteGroupSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#group-' + paramsArray[0]).fadeOut(500, function() { $('#group-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteGroupSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteGroupSA(theparam) {
    "use strict";
    var idgroup = theparam[0];
    var idcompany = theparam[1];

    paramsArray[0] = idgroup;
    
    var data = {
        idgroup: idgroup,
        idcny: idcompany,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletegroup',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteGroupSA_Ok, deleteGroupSA_Error);

}

/******************************************************/

function updateGroupGeneralSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGroupGeneralSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGroupGeneralSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var titlegroup = validationInput('empty', '#titlegroup', diverror, txt_enter_title, bsubmit, true);
	if (!titlegroup) return;

	var urlgroup = validationInput('empty', '#urlgroup', diverror, txt_enter_url, bsubmit, true);
	if (!urlgroup) return;

	var urlgroup = validationInput('pageorgroup', '#urlgroup', diverror, txt_url_invalid, bsubmit, true);
	if (!urlgroup) return;

	var descriptiongroup = validationInput('empty', '#descriptiongroup', diverror, txt_enter_description, bsubmit, true);
	if (!descriptiongroup) return;

    var privacygroup = $('#privacygroup').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        gti: titlegroup,
        gur: urlgroup,
        gds: descriptiongroup,
        gpr: privacygroup,
        idg: idg,
        idcpy: idcpy,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdategroupsgeneral',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGroupGeneralSA_Ok, updateGroupGeneralSA_Error);

}

/******************************************************/

function createStaticPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'superadmin/static-pages', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createStaticPageSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createStaticPageSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var urlstatic = validationInput('url_static', '#urlstatic', diverror, txt_error_url, bsubmit, true);
    if (!urlstatic) return;

    var titlestatic = validationInput('empty', '#titlestatic', diverror, txt_error_title, bsubmit, true);
    if (!titlestatic) return;

    var htmlstatic = validationInput('empty', '#htmlstatic', diverror, txt_error_html, bsubmit, true);
    if (!htmlstatic) return;

    var infootstatic = $('#infootstatic').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        us: urlstatic,
        ts: titlestatic,
        hs: htmlstatic,
        ifs : infootstatic,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saaddstaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, createStaticPageSA_Ok, createStaticPageSA_Error);

}

/******************************************************/

function updateStaticPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateStaticPageSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateStaticPageSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var urlstatic = validationInput('url_static', '#urlstatic', diverror, txt_error_url, bsubmit, true);
    if (!urlstatic) return;

    var titlestatic = validationInput('empty', '#titlestatic', diverror, txt_error_title, bsubmit, true);
    if (!titlestatic) return;

    var htmlstatic = validationInput('empty', '#htmlstatic', diverror, txt_error_html, bsubmit, true);
    if (!htmlstatic) return;

    var infootstatic = $('#infootstatic').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ids: id_staticpage,
        us: urlstatic,
        ts: titlestatic,
        hs: htmlstatic,
        ifs : infootstatic,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatestaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, updateStaticPageSA_Ok, updateStaticPageSA_Error);

}

/******************************************************/

function updateStaticPageCompanySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateStaticPageCompanySA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateStaticPageCompanySA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var urlstatic = validationInput('url_static', '#urlstatic', diverror, txt_error_url, bsubmit, true);
    if (!urlstatic) return;

    var titlestatic = validationInput('empty', '#titlestatic', diverror, txt_error_title, bsubmit, true);
    if (!titlestatic) return;

    var htmlstatic = validationInput('empty', '#htmlstatic', diverror, txt_error_html, bsubmit, true);
    if (!htmlstatic) return;

    var infootstatic = $('#infootstatic').val();
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        ids: id_staticpage,
        us: urlstatic,
        ts: titlestatic,
        hs: htmlstatic,
        ifs: infootstatic,
        icspc: idcompany_spc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatestaticpagecompany',
            cancelable: 0,
            data: data
    };

    invoke(params, updateStaticPageCompanySA_Ok, updateStaticPageCompanySA_Error);

}

/******************************************************/

function deleteStaticPageSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#static-' + paramsArray[0]).fadeOut(500, function() { $('#static-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteStaticPageSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteStaticPageSA(idsp) {
    "use strict";
    paramsArray[0] = idsp;
    
    var data = {
        idsp: idsp,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletestaticpage',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteStaticPageSA_Ok, deleteStaticPageSA_Error);

}

/******************************************************/

function deleteStaticPageCompanySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#static-' + paramsArray[0]).fadeOut(500, function() { $('#static-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteStaticPageCompanySA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteStaticPageCompanySA(idsp) {
    "use strict";
    paramsArray[0] = idsp;
    
    var data = {
        idsp: idsp,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletestaticpagecompany',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteStaticPageCompanySA_Ok, deleteStaticPageCompanySA_Error);

}

/******************************************************/

function deleteCurrencyCompanySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#onecurrency-' + paramsArray[0]).fadeOut(500, function() { $('#onecurrency-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteCurrencyCompanySA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteCurrencyCompanySA(idc) {
    "use strict";
    paramsArray[0] = idc;
    
    var data = {
        idc: idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecurrencycompany',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCurrencyCompanySA_Ok, deleteCurrencyCompanySA_Error);

}

/******************************************************/

function updateCurrencyCompanySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'superadmin/currencies-companies', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function updateCurrencyCompanySA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCurrencyCompanySA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var namecurrency = validationInput('empty', '#namecurrency', diverror, txt_error_name, bsubmit, true);
    if (!namecurrency) return;

    var codecurrency = validationInput('empty', '#codecurrency', diverror, txt_error_code, bsubmit, true);
    if (!codecurrency) return;

    var symbolcurrency = validationInput('empty', '#symbolcurrency', diverror, txt_error_symbol, bsubmit, true);
    if (!symbolcurrency) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        idc: idc,
        namec: namecurrency,
        codec: codecurrency,
        symbc: symbolcurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecurrencycompany',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCurrencyCompanySA_Ok, updateCurrencyCompanySA_Error);

}

/******************************************************/

function deleteAdsSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#oneads-' + paramsArray[0]).fadeOut(500, function() { $('#oneads-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteAdsSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteAdsSA(id) {
    "use strict";
	paramsArray[0] = id;

    var data = {
        idad: id,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeleteads',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteAdsSA_Ok, deleteAdsSA_Error);

}

/******************************************************/

function updateAdsSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateAdsSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection+'xxx', 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateAdsSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var nameads = validationInput('empty', '#nameads', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;
    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') {
    
        var thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_formatimage, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_image, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    }

	var urlads = validationInput('url', '#urlads', diverror, txt_error_url, bsubmit, false);
	if (!urlads) return;
    
	var target = validationInput('zeroandpositive', '#target', diverror, txt_error_target, bsubmit, false);
	if (!target) return;
    
	var status = validationInput('zeroandpositive', '#status', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var formData = new FormData(document.getElementById("form1"));
    formData.append("namea", nameads);
    formData.append("urla", urlads);
    formData.append("tara", target);
    formData.append("slot", slot);
    formData.append("idads", idads);
    formData.append("status", status);
    formData.append("chgi", changeimg);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'superadmin',
            action: 'saupdateads',
            cancelable: 0,
            data: formData
    };

    invoke(params, updateAdsSA_Ok, updateAdsSA_Error);

}

/******************************************************/

function deleteGameSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#onegame-' + paramsArray[0]).fadeOut(500, function() { $('#onegame-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteGameSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteGameSA(id) {
    "use strict";
	paramsArray[0] = id;

    var data = {
        idg: id,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletegame',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteGameSA_Ok, deleteGameSA_Error);

}

/******************************************************/

function updateGameSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGameSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateGameSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var namegame = validationInput('empty', '#namegame', diverror, txt_error_name, bsubmit, false);
	if (!namegame) return;
    
	var urlgame = validationInput('url', '#urlgame', diverror, txt_error_url_game, bsubmit, false);
	if (!urlgame) return;
    
	var urlowner = validationInput('url', '#urlowner', diverror, txt_error_url_owner, bsubmit, false);
	if (!urlowner) return;
    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') {
    
        var thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_thumbnail_format, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_thumbnail, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    }

	var status = validationInput('zeroandpositive', '#status', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var formData = new FormData(document.getElementById("form1"));
    formData.append("nameg", namegame);
    formData.append("urlgm", urlgame);
    formData.append("urlow", urlowner);
    formData.append("idgam", idgame);
    formData.append("status", status);
    formData.append("chgi", changeimg);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'superadmin',
            action: 'saupdategame',
            cancelable: 0,
            data: formData
    };

    invoke(params, updateGameSA_Ok, updateGameSA_Error);

}

/******************************************************/

function updateTimezoneSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateTimezoneSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateTimezoneSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var timezone = validationInput('empty', '#timezone', diverror, txt_error_option, bsubmit, true);
    if (!timezone) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        timez: timezone,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'satimezone',
            cancelable: 0,
            data: data
    };

    invoke(params, updateTimezoneSA_Ok, updateTimezoneSA_Error);

}

/******************************************************/

function updateProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateProductSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateProductSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var nameproduct = validationInput('empty', '#nameproduct', diverror, txt_error_name, bsubmit, false);
	if (!nameproduct) return;

	var descriptionproduct = validationInput('empty', '#descriptionproduct', diverror, txt_error_description, bsubmit, false);
	if (!descriptionproduct) return;

	var idcategory = validationInput('positive', '#categoryproduct', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryproduct', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;
    
	var typeproduct = validationInput('positive', '#typeproduct', diverror, txt_error_type, bsubmit, false);
	if (!typeproduct) return;

	var currencyproduct = validationInput('positive', '#currencyproduct', diverror, txt_error_currency, bsubmit, false);
	if (!currencyproduct) return;
    
	var priceproduct = validationInput('numberpositive', '#priceproduct', diverror, txt_error_price, bsubmit, false);
	if (!priceproduct) return;
    
	var locationproduct = validationInput('empty', '#locationproduct', diverror, txt_error_location, bsubmit, false);
	if (!locationproduct) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        idpr: idproduct,
        namp: nameproduct,
        desp: descriptionproduct,
        idcp: idcategory,
        idsp: idsubcategory,
        typp: typeproduct,
        curp: currencyproduct,
        prip: priceproduct,
        locp: locationproduct,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdateproduct',
            cancelable: 0,
            data: data
    };

    invoke(params, updateProductSA_Ok, updateProductSA_Error);

}

/******************************************************/

function deleteProductSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#product-' + paramsArray[0]).fadeOut(500, function() { $('#product-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;            
    }
}

function deleteProductSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteProductSA(theparam) {
    "use strict";
    var idproduct = theparam[0];
    var idcompany = theparam[1];

    paramsArray[0] = idproduct;
    
    var data = {
        idp: idproduct,
        idcny: idcompany,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeleteproduct',
            cancelable: 0,
            data: data
    }

    invoke(params, deleteProductSA_Ok, deleteProductSA_Error);

}

/******************************************************/


function updateArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateArticleSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateArticleSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var titlearticle = validationInput('empty', '#titlearticle', diverror, txt_error_title, bsubmit, false);
	if (!titlearticle) return;

	var idcategory = validationInput('positive', '#categoryarticle', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryarticle', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var summaryarticle = validationInput('empty', '#summaryarticle', diverror, txt_error_summary, bsubmit, false);
	if (!summaryarticle) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        idea: idarticle,
        tta: titlearticle,
        idca: idcategory,
        idsca: idsubcategory,
        smrya: summaryarticle,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatearticle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateArticleSA_Ok, updateArticleSA_Error);

}

/******************************************************/


function deleteArticleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#article-' + paramsArray[0]).fadeOut(500, function() { $('#article-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;            
    }
}

function deleteArticleSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteArticleSA(idarticle) {
    "use strict";
    paramsArray[0] = idarticle;
    
    var data = {
        ida: idarticle,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletearticle',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteArticleSA_Ok, deleteArticleSA_Error);

}

/******************************************************/

function updateAdsHTMLSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[2], response.themessage, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateAdsHTMLSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateAdsHTMLSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = divok;
    
	var nameads = validationInput('empty', '#nameads2', diverror, txt_error_name, bsubmit, false);
	if (!nameads) return;

	var codehtml = validationInput('empty', '#codehtml', diverror, txt_error_htmlcode, bsubmit, false);
	if (!codehtml) return;

	var status = validationInput('zeroandpositive', '#status2', diverror, txt_error_status, bsubmit, false);
	if (!status) return;

    var data = {
        namea: nameads,
        chtml: codehtml,
        status: status,
        slot: slot,
        idads: idads,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdateadshtml',
            cancelable: 0,
            data: data
    };

    invoke(params, updateAdsHTMLSA_Ok, updateAdsHTMLSA_Error);

}

/******************************************************/

function updateAPIGoogleSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateAPIGoogleSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateAPIGoogleSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var apigoogle = validationInput('empty', '#apigoogle', diverror, txt_error_apigoogle, bsubmit, true);
    if (!apigoogle) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        apig: apigoogle,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saapigoogle',
            cancelable: 0,
            data: data
    };

    invoke(params, updateAPIGoogleSA_Ok, updateAPIGoogleSA_Error);

}

/******************************************************/

function updateCurrencyGatSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateCurrencyGatSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCurrencyGatSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
    
    var thecurrency = $('#thecurrency').val();

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        tcr: thecurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sacurrency',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCurrencyGatSA_Ok, updateCurrencyGatSA_Error);

}

/******************************************************/

function updatePlanFreeSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updatePlanFreeSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePlanFreeSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var free_users = validationInput('positive', '#free_users', diverror, txt_error_users, bsubmit, true);
    if (!free_users) return;

    var free_videos = validationInput('zeroandpositive', '#free_videos', diverror, txt_error_option_choice, bsubmit, true);
    if (!free_videos) return;

    var free_audios = validationInput('zeroandpositive', '#free_audios', diverror, txt_error_option_choice, bsubmit, true);
    if (!free_audios) return;

    var free_days = validationInput('positive', '#free_days', diverror, txt_error_days, bsubmit, true);
    if (!free_days) return;
    
	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        pfu: free_users,
        pfv: free_videos,
        pfa: free_audios,
        pfd: free_days,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdateplanfree',
            cancelable: 0,
            data: data
    };

    invoke(params, updatePlanFreeSA_Ok, updatePlanFreeSA_Error);

}

/******************************************************/

function updatePlanSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updatePlanSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updatePlanSA(diverror, divok, bsubmit, plan) { /* UPDATE in v1.0.1 */
    "use strict";
	$(bsubmit).attr('disabled','true');

    var name_plan = validationInput('empty', '#p' + plan + '_name', diverror, txt_error_name_plan, bsubmit, false);
    if (!name_plan) return;

    var monthly_price = validationInput('positive', '#p' + plan + '_price_monthly', diverror, txt_error_monthly_price, bsubmit, false);
    if (!monthly_price) return;

    var annual_price = validationInput('positive', '#p' + plan + '_price_annual', diverror, txt_error_annual_price, bsubmit, false);
    if (!annual_price) return;

    var max_users = validationInput('positive', '#p' + plan + '_users', diverror, txt_error_users, bsubmit, false);
    if (!max_users) return;

    var sup_videos = validationInput('zeroandpositive', '#p' + plan + '_videos', diverror, txt_error_option_choice, bsubmit, false);
    if (!sup_videos) return;

    var sup_audios = validationInput('zeroandpositive', '#p' + plan + '_audios', diverror, txt_error_option_choice, bsubmit, false);
    if (!sup_audios) return;
    
    w_cdomain = 0;
    if (wcd == 1) {
        var w_cdomain = validationInput('zeroandpositive', '#p' + plan + '_cdomain', diverror, txt_error_option_choice, bsubmit, false);
        if (!w_cdomain) return;        
    }

    var is_popular = validationInput('zeroandpositive', '#p' + plan + '_popular', diverror, txt_error_option_choice, bsubmit, false);
    if (!is_popular) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        pnm: name_plan,
        pmp: monthly_price,
        pap: annual_price,
        pmu: max_users,
        psv: sup_videos,
        psa: sup_audios,
        pip: is_popular,
        thp: plan,
        wcd: w_cdomain,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdateplan',
            cancelable: 0,
            data: data
    };

    invoke(params, updatePlanSA_Ok, updatePlanSA_Error);

}

/******************************************************/

function deleteCompanySA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#item-' + paramsArray[0]).fadeOut(500, function() { $('#item-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteCompanySA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteCompanySA(idcompany) {
    "use strict";
    paramsArray[0] = idcompany;
    
    var data = {
        idc: idcompany,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecompany',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCompanySA_Ok, deleteCompanySA_Error);

}

/******************************************************/

function updateCompanyBasicSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCompanyBasicSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCompanyBasicSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var company_name = validationInput('empty', '#company_name', diverror, txt_error_name_company, bsubmit, true);
    if (!company_name) return;

    var company_phone = validationInput('empty', '#company_phone', diverror, txt_error_phone_company, bsubmit, true);
    if (!company_phone) return;

    var company_username = validationInput('empty', '#company_username', diverror, txt_error_username_company, bsubmit, true);
    if (!company_username) return;
    
    company_username = validationInput('usernamecompany', '#company_username', diverror, txt_error_username_company_invalid, bsubmit, true);
    if (!company_username) return;

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        cn: company_name,
        cp: company_phone,
        cu: company_username,
        idc: idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sacompanybasic',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCompanyBasicSA_Ok, updateUserProfileSA_Error);

}

/******************************************************/

function updateCompanyPlanSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateCompanyPlanSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCompanyPlanSA(diverror, divok, bsubmit) {
    "use strict";    
	$(bsubmit).attr('disabled','true');

    var plan_users = validationInput('empty', '#plan_users', diverror, txt_error_max_users, bsubmit, true);
    if (!plan_users) return;

    var plan_days = validationInput('empty', '#plan_days', diverror, txt_error_days, bsubmit, true);
    if (!plan_days) return;

    var plan_sup_video = $('#plan_sup_video').val();
    var plan_sup_audio = $('#plan_sup_audio').val();    

    var plan_cdomain = 0;
    if (wcdm == 1) {
        plan_cdomain = $('#plan_cdomain').val();
    }

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        pu: plan_users,
        pd: plan_days,
        psv: plan_sup_video,
        psa: plan_sup_audio,
        idc: idc,
        cdm: plan_cdomain,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sacompanyplan',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCompanyPlanSA_Ok, updateCompanyPlanSA_Error);

}

/******************************************************/

function updateGatPaypalSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGatPaypalSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGatPaypalSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var do_with_paypal = $('#do_with_paypal').val();

    if (do_with_paypal == 1) {

        var email_paypal = validationInput('email', '#email_paypal', diverror, txt_error_email_paypal, bsubmit, true);
        if (!email_paypal) return;

        var email_notification = validationInput('email', '#email_notification', diverror, txt_error_email_paypal, bsubmit, true);
        if (!email_notification) return;

        var url_action_paypal = validationInput('empty', '#url_action_paypal', diverror, txt_error_url_action_paypal, bsubmit, true);
        if (!url_action_paypal) return;

        var url_action_paypal_ipn = validationInput('empty', '#url_action_paypal_ipn', diverror, txt_error_url_action_paypal_ipn, bsubmit, true);
        if (!url_action_paypal_ipn) return;

    } else {

        var email_paypal = $('#email_paypal').val();
        var email_notification = $('#email_notification').val();
        var url_action_paypal = $('#url_action_paypal').val();
        var url_action_paypal_ipn = $('#url_action_paypal_ipn').val();

    }

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        dwp: do_with_paypal,
        emp: email_paypal,
        emn: email_notification,
        uap: url_action_paypal,
        uapipn: url_action_paypal_ipn,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdategatpaypal',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGatPaypalSA_Ok, updateGatPaypalSA_Error);

}

/******************************************************/

function updateBrandGlobalSA_Ok(response) {
    "use strict";
    $(paramsArray[3]).hide();
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateBrandGlobalSA_Error(response) {
    "use strict";
    $(paramsArray[3]).hide();
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateBrandGlobalSA(diverror, divok, bsubmit, thepreload, idform) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = thepreload;
    
    var changeimg = $('#changeimg' + idform).val();
    
    if (changeimg == '1') { 

        var thefile = $('#imagenfile' + idform).val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_notformat, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_notimage, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }

    } else {
        openandclose(diverror, txt_error_notimage, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }
    
    $(thepreload).show();

    var formData = new FormData(document.getElementById("form" + idform));
    formData.append("chgi", changeimg);
    formData.append("idform", idform);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'superadmin',
            action: 'saupdatebrand',
            cancelable: 0,
            data: formData
    };

    invoke(params, updateBrandGlobalSA_Ok, updateBrandGlobalSA_Error);

}

/******************************************************/

function updateCustomDomainsSA_Ok(response) {

   "use strict";

   switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;

        case 'OK':
            if (paramsArray[3] == 0) {
                $('#cdomains_dns1').val('');
                $('#cdomains_dns2').val('');
                $('#cdomains_dns3').val('');
                $('#cdomains_timeresponse').val('');
                $('#cdomains_emailnotif').val('');
            }
            
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
   }
}

function updateCustomDomainsSA_Error(response) {
   "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCustomDomainsSA(diverror, divok, bsubmit) {

   "use strict";
    $(bsubmit).attr('disabled','true');
    
    var withcdomains = validationInput('zeroandpositive', '#withcdomains', diverror, txt_error_option, bsubmit, true);
    if (!withcdomains) return;
    
    if (withcdomains == 1) {

        var cdomains_dns1 = validationInput('empty', '#cdomains_dns1', diverror, txt_error_dns1, bsubmit, true);
        if (!cdomains_dns1) return;

        var cdomains_dns2 = validationInput('empty', '#cdomains_dns2', diverror, txt_error_dns2, bsubmit, true);
        if (!cdomains_dns2) return;
        
        var cdomains_dns3 = $('#cdomains_dns3').val();
    
        var cdomains_timeresponse = validationInput('positive', '#cdomains_timeresponse', diverror, txt_error_timeresponse, bsubmit, true);
        if (!cdomains_timeresponse) return;
    
        var cdomains_emailnotif = validationInput('email', '#cdomains_emailnotif', diverror, txt_error_cdemailnotif, bsubmit, true);
        if (!cdomains_emailnotif) return;
    
    } else {
        var cdomains_dns1 = '';
        var cdomains_dns2 = '';
        var cdomains_dns3 = '';
        var cdomains_timeresponse = '';
        var cdomains_emailnotif = '';
    }
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = withcdomains;
    
    var data = {
        wcd: withcdomains,
        ns1: cdomains_dns1,
        ns2: cdomains_dns2,
        ns3: cdomains_dns3,
        tmr: cdomains_timeresponse,
        enf: cdomains_emailnotif,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecustdoms',
            cancelable: 0,
            data: data
    };
    
    invoke(params, updateCustomDomainsSA_Ok, updateCustomDomainsSA_Error);

}

/******************************************************/

function updateContactEmailSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.msg_ok, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateContactEmailSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateContactEmailSA(diverror, divok, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

    var contactemail = validationInput('email', '#contactemail', diverror, txt_error_contactemail, bsubmit, true);
    if (!contactemail) return;

	paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        cem: contactemail,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sacontactemail',
            cancelable: 0,
            data: data
    };

    invoke(params, updateContactEmailSA_Ok, updateContactEmailSA_Error);

}

/******************************************************/

function updateGatStripeSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGatStripeSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGatStripeSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var do_with_stripe = $('#do_with_stripe').val();

    if (do_with_stripe == 1) {

        var do_with_alipay = $('#do_with_alipay').val();

        var stripe_secret_key = validationInput('empty', '#stripe_secret_key', diverror, txt_error_stripe_secret_key, bsubmit, true);
        if (!stripe_secret_key) return;

        var stripe_publishable_key = validationInput('empty', '#stripe_publishable_key', diverror, txt_error_stripe_publishable_key, bsubmit, true);
        if (!stripe_publishable_key) return;

        var stripe_email_notif = validationInput('empty', '#email_notification_stripe', diverror, txt_error_email_notification_stripe, bsubmit, true);
        if (!stripe_email_notif) return;

    } else {

        var do_with_alipay = $('#do_with_alipay').val();
        var stripe_secret_key = $('#stripe_secret_key').val();
        var stripe_publishable_key = $('#stripe_publishable_key').val();
        var stripe_email_notif = $('#email_notification_stripe').val();

    }

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        dws: do_with_stripe,
        dwa: do_with_alipay,
        ssk: stripe_secret_key,
        spk: stripe_publishable_key,
        sen: stripe_email_notif,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdategatstripe',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGatStripeSA_Ok, updateGatStripeSA_Error);

}

/******************************************************/

function updateGatPaystackSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGatPaystackSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGatPaystackSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var do_with_paystack = $('#do_with_paystack').val();

    if (do_with_paystack == 1) {

        var paystack_public_key = validationInput('empty', '#paystack_public_key', diverror, txt_error_paystack_public_key, bsubmit, true);
        if (!paystack_public_key) return;

        var paystack_secret_key = validationInput('empty', '#paystack_secret_key', diverror, txt_error_paystack_secret_key, bsubmit, true);
        if (!paystack_secret_key) return;

        var paystack_email_notif = validationInput('empty', '#email_notification_paystack', diverror, txt_error_email_notification_paystack, bsubmit, true);
        if (!paystack_email_notif) return;

    } else {

        var paystack_public_key = $('#paystack_public_key').val();
        var paystack_secret_key = $('#paystack_secret_key').val();
        var paystack_email_notif = $('#email_notification_paystack').val();

    }

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        dwps: do_with_paystack,
        pspk: paystack_public_key,
        pssk: paystack_secret_key,
        psen: paystack_email_notif,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdategatpaystack',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGatPaystackSA_Ok, updateGatPaystackSA_Error);

}

/******************************************************/

function updateGDPRSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    }
}

function updateGDPRSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateGDPRSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var gdprstatus = validationInput('zeroandpositive', '#gdprstatus', diverror, txt_error_option, bsubmit, true);
    if (!gdprstatus) return;

    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    
    var data = {
        gdpr: gdprstatus,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdategdpr',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGDPRSA_Ok, updateGDPRSA_Error);

}

/******************************************************/

function deleteCurrencySystemSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#onecurrency-' + paramsArray[0]).fadeOut(500, function() { $('#onecurrency-' + paramsArray[0]).remove(); });
            $('#num_items').html(parseInt($('#num_items').html()) - 1);
            break;
    }
}

function deleteCurrencySystemSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteCurrencySystemSA(idc) {
    "use strict";
    paramsArray[0] = idc;
    
    var data = {
        idc: idc,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletecurrencysystem',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteCurrencySystemSA_Ok, deleteCurrencySystemSA_Error);

}

/******************************************************/

function createCurrencySystemSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'superadmin/currencies-system', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function createCurrencySystemSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function createCurrencySystemSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var namecurrency = validationInput('empty', '#namecurrency', diverror, txt_error_name, bsubmit, true);
    if (!namecurrency) return;

    var codecurrency = validationInput('empty', '#codecurrency', diverror, txt_error_code, bsubmit, true);
    if (!codecurrency) return;

    var symbolcurrency = validationInput('empty', '#symbolcurrency', diverror, txt_error_symbol, bsubmit, true);
    if (!symbolcurrency) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        namec: namecurrency,
        codec: codecurrency,
        symbc: symbolcurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saaddcurrencysystem',
            cancelable: 0,
            data: data
    };

    invoke(params, createCurrencySystemSA_Ok, createCurrencySystemSA_Error);

}

/******************************************************/

function updateCurrencySystemSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'superadmin/currencies-system', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function updateCurrencySystemSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateCurrencySystemSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var namecurrency = validationInput('empty', '#namecurrency', diverror, txt_error_name, bsubmit, true);
    if (!namecurrency) return;

    var codecurrency = validationInput('empty', '#codecurrency', diverror, txt_error_code, bsubmit, true);
    if (!codecurrency) return;

    var symbolcurrency = validationInput('empty', '#symbolcurrency', diverror, txt_error_symbol, bsubmit, true);
    if (!symbolcurrency) return;
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        idc: idc,
        namec: namecurrency,
        codec: codecurrency,
        symbc: symbolcurrency,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saupdatecurrencysystem',
            cancelable: 0,
            data: data
    };

    invoke(params, updateCurrencySystemSA_Ok, updateCurrencySystemSA_Error);

}

/******************************************************/

function updateAdsSettingSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            openandclose(paramsArray[1], response.html, 1700);
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function updateAdsSettingSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
}

function updateAdsSettingSA(diverror, divok, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    var allowadscompany = validationInput('zeroandpositive', '#allow-ads-company', diverror, txt_error_option, bsubmit, true);
    if (!allowadscompany) return;

    if (allowadscompany == 1) {
        var allowadsonfree = validationInput('zeroandpositive', '#allow-ads-on-free', diverror, txt_error_option, bsubmit, true);
        if (!allowadsonfree) return;
    } else {
        var allowadsonfree = 0;
    }
    
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;

    var data = {
        aac: allowadscompany,
        aof: allowadsonfree,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'saadssetting',
            cancelable: 0,
            data: data
    };

    invoke(params, updateAdsSettingSA_Ok, updateAdsSettingSA_Error);

}

/******************************************************/

function createMyAdsSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            if (paramsArray[2] == 1) actionOnClick(_SITE_URL + 'superadmin/myads/dashboard', 'dashboard-main-area-right', 'min');
            else actionOnClick(_SITE_URL + 'superadmin/myads/profile', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createMyAdsSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createMyAdsSA(diverror, divok, bsubmit, slot) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = slot;
    
    var nameads = validationInput('empty', '#nameads', diverror, txt_error_name, bsubmit, false);
    if (!nameads) return;
    
    var thefile = $('#imagenfile').val();
    if (thefile != '') {
        var ext = thefile.split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            openandclose(diverror, txt_error_formatimage, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    } else {
        openandclose(diverror, txt_error_image, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

    var urlads = validationInput('url', '#urlads', diverror, txt_error_url, bsubmit, false);
    if (!urlads) return;
    
    var target = validationInput('zeroandpositive', '#target', diverror, txt_error_target, bsubmit, false);
    if (!target) return;


    var formData = new FormData(document.getElementById("form1"));
    formData.append("namea", nameads);
    formData.append("urla", urlads);
    formData.append("tara", target);
    formData.append("slot", slot);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'superadmin',
            action: 'sacreatemyads',
            cancelable: 0,
            data: formData
    }

    invoke(params, createMyAdsSA_Ok, createMyAdsSA_Error);

}

/******************************************************/

function deleteMyAdsSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            $('#oneads-' + paramsArray[0]).fadeOut(500, function() { $('#oneads-' + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteMyAdsSA_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deleteMyAdsSA(id) {
    "use strict";
    paramsArray[0] = id;

    var data = {
        idad: id,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sadeletemyads',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteMyAdsSA_Ok, deleteMyAdsSA_Error);

}

/******************************************************/

function createMyAdsHTMLSA_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            if (paramsArray[2] == 1) actionOnClick(_SITE_URL + 'superadmin/myads/dashboard', 'dashboard-main-area-right', 'min');
            else actionOnClick(_SITE_URL + 'superadmin/myads/profile', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createMyAdsHTMLSA_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createMyAdsHTMLSA(diverror, divok, bsubmit, slot) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    paramsArray[2] = slot;
    
    var nameads = validationInput('empty', '#nameads2', diverror, txt_error_name, bsubmit, false);
    if (!nameads) return;

    var codehtml = validationInput('empty', '#codehtml', diverror, txt_error_htmlcode, bsubmit, false);
    if (!codehtml) return;

    var data = {
        namea: nameads,
        chtml: codehtml,
        slot: slot,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'superadmin',
            action: 'sacreatemyadshtml',
            cancelable: 0,
            data: data
    }

    invoke(params, createMyAdsHTMLSA_Ok, createMyAdsHTMLSA_Error);

}

/******************************************************/
