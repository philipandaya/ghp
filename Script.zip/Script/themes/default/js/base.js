/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

/*************************************/

var paramsArray = new Array();

/*************************************/

function hideScrollBody() {
    "use strict";
    var $thebody = $(window.document.body);
    var bodyWidth = $thebody.innerWidth();
    $thebody.css('overflow', 'hidden'); 
    $thebody.css('marginRight', ($thebody.css('marginRight') ? '+=' : '') + ($thebody.innerWidth() - bodyWidth)) 
}

function showScrollBody() {
    "use strict";
    var $thebody = $(window.document.body);
    var bodyWidth = $thebody.innerWidth();
    $thebody.css('marginRight', '-=' + (bodyWidth - $thebody.innerWidth()))
    $thebody.css('overflow', 'auto');  
}

/*************************************/

function activeSlimScrollers() {
    "use strict";
    $('.slimscrollers').each(function(){
        if ($(this).parent('.slimScrollDiv').length > 0) return;
        $(this).slimScroll({
            height: function(){
                var value_default = '100%';
                var height = $(this).attr('data-slimscroll-height');
                if (height === undefined) return value_default;
                return height;
            },
            distance: '2px'
        })
    });
}

/*************************************/

function nothign(){ }

function _closeModal() {
    "use strict";
    $('#the-modal-content').html('');
    $('#the-modal').removeClass('modal-for-zoomeer');
    $('#the-modal').hide();
    showScrollBody();
}

function _alert(theContent) {
    "use strict";
    hideScrollBody();
    $('#the-modal-content').html(theContent);
    $('#the-modal').show();
    $('#space_close, #bclose_alert').on("click", function(){
        _closeModal();
    });
}

function _confirm(theContent, callCancel, callConfirm, thevalue) {
    "use strict";
    hideScrollBody();
    $('#the-modal-content').html(theContent);
    $('#the-modal').show();
    $('#space_close, #b_cancel').on("click", function(){
        _closeModal();
        callCancel();
    });

    $('#b_ok').on("click", function(){
        _closeModal();
        callConfirm(thevalue);
    });
}

function _confirmWithInput(theContent, callCancel, callConfirm, thevalue, theinput) {
    "use strict";
    hideScrollBody();
    $('#the-modal-content').html(theContent);
    $('#the-modal').show();
    $('#space_close, #b_cancel').on("click", function(){
        _closeModal();
        callCancel();
    });

    $('#b_ok').on("click", function(){
        var valuereturn = $.trim($(theinput).val());
        if (valuereturn == '') return false;
        _closeModal();
        callConfirm(thevalue, valuereturn);
    });
}

$(document).on('click', '#the-modal', function(e) {
    "use strict";
    if ($(e.target).is("#the-modal")) {
        _closeModal();
    }
});

/**********************/
$('html').on('click', '.slimScrollBar', function (e) {
    "use strict";
    e.stopPropagation();
});

$(document).on('click', '.slimScrollBar', function (e) {
    "use strict";
    e.stopPropagation();
});
/*********************/

function destroy_slimScrol(element) {
    "use strict";
    if($(element).parent().hasClass('slimScrollDiv')) {
        $(element).parent().replaceWith($(element));
        $(element).removeAttr('style');
    }
}

/*************************************/

function closeEmerged() {
    "use strict";
    /****************************/
	clearInterval(delayCard);
	clearInterval(delayCard2);
    $('#item-card').html('');
    /****************************/
    
    $('._emerged').hide();
    
    if (_IN_DASHBOARD || _IN_ADMIN_PANEL || _IN_SETTING_PANEL) {
        if (isVisibleMenuMore) closeMenuMore();
        if (isVisibleNotif) closeNotifGlobal();
        if (isVisibleNotifPeople) closeNotifPeople();
        if (isVisibleNotifMessage) closeNotifMessage();
        if (isVisibleMenuResponsive) closeMenuResponsive();
        
        if ($('#inputsf').val() != '') {
            $('#inputsf').val('');
            loadFriendsOnline();
        }
        
        if ($('#inputsf2').val() != '') {
            $('#inputsf2').val('');
            loadFriendsOnline();
        }

        if ($('#input-search-top').val() != '') {
            $('#input-search-top').val('');
        }
        
    }    
    //return false;
}

/*************************************/

function validateDate(a) {
    "use strict";
    var strExpReg = /^(((0[1-9]|[12][0-9]|3[01])([/])(0[13578]|10|12)([/])(\d{4}))|(([0][1-9]|[12][0-9]|30)([/])(0[469]|11)([/])(\d{4}))|((0[1-9]|1[0-9]|2[0-8])([/])(02)([/])(\d{4}))|((29)(\.|-|\/)(02)([/])([02468][048]00))|((29)([/])(02)([/])([13579][26]00))|((29)([/])(02)([/])([0-9][0-9][0][48]))|((29)([/])(02)([/])([0-9][0-9][2468][048]))|((29)([/])(02)([/])([0-9][0-9][13579][26])))$/;
    return strExpReg.test(a);
}

/*************************************/

function validateEmail(e) {
    "use strict";
	var b=/^[^@\s]+@[^@\.\s]+(\.[^@\.\s]+)+$/;
	return b.test(e);
}

/*************************************/

function validateUsername(username) {
    "use strict";
	var pattern = /^[A-Za-z0-9][A-Za-z0-9_]{5,14}$/;
	if (username.match(pattern)) return true;
	return false;
}

function validateUsernameCompany(username) {
    "use strict";
	var pattern = /^[A-Za-z0-9][A-Za-z0-9_]{5,20}$/;
	if (username.match(pattern)) return true;
	return false;
}

/*************************************/

function validateURLStatic(url) {
    "use strict";
	var pattern = /^[A-Za-z0-9][A-Za-z0-9_]{3,20}$/;
	if (url.match(pattern)) return true;
	return false;
}

/*************************************/

function validateUrl(url) {
    "use strict";
    return url.match(/^(http|https|ftp):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(:(\d+))?\/?/i);
}

/*************************************/

function validateUrlWithoutHttp(url) {
    "use strict";
    return url.match(/^(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(:(\d+))?\/?/i);
}

/*************************************/

function validateUsernamePageOrGroup(username) {
    "use strict";
	if (username == '') return false;
	if (username.lenght < 6 && username.lenght > 20) return false;
	
	var pattern = /^[A-Za-z0-9][A-Za-z0-9_]{5,19}$/; //Allow only letters, digits and the underscore (except in the first position). With a minimum of 6 characters (1+5), and a maximum of 20 (1+19).
	if (username.match(pattern)) return true;
	return false;
}

/*************************************/

function stripslashes(str) {
    "use strict";
    return (str + '')
        .replace(/\\(.?)/g, function(s, n1) {
          switch (n1) {
            case '\\':
              return '\\';
            case '0':
              return '\u0000';
            case '':
              return '';
            default:
              return n1;
          }
    });
}

/*************************************/

function replaceString(cadsearch, cadreplace, num, str) {
    "use strict";
    var newcad = str;
    for (var x=0; x<num; x++) {
        newcad = str.replace(cadsearch, cadreplace);
        str = newcad;
    }
    return newcad;
}

/*************************************/

function is_empty(value) {
    "use strict";
    if (value.match(/\S/) == null) return true;
    else return false;
}

/*************************************/

function opendiv(thediv,message) {
    "use strict";
	$(thediv).html(message);
	$(thediv).slideDown("slow");
}

var divactive='';
var delayactive;
function openandclose(thediv,message,thetime) {
    "use strict";
	$(thediv).html(message);
	$(thediv).slideDown("slow", function(){
		divactive=thediv;
		delayactive=setTimeout(closediv,thetime);
	});	
}

function closediv() {
    "use strict";
	$(divactive).slideUp("slow", function(){
		clearTimeout(delayactive);
	});
}

/*************************************/
var httpCancelable = new Array(); 
function invoke(params, fSuccess, fError) {
    "use strict";
    if (params.withFile) { 
        $.ajax({
            type: params.type ? params.type : 'POST',
            url: _SITE_URL + 'services/' + params.module + '/' + params.action,
            
            beforeSend: function(xdatax){
                if (params.cancelable == 1) {
                    httpCancelable.push(xdatax);
                }
            },            
            
            data: params.data,
            cache: false,
            contentType: false,
            processData: false,
            
            xhrFields: { withCredentials: true },
            crossDomain: 'withCredentials' in new XMLHttpRequest(),
            
            success: function(response) {
                fSuccess(response.data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                var response = new Array(jqXHR, textStatus, errorThrown);
                fError(response);
            }
        });
    } else {
        $.ajax({
            type: params.type ? params.type : 'POST',
            url: _SITE_URL + 'services/' + params.module + '/' + params.action,
            
            beforeSend: function(xdatax){
                if (params.cancelable == 1) {
                    httpCancelable.push(xdatax);
                }
            },
            
            data: params.data,
            
            xhrFields   : { withCredentials: true },
            crossDomain : 'withCredentials' in new XMLHttpRequest(),
            
            success: function(response) {
                fSuccess(response.data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                var response = new Array(jqXHR, textStatus, errorThrown);
                fError(response);
            }
        });
    }
}

/*************************************/
/*************************************/
/*************************************/

var delayCard, delayCard2;
function keepCardVisible() {
    "use strict";
	clearInterval(delayCard2);
}

function ignoreItemCard() {
	"use strict";
	clearInterval(delayCard);
	
	delayCard2 = setInterval(function() {
        $('#item-card').html('');
		$('#item-card').hide();
		clearInterval(delayCard2);	
	},700);
	
}

function itemCard_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#item-card').html(response.message);
            break;
    
        case 'OK':
            if (response.withcover) {
                var unewtop = response.utopCard + 'px';
                $('#item-card').css('top',unewtop);
                $('#item-card').html(response.html);
            } else {
                var unewtop = response.utopCardnoCover + 'px';
                $('#item-card').css('top',unewtop);
                $('#item-card').html(response.html);
            }
            break;            
    }
}

function itemCard_Error(response) {
}

function itemCard(posi, divitem, ucode, typeItem) {
    "use strict";

	clearInterval(delayCard2);
	delayCard = setInterval(function() {    

		var margintop = 10;
		
		var heightAvat1 = 42;
		var heightName1 = 17;
		var heightAvat2 = 35;
		var heightName2 = 14;
		
		var topDiv = $('#' + divitem).offset().top;
		var leftDiv = $('#' + divitem).offset().left;

		var heightCard = 180;
		var heightCardnoCover = 125;
	
		var u = topDiv > ($(document).scrollTop() + $(window).height() / 2) ? 's' : 'n';
		
		if (u == 'n') {
	
			var utopini = margintop + topDiv  + 10;

			if (posi == 0) { utopini = utopini + heightAvat1; }
			if (posi == 1) { utopini = utopini + heightName1; }
			if (posi == 2) { utopini = utopini + heightAvat2; }
			if (posi == 3) { utopini = utopini + heightName2; }
			
			var utopCard = utopini;
			var utopCardnoCover = utopini;
			
		} else {
			
			var utopini = margintop + topDiv - 35;
			
			var utopCard = utopini - heightCard;
			var utopCardnoCover = utopini - heightCardnoCover;
			
		}
		
		if (posi == 0 || posi == 2) { leftDiv = leftDiv - 10; }
		if (posi == 1 || posi == 3) { leftDiv = leftDiv + 50; }
	
		$('#item-card').show();
		$('#item-card').html('<div class="cpreload"><div class="k-preloader"></div></div>');
	
		var pos = {
			top: utopini + 'px',
			left: leftDiv + 'px'
		};
		
		$('#item-card').css(pos);

        var data = {
            cod: ucode,
            typ: typeItem,
            unt: utopCard,
            untnc: utopCardnoCover,
            waw: _WIDTH_AREA_WORK,
        };
    
        var params = {
                type: 'POST',
                withFile: false,
                module: 'itemcard',
                action: 'load',
                cancelable: 1,
                data: data
        };
    
        invoke(params, itemCard_Ok, itemCard_Error);
    
		clearInterval(delayCard);

	}, 700);

}

/*************************************/

function actionSearchForTop_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $('#inside-info-search').html(response.result_search);
            $('#link-more-search-top').attr('href', _SITE_URL + 'search/q:' + response.the_query);
            break;            
    }
}

function actionSearchForTop_Error(response) {
}

function actionSearchForTop(query) {
    "use strict";
    var data = {
        q: query,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssearch',
            action: 'searchtop',
            cancelable: 0,
            data: data
    };

    invoke(params, actionSearchForTop_Ok, actionSearchForTop_Error);

}

function searchForTop() {
    "use strict";
	var query = $('#input-search-top').val();
        
	if (query == '') {
		var time_show_result = 0;
	} else {
		$('#area-results-search').show();
		var time_show_result = 250;
    }
    
	setTimeout(function() {

        if($.trim(query) == '') {
            $("#area-results-search").hide();
            $("#inside-info-search").html('');
        } else {
            actionSearchForTop(query);
        }

	}, time_show_result);
}

/*************************************/

function handleFiles(files, divpreview, nummax) {
    "use strict";
    var themax = nummax;
    if (nummax > files.length) themax = files.length;
    
    if ($('#' + divpreview + ' img').length < nummax) {
    
        for (var i = 0; i < themax; i++) {
            var file = files[i];
            
            if (!file.type.startsWith('image/')){ continue }
            
            var img = document.createElement("img");
            img.classList.add("obj");
            img.file = file;
            var preview = document.getElementById(divpreview);
            preview.appendChild(img); // Assuming that "preview" is the div output where the content will be displayed.
            
            var reader = new FileReader();
            reader.onload = (function(aImg) { return function(e) { aImg.src = e.target.result; }; })(img);
            reader.readAsDataURL(file);
        }
        
        return true;

    } else return false;

}

/*************************************/

function validationInput(action, idinput, diverror, msgerror, bsubmit, withfocus) {
    "use strict";
	$(bsubmit).attr('disabled','true');
	var valinput = $.trim($(idinput).val());
    var result = false;
	switch (action) {
		case 'empty':
			if (valinput != '') result = true;
			break;

		case 'negative':
			if (valinput < 0) result = true;
			break;

		case 'positive':
			if (valinput > 0) result = true;
			break;

		case 'zero':
			if (valinput == 0) result = true;
			break;

		case 'zeroandpositive':
			if (valinput >= 0) result = true;
			break;

		case 'number':
			if (!isNaN(valinput)) result = true;
			break;
            
		case 'numberpositive':
			if (!isNaN(valinput)) 
                if (valinput > 0) result = true;
			break;

		case 'email':
			if (validateEmail(valinput)) result = true;
			break;
			
		case 'username':
			if (validateUsername(valinput)) result = true;
			break;

		case 'usernamecompany':
			if (validateUsernameCompany(valinput)) result = true;
			break;

		case 'url_static':
			if (validateURLStatic(valinput)) result = true;
			break;
            
		case 'pageorgroup':
			if (validateUsernamePageOrGroup(valinput)) result = true;
			break;
			
		case 'password':
			if (valinput != '' && valinput.length >= 6 && valinput.length <= 20) result = true;
			break;
            
		case 'url':
			if (validateUrl(valinput)) result = true;
			break;

		case 'urlwithouthttp':
			if (validateUrlWithoutHttp(valinput)) result = true;
			break;
	}

    if (result == false) {
        $(idinput).val(valinput);
        openandclose(diverror,msgerror,1700);	
        if (withfocus) $(idinput).focus();
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500); 
        return false;
    } else {
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500); 
        return valinput;
    }
}

/**********************************************************/

function moreActivities_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            var theactivities = response.activities;
            var more = parseInt(response.more);
    
            $('#list-activities').append(theactivities);
    
            if (more == 1) {
                var ap = parseInt($('#activity_page').val());
                $('#activity_page').val(ap + 1);
                var reloading_done = 0;
            } else {
                $('#linkmore').hide();
                var reloading_done = 1;
            }
    
            $('video.js_video-js').each(function(){ videojs($(this)[0], {}, function() {}); });
            $('audio.mep_audio').mediaelementplayer();
            activeSlimScrollers();
            $('.action_autosize').each(function(){
                autosize(this);
            });
    
            break;            
    }
    $('#loader_showmore').hide();
    $('#bmore').show();
}

function moreActivities_Error(response) {
}

function moreActivities() {
    "use strict";
    $('#bmore').hide();
    $('#loader_showmore').show();

    var data = {
        ap: $('#activity_page').val(),
        plc: theplace,
        cp: code_profile,
        typ: type_items,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'moreactivities',
            action: 'more',
            cancelable: 1,
            data: data
    };

    invoke(params, moreActivities_Ok, moreActivities_Error);

}

/**********************************************************/

function moreCommentsPost_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            
            let codepost = response.codepost;
            let comments = response.comments;
            let numcomms = response.numcomms;
            let more = response.more;
            let commperpost = response.commperpost;
					
            $('#space-commspost-' + codepost).prepend(comments);

            $('#numcomms_' + codepost).val(parseInt(numcomms));

            $('#preload-morecomms-' + codepost).hide();
            
            if (more == true) {
				$('#space-morecomms-' + codepost).show();
            } else {
                $('#space-morecomms-' + codepost).remove();
            }
    
            break;            
    }

}

function moreCommentsPost_Error(response) {
}

function moreCommentsPost(codepost) {
    "use strict";
    
	$('#space-morecomms-' + codepost).hide();
	$('#preload-morecomms-' + codepost).show();
	
	let numcomms = $('#numcomms_' + codepost).val();

    var data = {
        codp: codepost,
        numc: numcomms,
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'morecomments',
            action: 'more',
            cancelable: 1,
            data: data
    };

    invoke(params, moreCommentsPost_Ok, moreCommentsPost_Error);

}

/**********************************************************/

$('html').on('click', function() {
    closeEmerged();
});

$(function() {
    _WIDTH_AREA_WORK = $('.spacetop').width();
    $(window).resize(function() {
        _WIDTH_AREA_WORK = $('.spacetop').width();
    });
});

window.onbeforeunload = function() {
  window.scrollTo(0, 0);
}

function goAnchor(theid) {
    "use strict";
    $('html,body').animate({scrollTop: $(theid).offset().top}, 500);
}


$(function() {
    
    function changeLang_Ok(response) {
        switch (response.status) {
            case 'ERROR':
                break;
            case 'OK':
                location.href = $(location).attr('href');
                break;
        }
    }
    
    function changeLang_Error(response) {}
    
    $(document).on("click", "a[rel='language']", function(e) {
        e.preventDefault();
        var data = {
            lg: $(this).attr('data-lang'),
        };
        var params = {
                type: 'POST',
                module:  'changelang',
                action: 'change',
                cancelable: 0,
                data: data
        };
        invoke(params, changeLang_Ok, changeLang_Error);
    });
    


});