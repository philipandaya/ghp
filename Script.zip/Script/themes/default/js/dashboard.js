/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

_IN_ADMIN_PANEL = false;
_IN_SETTING_PANEL = false;
_IN_DASHBOARD = true;

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function moreItems_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            var theItems = response.items;
            var more = parseInt(response.more);
    
            $('#list-items').append(theItems);
                        
            if (more == 1) {
                var ap = parseInt($('#activity_page').val());
                $('#activity_page').val(ap + 1);
                var reloading_done = 0;
            } else {
                $('#space_more').hide();
                var reloading_done = 1;
            }
            break;            
    }
}

function moreItems_Error(response) {
}

function moreItems() {
    "use strict";
    var data = {
        ap: $('#activity_page').val(),
        from: $('#activities_place').val(),
    };

    var params = {
            type: 'POST',
            withFile: false,
            module: 'moreitems',
            action: 'more',
            cancelable: 1,
            data: data
    };

    invoke(params, moreItems_Ok, moreItems_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function createGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlgroup, 'dashboard-main-area', 'max');
            break;            
    }
}

function createGroup_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createGroup(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
	
	var titlegroup = validationInput('empty', '#titlegroup', diverror, txt_enter_title, bsubmit, true);
	if (!titlegroup) return;
	
	var urlgroup = validationInput('empty', '#urlgroup', diverror, txt_enter_url, bsubmit, true);
	if (!urlgroup) return;
    
	var urlgroup = validationInput('pageorgroup', '#urlgroup', diverror, txt_url_invalid, bsubmit, true);
	if (!urlgroup) return;
	
	var descriptiongroup = validationInput('empty', '#descriptiongroup', diverror, txt_enter_description, bsubmit, true);
	if (!descriptiongroup) return;

    var privacygroup = $('#privacygroup').val();

	paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var data = {
        gti: titlegroup,
        gur: urlgroup,
        gds: descriptiongroup,
        gpr: privacygroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsgroups',
            action: 'create',
            cancelable: 0,
            data: data
    };

    invoke(params, createGroup_Ok, createGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function updateGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700);
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlgroup, 'dashboard-main-area', 'max');
            break;            
    }
}

function updateGroup_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700);
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateGroup(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
	
	var titlegroup = validationInput('empty', '#titlegroup', diverror, txt_enter_title, bsubmit, true);
	if (!titlegroup) return;
	
	var urlgroup = validationInput('empty', '#urlgroup', diverror, txt_enter_url, bsubmit, true);
	if (!urlgroup) return;
    
	var urlgroup = validationInput('pageorgroup', '#urlgroup', diverror, txt_url_invalid, bsubmit, true);
	if (!urlgroup) return;
	
	var descriptiongroup = validationInput('empty', '#descriptiongroup', diverror, txt_enter_description, bsubmit, true);
	if (!descriptiongroup) return;

    var privacygroup = $('#privacygroup').val();

	paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var data = {
        gti: titlegroup,
        gur: urlgroup,
        gds: descriptiongroup,
        gpr: privacygroup,
        cgr: cgr,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsgroups',
            action: 'update',
            cancelable: 0,
            data: data
    };

    invoke(params, updateGroup_Ok, updateGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function searchGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preloadsearch').hide();
            openandclose(paramsArray[2], response.message, 1700)
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#preloadsearch').hide();
            $('#space-result-search-groups').html(response.theresult);
            $('#space-result-search-groups').show();
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function searchGroup_Error(response) {
    "use strict";
    $('#preloadsearch').hide();
    openandclose(paramsArray[2], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
}

function searchGroup(diverror, bsubmit) {
    "use strict";
    $('#space-result-search-groups').html('');
        
	$(bsubmit).attr('disabled','true');
    $('#preloadsearch').show();
    
	var termsearch = validationInput('empty', '#termsearch', diverror, txt_error_empty_term, bsubmit, true);
	if (!termsearch) return;
    
    if ($.trim($('#termsearch').val()).length <= 3) {
        openandclose(diverror, txt_error_short_term, 1700);		
        $('#termsearch').focus();
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500); 
        return;
    }

	paramsArray[2] = diverror;
    paramsArray[3] = bsubmit;
    
    var data = {
        tse: termsearch,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsgroups',
            action: 'search',
            cancelable: 0,
            data: data
    };

    invoke(params, searchGroup_Ok, searchGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'groups', 'dashboard-main-area', 'max');
            break;            
    }
}

function deleteGroup_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deleteGroup(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: codegroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsgroups',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteGroup_Ok, deleteGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadcategorypages_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
        
        case 'OK':
            $(paramsArray[0]).html(response.categories);
            $(paramsArray[0]).removeAttr('disabled');
            break;            
        }
}

function loadcategorypages_Error(response) {
}

function loadcategorypages(idcat, msgcategory, msgsubcategory, divcategories, divsubcategories, idcompany) {
    "use strict";
	$(divcategories).html('<option value="-1">' + msgcategory + '</option>');
	$(divcategories).attr('disabled','true');
	$(divsubcategories).html('<option value="0">' + msgsubcategory + '</option>');
    
	paramsArray[0] = divcategories;
    
    var data = {
        idc: idcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getcategories',
            action: 'getcatpages',
            cancelable: 0,
            data: data
    };

    invoke(params, loadcategorypages_Ok, loadcategorypages_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadsubcategorypages_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.subcategories);
            $(paramsArray[1]).removeAttr('disabled');
            break;            
    }
}

function loadsubcategorypages_Error(response) {
}

function loadsubcategorypages(idcat, idsubcat, msgcsubcategory, divsubcategories, idcompany) {
    "use strict";
	$(divsubcategories).html('<option value="-1">' + msgcsubcategory + '</option>');
	$(divsubcategories).attr('disabled','true');
    
	paramsArray[1] = divsubcategories;
    
    var data = {
        idc: idcat,
        idsc: idsubcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getsubcategories',
            action: 'getsubcatpages',
            cancelable: 0,
            data: data
    };

    invoke(params, loadsubcategorypages_Ok, loadsubcategorypages_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function createPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[2], response.message, 1700);
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlpage, 'dashboard-main-area', 'max');
            break;            
    }
}

function createPage_Error(response) {
    "use strict";
    openandclose(paramsArray[2], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
}

function createPage(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
    
	var idcategory = validationInput('positive', '#categorypage', diverror, txt_choose_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategorypage', diverror, txt_choose_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var titlepage = validationInput('empty', '#titlepage', diverror, txt_enter_title, bsubmit, false);
	if (!titlepage) return;
	
	var urlpage = validationInput('empty', '#urlpage', diverror, txt_enter_url, bsubmit, false);
	if (!urlpage) return;
    
	var urlpage = validationInput('pageorgroup', '#urlpage', diverror, txt_url_invalid, bsubmit, false);
	if (!urlpage) return;
	
	var descriptionpage = validationInput('empty', '#descriptionpage', diverror, txt_enter_description, bsubmit, false);
	if (!descriptionpage) return;

	paramsArray[2] = diverror;
    paramsArray[3] = bsubmit;
    
    var data = {
        pic: idcategory,
        pisc: idsubcategory,
        pti: titlepage,
        pur: urlpage,
        pds: descriptionpage,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspages',
            action: 'create',
            cancelable: 0,
            data: data
    };

    invoke(params, createPage_Ok, createPage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function updatePage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[2], response.message, 1700)
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlpage, 'dashboard-main-area', 'max');
            break;            
    }
}

function updatePage_Error(response) {
    "use strict";
    openandclose(paramsArray[2], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
}

function updatePage(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
    
	var idcategory = validationInput('positive', '#categorypage', diverror, txt_choose_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategorypage', diverror, txt_choose_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var titlepage = validationInput('empty', '#titlepage', diverror, txt_enter_title, bsubmit, false);
	if (!titlepage) return;
	
	var urlpage = validationInput('empty', '#urlpage', diverror, txt_enter_url, bsubmit, false);
	if (!urlpage) return;
    
	var urlpage = validationInput('pageorgroup', '#urlpage', diverror, txt_url_invalid, bsubmit, false);
	if (!urlpage) return;
	
	var descriptionpage = validationInput('empty', '#descriptionpage', diverror, txt_enter_description, bsubmit, false);
	if (!descriptionpage) return;

	paramsArray[2] = diverror;
    paramsArray[3] = bsubmit;
    
    var data = {
        pic: idcategory,
        pisc: idsubcategory,
        pti: titlepage,
        pur: urlpage,
        pds: descriptionpage,
        cpg: cpg,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspages',
            action: 'update',
            cancelable: 0,
            data: data
    };

    invoke(params, updatePage_Ok, updatePage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deletePage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'pages', 'dashboard-main-area', 'max');
            break;            
    }
}

function deletePage_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deletePage(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: codepage,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspages',
            action: 'delete',
            cancelable: 0,
            data: data
    }

    invoke(params, deletePage_Ok, deletePage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function searchPage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preloadsearch').hide();
            openandclose(paramsArray[2], response.message, 1700)
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $('#preloadsearch').hide();
            $('#space-result-search-page').html(response.theresult);
            $('#space-result-search-page').show();
            setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
            break;            
    }
}

function searchPage_Error(response) {
    "use strict";
    $('#preloadsearch').hide();
    openandclose(paramsArray[2], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[3]).removeAttr('disabled'); }, 2500);
}

function searchPage(diverror, bsubmit) {
    "use strict";
    $('#space-result-search-page').html('');
        
	$(bsubmit).attr('disabled','true');
    $('#preloadsearch').show();
    
	var termsearch = validationInput('empty', '#termsearch', diverror, txt_error_empty_term, bsubmit, true);
	if (!termsearch) return;
    
    if ($.trim($('#termsearch').val()).length <= 3) {
        openandclose(diverror, txt_error_short_term, 1700);		
        $('#termsearch').focus();
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500); 
        return;
    }

	paramsArray[2] = diverror;
    paramsArray[3] = bsubmit;
    
    var data = {
        tse: termsearch,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspages',
            action: 'search',
            cancelable: 0,
            data: data
    };

    invoke(params, searchPage_Ok, searchPage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function saveRepositionBG_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            break;            
    }
}

function saveRepositionBG_Error(response) {
}

function saveRepositionBG(posibg) {
    "use strict";
    var data = {
        posi: posibg,
        typr: _tp,
        copr: _cp,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssettingprofile',
            action: 'positionbgcover',
            cancelable: 0,
            data: data
    };

    invoke(params, saveRepositionBG_Ok, saveRepositionBG_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function removeCover_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $('#cover-header').removeClass('with_cover');
            $('#cover-header').addClass('cover_temporal');
            $('#cover-header').css('background-image', 'url(' + response.space_cover_header + ')');
            $('#space-cover-header').html('<div id="shadow-header-temporal"></div>');
            $('#move-bg-header').hide();
            $('#remove-bg-header').hide();
            break;            
    }
    $('#actions-cover').show();
}

function removeCover_Error(response) {
    "use strict";
    $('#actions-cover').show();
}

function removeCover(n) {
    "use strict";
    $('#actions-cover').hide();
    
    var data = {
        typr: _tp,
        copr: _cp,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssettingprofile',
            action: 'removecover',
            cancelable: 0,
            data: data
    };

    invoke(params, removeCover_Ok, removeCover_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function uploadCoverNew_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-actions-cover').hide();
            $('#actions-cover').show();
            
            break;
    
        case 'OK':
            $('#preload-actions-cover').hide();
            $('#cover-header').addClass('with_cover');
            $('#space-cover-header').html(response.space_cover_header);
    
            $('#move-bg-header').show();
            $('#remove-bg-header').show();
    
            $('#link-cover').show();
            $('#actions-cover').show();
            
            break;            
    }
}

function uploadCoverNew_Error(response) {
    "use strict";
    $('#preload-actions-cover').hide();
    $('#actions-cover').show();
}

function uploadCoverNew() {
    "use strict";
    $('#actions-cover').hide();

    var thefilecover = filecover;
    if (thefilecover == null) {
        _alert(msg_alert_cover_empty);
        $('#actions-cover').show();
        return;
    }

    if (thefilecover != '') {
        var ext = thefilecover.name.split('.').pop().toLowerCase();
        if($.inArray(ext, ['jpg', 'png']) == -1) {
            _alert(msg_alert_cover_format);
            $('#actions-cover').show();
            return;
        }
    }
    
    if (thefilecover.size > sizeCover) {
        _alert(msg_alert_cover_large);
        $('#actions-cover').show();
        return;
    }

    var data_cover = new FormData(document.getElementById("form-cover-new"));
    data_cover.append("the_cover_new", filecover);
    data_cover.append("type_profile", _tp);
    data_cover.append("code_profile", _cp);

    var params = {
            type: 'POST',
            withFile: true,
            module:  'actionssettingprofile',
            action: 'uploadcover',
            cancelable: 0,
            data: data_cover
    }
    
    $('#preload-actions-cover').show();

    invoke(params, uploadCoverNew_Ok, uploadCoverNew_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function removeAvatar_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#icon-remove-avatar').show();
            break;
    
        case 'OK':
            $('#space-avatar-header').html(response.space_avatar);
            $('#opt-user-top .the_avatar img').attr('src', response.icoavatartop);
            break;            
    }
}

function removeAvatar_Error(response) {
    "use strict";
    $('#icon-remove-avatar').show();
}

function removeAvatar(n) {
    "use strict";
    $('#icon-remove-avatar').hide();
    
    var data = {
        typr: _tp,
        copr: _cp,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssettingprofile',
            action: 'removeavatar',
            cancelable: 0,
            data: data
    };

    invoke(params, removeAvatar_Ok, removeAvatar_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function uploadAvatarNew_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-actions-avatar').hide();
            $('#icon-upload-avatar').show();
            break;
    
        case 'OK':
            $('#preload-actions-avatar').hide();
            $('#space-avatar-header').html(response.space_avatar);
            $('#opt-user-top .the_avatar img').attr('src', response.icoavatartop);
            $('#icon-remove-avatar').show();
            $('#icon-upload-avatar').show();
            break;            
    }
}

function uploadAvatarNew_Error(response) {
    "use strict";
    $('#preload-actions-avatar').hide();
    $('#icon-upload-avatar').show();
}

function uploadAvatarNew() {
    "use strict";
    $('#preload-actions-avatar').show();
    $('#icon-upload-avatar').hide();

    var thefileavatar = fileavatar;
    if (thefileavatar == null) {
        _alert(msg_alert_avatar_empty);
        $('#preload-actions-avatar').hide();
        $('#icon-upload-avatar').show();
        return;
    }

    if (thefileavatar != '') {
        var ext = thefileavatar.name.split('.').pop().toLowerCase();
        if($.inArray(ext, ['jpg', 'png']) == -1) {
            _alert(msg_alert_avatar_format);
            $('#preload-actions-avatar').hide();
            $('#icon-upload-avatar').show();
            return;
        }
    }
    
    if (thefileavatar.size > sizeAvatar) {
        _alert(msg_alert_avatar_large);
        $('#preload-actions-avatar').hide();
        $('#icon-upload-avatar').show();
        return;
    }

    var data_avatar = new FormData(document.getElementById("form-avatar-new"));
    data_avatar.append("the_avatar_new", fileavatar);
    data_avatar.append("type_profile", _tp);
    data_avatar.append("code_profile", _cp);

    var params = {
            type: 'POST',
            withFile: true,
            module:  'actionssettingprofile',
            action: 'uploadavatar',
            cancelable: 0,
            data: data_avatar
    };

    invoke(params, uploadAvatarNew_Ok, uploadAvatarNew_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message); 
            break;
        case 'OK':
            $("#activity_" + response.codepost).fadeOut(500, function() { $("#activity_" + response.codepost).remove(); });
            break;            
    }
}

function deleteActivity_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function deleteActivity(code){
    "use strict";
    var data = {
        cod: code,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteActivity_Ok, deleteActivity_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function updateActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#edit_preload_' + response.codepost).hide();
            $('#edit_actions_' + response.codepost).show();
            _alert(response.message);
            break;
        case 'OK':
            $('#space_txt_message_' + response.codepost).html(response.newmsg);
            $('#space_edit_message_' + response.codepost).hide();
            $('#space_txt_message_' + response.codepost).show();
            $('#edit_preload_' + response.codepost).hide();
            $('#edit_actions_' + response.codepost).show();
            $('#space_edit_message_' + response.codepost + ' textarea').val(response.newmsg_raw);
            $('#tmp_edit_' + response.codepost).val(response.newmsg_raw);
            break;            
    }
}

function updateActivity_Error(response) {}

function updateActivity(code){
    "use strict";
    $('#edit_actions_' + code).hide();
    $('#edit_preload_' + code).show();
    
    var message = $('#space_edit_message_' + code + ' textarea').val();
    message = $.trim(message);
    if (message == '') {
        $('#edit_preload_' + code).hide();
        $('#edit_actions_' + code).show();
        _alert(msg_alert_edit_empty);
        return;
    };
    
    var data = {
        cod: code,
        msg: message,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'update',
            cancelable: 0,
            data: data
    };

    invoke(params, updateActivity_Ok, updateActivity_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function hideActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
        case 'OK':
            $("#activity_" + response.codepost).fadeOut(500, function() { $("#activity_" + response.codepost).remove(); });
            break;            
    }
}

function hideActivity_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function hideActivity(code){
	"use strict";
    var data = {
        cod: code,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'hide',
            cancelable: 0,
            data: data
    };

    invoke(params, hideActivity_Ok, hideActivity_Error);
}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function reportActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
        case 'OK':
            $('#optma_report_' + response.codepost).remove();
            _alert(response.html);
            break;            
    }
}

function reportActivity_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function reportActivity(codepost, valuereturn) {
    "use strict";
	valuereturn = $.trim(valuereturn);
    if (valuereturn == '') return false;

    var data = {
        cod: codepost,
        reason: valuereturn,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'report',
            cancelable: 0,
            data: data
    };

    invoke(params, reportActivity_Ok, reportActivity_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function saveActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
        case 'OK':
            $('#optma_save_' + response.codepost).hide();
            $('#optma_unsave_' + response.codepost).show();
            _alert(response.html);
            break;            
    }
}

function saveActivity_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function saveActivity(codepost) {
    "use strict";
    var data = {
        cod: codepost,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'saved',
            cancelable: 0,
            data: data
    };

    invoke(params, saveActivity_Ok, saveActivity_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unSaveActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
        case 'OK':
            $('#optma_save_' + response.codepost).show();
            $('#optma_unsave_' + response.codepost).hide();
            _alert(response.html);
            break;            
    }
}

function unSaveActivity_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function unSaveActivity(codepost) {
    "use strict";
    var data = {
        cod: codepost,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'unsaved',
            cancelable: 0,
            data: data
    };

    invoke(params, unSaveActivity_Ok, unSaveActivity_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unReportActivity_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
        case 'OK':
            $('#optma_ureport_' + response.codepost).remove();
            _alert(response.html);
            break;            
    }
}

function unReportActivity_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function unReportActivity(codepost) {
    "use strict";
    var data = {
        cod: codepost,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'unreport',
            cancelable: 0,
            data: data
    };

    invoke(params, unReportActivity_Ok, unReportActivity_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function likedPost_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-like-' + paramsArray[0]).hide();
            $('#space-like-' + paramsArray[0]).show();
            _alert(response.message);
            break;
        case 'OK':
            var code = response.codepost;
            var numlikes;
            var status_like = $('#status-like-' + code).val();
            if (status_like == '0') {
                $('#status-like-' + code).val('1');
                $('#action-like-' + code + ' .act-text').addClass('active');
                $('#action-like-' + code + ' img').attr('height', 17);
                $('#action-like-' + code + ' img').attr('width', 17);
                $('#action-like-' + code + ' img').attr('src', _SITE_URL + 'themes/' + _THEME + '/imgs/post-ico-like-active.png');
                numlikes = $('#activity_' + code + ' .activity_num_likes').html();
                numlikes = parseInt(numlikes) + 1;
                $('#activity_' + code + ' .activity_num_likes').html(numlikes);
                if (numlikes == 1) $('#activity_' + code + ' .ba-nums-likes').show();
            }
            if (status_like == '1') {
                $('#status-like-' + code).val('0');
                $('#action-like-' + code + ' .act-text').removeClass('active');
                $('#action-like-' + code + ' img').attr('height', 17);
                $('#action-like-' + code + ' img').attr('width', 17);
                $('#action-like-' + code + ' img').attr('src', _SITE_URL + 'themes/' + _THEME + '/imgs/post-ico-like.png');
                numlikes = $('#activity_' + code + ' .activity_num_likes').html();
                numlikes = parseInt(numlikes) - 1;
                $('#activity_' + code + ' .activity_num_likes').html(numlikes);
                if (numlikes == 0) $('#activity_' + code + ' .ba-nums-likes').hide();
            }
    
            $('#preload-like-' + code).hide();
            $('#space-like-' + code).show();
            break;            
    }
}

function likedPost_Error(response) {
    "use strict";
    $('#preload-like-' + paramsArray[0]).hide();
    $('#space-like-' + paramsArray[0]).show();
    alert(msg_error_conection);
}

function likedPost(code){
    "use strict";
    $('#space-like-' + code).hide();
    $('#preload-like-' + code).show();

	paramsArray[0] = code;

    var data = {
        cod: code,
        sts: $('#status-like-' + code).val(),
        cvis: $('#code_visit_' + code).val(),
        tvis: $('#type_visit_' + code).val(),
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'like',
            cancelable: 0,
            data: data
    };

    invoke(params, likedPost_Ok, likedPost_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function sharePost_Ok(response) {
    "use strict";
    var code;
    switch (response.status) {
        case 'ERROR':
            code = response.codepost;
            $('#preload-like-' + code).hide();
            $('#space-like-' + code).show();
            _alert(response.message);
            
            break;
        case 'OK':
            code = response.codepost;
            $("#share_ok_" + paramsArray[0]).html(response.msgok);
            $("#activity_" + paramsArray[0] + " .space-for-share-post").slideUp('low',function(){
                $("#share_ok_" + paramsArray[0]).slideDown('low');
            });
            setTimeout(function(){
                $("#share_ok_" + paramsArray[0]).slideUp('low',function(){
                    $("#activity_" + paramsArray[0] + " .space-icons-actions").slideDown('low');
                    $("#share-msg-post-" + code + paramsArray[0]).val('');
                    $('#share_preload_' + paramsArray[0]).hide();
                    $('#share_actions_' + paramsArray[0]).show();
                });
            }, 3000);
            
            break;            
    }
}

function sharePost_Error(response) {
    "use strict";
    $('#share_preload_' + paramsArray[0]).hide();
    $('#share_actions_' + paramsArray[0]).show();
    alert(msg_error_conection);
}

function sharePost(code, container){
    "use strict";
    $('#share_actions_' + code).hide();
    $('#share_preload_' + code).show();

	paramsArray[0] = container;

    var data = {
        cod: code,
        shfw: $('#sh_for_who_' + code).val(),
        shcwr: $('#sh_code_writer_' + code).val(),
        shtw: $('#sh_type_writer_' + code).val(),
        shpi: $('#sh_posted_in_' + code).val(),
        shcwl: $('#sh_code_wall_' + code).val(),
        shmsg: $("#share-msg-post-" + code + container).val(),
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'share',
            cancelable: 0,
            data: data
    };

    invoke(params, sharePost_Ok, sharePost_Error);
}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function commentPost_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message); 
            break;
        case 'OK':
            let numcomms = parseInt($('#numcomms_' + paramsArray[0]).val()) + 1;
            $('#numcomms_' + paramsArray[0]).val(numcomms);
            
            $('#comments-news-' + paramsArray[0]).append(response.newcomment);
            $('#info-attach-file-' + paramsArray[0]).html('');
            $('#space-attach-file-' + paramsArray[0]).hide();
            $('#button-attach-comment-' + paramsArray[0]).show();
            $('#attach-comment-' + paramsArray[0]).val('');
            $('#textarea-comment-' + paramsArray[0]).val('');
            $('#textarea-comment-' + paramsArray[0]).height('16px');
            break;            
    }
    $('#preload-input-comment-' + paramsArray[0]).hide();
    $('#space-input-comment-' + paramsArray[0]).show();
}

function commentPost_Error(response) {
    "use strict";
    $('#preload-input-comment-' + paramsArray[0]).hide();
    $('#space-input-comment-' + paramsArray[0]).show();
    alert(msg_error_conection);
}

function commentPost(code){
    "use strict";
    $('#space-input-comment-' + code).hide();
    $('#preload-input-comment-' + code).show();
    
    paramsArray[0] = code;
    
    var formData = new FormData(document.getElementById("form-comment-" + code));
    formData.append("codepost", code);
    formData.append("msgcomment", $('#textarea-comment-' + code).val());
    formData.append("code_writer", $('#cm_code_writer_' + code).val());
    formData.append("type_writer", $('#cm_type_writer_' + code).val());
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionspost',
            action: 'newcomment',
            cancelable: 0,
            data: formData
    };

    invoke(params, commentPost_Ok, commentPost_Error);
}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteComment_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message); 
            $('#delete-comment-' + paramsArray[0]).show();
            break;
        case 'OK':
            let typeitem = response.typeitem;
            let codepost = response.codepost;
            if (typeitem == 0) {
                let numcomms = parseInt($('#numcomms_' + codepost).val()) - 1;
                $('#numcomms_' + codepost).val(numcomms);
            }
            $("#comment-post-" + paramsArray[0]).fadeOut(500, function() { $("#comment-post-" + paramsArray[0]).remove(); });
            break;            
    }
}

function deleteComment_Error(response) {
    "use strict";
    alert(msg_error_conection); 
    $('#delete-comment-' + paramsArray[0]).show();
}

function deleteComment(idcomment){
    "use strict";
    paramsArray[0] = idcomment;
    
    var data = {
        idc: idcomment,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'deletecomment',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteComment_Ok, deleteComment_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function commentMedia_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message); 
            break;
        case 'OK':
            $('#textarea-comment-media-' + paramsArray[0]).val('');
            $('#comments-media-news-' + paramsArray[0]).append(response.newcomment);
            $('#textarea-comment-media-' + paramsArray[0]).height('16px');
            break;            
    }
}

function commentMedia_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function commentMedia(code){
    "use strict";
    paramsArray[0] = code;
    
    var data = {
        cod: code,
        msg: $('#textarea-comment-media-' + code).val(),
        cwr: cmm_code_writer,
        twr: cmm_type_writer,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsmedia',
            action: 'newcomment',
            cancelable: 0,
            data: data
    };

    invoke(params, commentMedia_Ok, commentMedia_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function likedMedia_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-like-media-' + paramsArray[0]).hide();
            $('#space-like-media-' + paramsArray[0]).show();
            _alert(response.message);
            break;
        case 'OK':
            var code = response.codemedia;
            var status_like = $('#status-like-media-' + code).val();
            var numlikes;
            if (status_like == '0') {
                $('#status-like-media-' + code).val('1');
                $('#action-like-media-' + code + ' img').attr('height', 17);
                $('#action-like-media-' + code + ' img').attr('width', 17);
                $('#action-like-media-' + code + ' .act-text').addClass('active');
                $('#action-like-media-' + code + ' img').attr('src', _SITE_URL + 'themes/' + _THEME + '/imgs/post-ico-like-active.png');
                numlikes = $('#media-' + code + ' .media_num_likes').html();
                numlikes = parseInt(numlikes) + 1;
                $('#media-' + code + ' .media_num_likes').html(numlikes);
                if (numlikes == 1) $('#media-' + code + ' .zo-nums-likes').show();
            }
            if (status_like == '1') {
                $('#status-like-media-' + code).val('0');
                $('#action-like-media-' + code + ' img').attr('height', 17);
                $('#action-like-media-' + code + ' img').attr('width', 17);
                $('#action-like-media-' + code + ' .act-text').removeClass('active');
                $('#action-like-media-' + code + ' img').attr('src', _SITE_URL + 'themes/' + _THEME + '/imgs/post-ico-like.png');
                numlikes = $('#media-' + code + ' .media_num_likes').html();
                numlikes = parseInt(numlikes) - 1;
                $('#media-' + code + ' .media_num_likes').html(numlikes);
                if (numlikes == 0) $('#media-' + code + ' .zo-nums-likes').hide();
            }
    
            $('#preload-like-media-' + code).hide();
            $('#space-like-media-' + code).show();
            break;            
    }
}

function likedMedia_Error(response) {
    "use strict";
    $('#preload-like-media-' + paramsArray[0]).hide();
    $('#space-like-media-' + paramsArray[0]).show();
    alert(msg_error_conection);
}

function likedMedia(code){
    "use strict";
    $('#space-like-media-' + code).hide();
    $('#preload-like-media-' + code).show();
    
	paramsArray[0] = code;

    var data = {
        cod: code,
        sts: $('#status-like-media-' + code).val(),
        cvis: cmm_code_writer,
        tvis: cmm_type_writer,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsmedia',
            action: 'like',
            cancelable: 0,
            data: data
    };

    invoke(params, likedMedia_Ok, likedMedia_Error);
}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function joinedGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#area-action-join').show();
            break;
    
        case 'OK':
            $('#area-action-join').hide();
            $('#area-action-pending').show();
            break;
    }
    $('#preload-b-action').hide();
}

function joinedGroup_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-join').show();
}

function joinedGroup() {
    "use strict";
    $('#area-action-join').hide();
    $('#preload-b-action').show();

    var data = {
        cgroup: cgroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsingroup',
            action: 'join',
            cancelable: 0,
            data: data
    };

    invoke(params, joinedGroup_Ok, joinedGroup_Error);

}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function cancelRequest_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-pending').show();
            break;
    
        case 'OK':
            $('#area-action-pending').hide();
            $('#area-action-join').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function cancelRequest_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-pending').show();
}

function cancelRequest() {
    "use strict";
    $('#area-action-pending').hide();
    $('#preload-b-action').show();

    var data = {
        cgroup: cgroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsingroup',
            action: 'cancelrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, cancelRequest_Ok, cancelRequest_Error);

}


/*__________________________________________________________________*/
/*__________________________________________________________________*/

function leaveGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-joined').show();
            break;
    
        case 'OK':
            $('#area-action-joined').hide();
            $('#area-action-join').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function leaveGroup_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-joined').show();
}

function leaveGroup() {
    "use strict";
    $('#area-action-joined').hide();
    $('#preload-b-action').show();

    var data = {
        cgroup: cgroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsingroup',
            action: 'leavegroup',
            cancelable: 0,
            data: data
    };

    invoke(params, leaveGroup_Ok, leaveGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function declineRequestGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $('#member-' + paramsArray[0]).fadeOut();
            break;
    }
}

function declineRequestGroup_Error(response) {
}

function declineRequestGroup(codeuser, codegroup) {
    "use strict";
    paramsArray[0] = codeuser;

    var data = {
        cuser: codeuser,
        cgroup: codegroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsingroup',
            action: 'declinerequest',
            cancelable: 0,
            data: data
    };

    invoke(params, declineRequestGroup_Ok, declineRequestGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function approveRequestGroup_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $('#actions-in-request-' + paramsArray[0]).slideUp('fast', function(){
                $('#ok-request-' + paramsArray[0]).slideDown('fast');
            });
            break;
    }
}

function approveRequestGroup_Error(response) {
}

function approveRequestGroup(codeuser, codegroup) {
    "use strict";
    paramsArray[0] = codeuser;

    var data = {
        cuser: codeuser,
        cgroup: codegroup,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsingroup',
            action: 'approverequest',
            cancelable: 0,
            data: data
    };

    invoke(params, approveRequestGroup_Ok, approveRequestGroup_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function likePage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-like').show();
            break;
    
        case 'OK':
            $('#area-action-like').hide();
            $('#area-action-liked').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function likePage_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-like').show();
}

function likePage() {
    "use strict";
    $('#area-action-like').hide();
    $('#preload-b-action').show();

    var data = {
        cpage: cpage,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinpage',
            action: 'like',
            cancelable: 0,
            data: data
    };

    invoke(params, likePage_Ok, likePage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unlikePage_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-liked').show();
            break;
    
        case 'OK':
            $('#area-action-liked').hide();
            $('#area-action-like').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function unlikePage_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-liked').show();
}

function unlikePage() {
    "use strict";
    $('#area-action-liked').hide();
    $('#preload-b-action').show();

    var data = {
        cpage: cpage,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinpage',
            action: 'unlike',
            cancelable: 0,
            data: data
    };

    invoke(params, unlikePage_Ok, unlikePage_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function addFriend_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-addfriend').show();
            break;
    
        case 'OK':
            $('#area-action-addfriend').hide();
            $('#area-action-requestsent').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function addFriend_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-addfriend').show();
}

function addFriend() {
    "use strict";
    $('#area-action-addfriend').hide();
    $('#preload-b-action').show();

    var data = {
        cuser: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'addfriend',
            cancelable: 0,
            data: data
    };

    invoke(params, addFriend_Ok, addFriend_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function cancelFriendRequest_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#area-action-requestsent').show();
            break;
    
        case 'OK':
            $('#area-action-requestsent').hide();
            $('#area-action-addfriend').show();
            break;
    }
    $('#preload-b-action').hide();
}

function cancelFriendRequest_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-requestsent').show();
}

function cancelFriendRequest() {
    "use strict";
    $('#area-action-requestsent').hide();
    $('#preload-b-action').show();

    var data = {
        cuser: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'cancelfriendrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, cancelFriendRequest_Ok, cancelFriendRequest_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteFriendRequest_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#area-action-answerrequest').show();
            break;
    
        case 'OK':
            $('#area-action-answerrequest').hide();
            $('#area-action-addfriend').show();
            break;
    }
    $('#preload-b-action').hide();
}

function deleteFriendRequest_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-answerrequest').show();
}

function deleteFriendRequest() {
    "use strict";
    $('#area-action-answerrequest').hide();
    $('#preload-b-action').show();

    var data = {
        cuser: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'deletefriendrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteFriendRequest_Ok, deleteFriendRequest_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function confirmFriendRequest_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#area-action-answerrequest').show();
            break;
    
        case 'OK':
            $('#area-action-answerrequest').hide();
            $('#area-action-friends').show();
            break;
    }
    $('#preload-b-action').hide();
}

function confirmFriendRequest_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-answerrequest').show();
}

function confirmFriendRequest() {
    "use strict";
    $('#area-action-answerrequest').hide();
    $('#preload-b-action').show();

    var data = {
        cuser: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'confirmfriendrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, confirmFriendRequest_Ok, confirmFriendRequest_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unFriend_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
    
            $('#area-action-friends').show();
            break;
    
        case 'OK':
            $('#area-action-friends').hide();
            $('#area-action-addfriend').show();
    
            break;
    }
    $('#preload-b-action').hide();
}

function unFriend_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-friends').show();
}

function unFriend() {
    "use strict";
    $('#area-action-friends').hide();
    $('#preload-b-action').show();

    var data = {
        cuser: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'unfriend',
            cancelable: 0,
            data: data
    };

    invoke(params, unFriend_Ok, unFriend_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function confirmRequestFriend_Notif_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-notif-' + paramsArray[0]).hide();
            $('#buttons-actions-' + paramsArray[0]).show();
            break;
    
        case 'OK':
            $('#buttons-actions-' + paramsArray[0]).hide();
            $('#preload-notif-' + paramsArray[0]).hide();
            $('#btn-friends-' + paramsArray[0]).show();
            break;
    }
}

function confirmRequestFriend_Notif_Error(response) {
    "use strict";
    $('#preload-notif-' + paramsArray[0]).hide();
    $('#buttons-actions-' + paramsArray[0]).show();
}

function confirmRequestFriend_Notif(idnotif, codeuser) {
    "use strict";
    $('#buttons-actions-' + idnotif).hide();
    $('#preload-notif-' + idnotif).show();

    paramsArray[0] = idnotif;

    var data = {
        idn: idnotif,
        cdu: codeuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinnotif',
            action: 'confirmfriendrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, confirmRequestFriend_Notif_Ok, confirmRequestFriend_Notif_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteRequestFriend_Notif_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-notif-' + paramsArray[0]).hide();
            $('#buttons-actions-' + paramsArray[0]).show();
            break;
    
        case 'OK':
            $('#buttons-actions-' + paramsArray[0]).hide();
            $('#preload-notif-' + paramsArray[0]).hide();
            $('#notif-people-' + paramsArray[0]).fadeOut();
            break;
    }
}

function deleteRequestFriend_Notif_Error(response) {
    "use strict";
    $('#preload-notif-' + paramsArray[0]).hide();
    $('#buttons-actions-' + paramsArray[0]).show();
}

function deleteRequestFriend_Notif(idnotif, codeuser) {
    "use strict";
    $('#buttons-actions-' + idnotif).hide();
    $('#preload-notif-' + idnotif).show();

    paramsArray[0] = idnotif;

    var data = {
        idn: idnotif,
        cdu: codeuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinnotif',
            action: 'deletefriendrequest',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteRequestFriend_Notif_Ok, deleteRequestFriend_Notif_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function insertStickerComment_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            $('#comments-news-' + paramsArray[0]).append(response.newcomment);
            break;
    }
    $('#preload-input-comment-' + paramsArray[0]).hide();
    $('#space-input-comment-' + paramsArray[0]).show();
}

function insertStickerComment_Error(response) {
    "use strict";
    $('#preload-input-comment-' + paramsArray[0]).hide();
    $('#space-input-comment-' + paramsArray[0]).show();
    alert(msg_error_conection);
}

function insertStickerComment(code, sticker) {
    "use strict";
    $('#bstickerscom-' + code).next('.menustickers-comment').toggle();
    
    $('#space-input-comment-' + code).hide();
    $('#preload-input-comment-' + code).show();

    paramsArray[0] = code;

    var formData = new FormData(document.getElementById("form-comment-" + code));
    formData.append("codepost", code);
    formData.append("msgcomment", sticker);
    formData.append("code_writer", $('#cm_code_writer_' + code).val());
    formData.append("type_writer", $('#cm_type_writer_' + code).val());
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionspost',
            action: 'newstickercomment',
            cancelable: 0,
            data: formData
    };

    invoke(params, insertStickerComment_Ok, insertStickerComment_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function insertStickerCommentMedia_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            $('#comments-media-news-' + paramsArray[0]).append(response.newcomment);
            break;
    }
}

function insertStickerCommentMedia_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function insertStickerCommentMedia(code, sticker) {
    "use strict";
    $('#bstickerscommed-' + code).next('.menustickers-comment').toggle();
    
    paramsArray[0] = code;

    var data = {
        cod: code,
        msg: sticker,
        cwr: cmm_code_writer,
        twr: cmm_type_writer,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsmedia',
            action: 'newstickercommentmedia',
            cancelable: 0,
            data: data
    };

    invoke(params, insertStickerCommentMedia_Ok, insertStickerCommentMedia_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function insertSmiles(areaText, stringEmo) {
    "use strict";
	var item_dom = document.getElementsByName(areaText)[0];
	if (document.selection) {
		item_dom.focus();
		var sel = document.selection.createRange();
		sel.text = ' ' + stringEmo + ' ';
		return;
	}
	
	if (item_dom.selectionStart || item_dom.selectionStart == "0") {
		var t_start = item_dom.selectionStart;
		var t_end = item_dom.selectionEnd;
		var val_start = item_dom.value.substring(0, t_start);
		var val_end = item_dom.value.substring(t_end, item_dom.value.length);
		item_dom.value = val_start + ' ' + stringEmo + ' ' + val_end;
	} else item_dom.value += ' ' + stringEmo + ' ';
	
	//item_dom.focus(); 
}

$(document).on('click', '.ico-smiles', function() {
    $(this).next('.menusmiles').toggle();
});

$(document).on('click', function(e) {
    if ($(e.target).hasClass('ico-smiles') || $(e.target).parents('.ico-smiles').length > 0 || $(e.target).hasClass('menusmiles') || $(e.target).parents('.menusmiles').length > 0) return;
    $('.menusmiles').hide();
});

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function blockUser_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            loadFriendsOnline();
            _SPACE_FULL = true;
            actionOnClick(_SITE_URL + 'settings/blocked', 'dashboard-main-area', 'max');
            break;
    }
}

function blockUser_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function blockUser() {
    "use strict";
    var data = {
        cod: cuser,
    }
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'blockuser',
            cancelable: 0,
            data: data
    }

    invoke(params, blockUser_Ok, blockUser_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unBlockUser_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            loadFriendsOnline();
            $("#user_blocked_" + paramsArray[0]).fadeOut(500, function() { $("#user_blocked_" + paramsArray[0]).remove(); });
            break;
    }
}

function unBlockUser_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function unBlockUser(cuser) {
    "use strict";
    var data = {
        cod: cuser,
    };
 
    paramsArray[0] = cuser;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionssetting',
            action: 'unblockuser',
            cancelable: 0,
            data: data
    };

    invoke(params, unBlockUser_Ok, unBlockUser_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function reportUser_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            $('#breportuser').remove();
            _alert(response.html);
            break;
    }
}

function reportUser_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function reportUser(divreason, valuereturn) {
    "use strict";
	valuereturn = $.trim(valuereturn);
    if (valuereturn == '') return false;

    var data = {
        cod: cuser,
        reason: valuereturn,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'reportuser',
            cancelable: 0,
            data: data
    };

    invoke(params, reportUser_Ok, reportUser_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function unReportUser_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            $('#bunreported').remove();
            _alert(response.html);
            break;
    }
}

function unReportUser_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function unReportUser() {
    "use strict";
    var data = {
        cod: cuser,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinprofile',
            action: 'unreportuser',
            cancelable: 0,
            data: data
    };

    invoke(params, unReportUser_Ok, unReportUser_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function changeTypePost_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            _alert(response.message);
            break;
    
        case 'OK':
            $('#theicon_' + paramsArray[0]).attr('src', response.theicon);
            $('#amwh_' + paramsArray[0]).hide();
            break;
    }
}

function changeTypePost_Error(response) {
    "use strict";
    alert(msg_error_conection); 
}

function changeTypePost(thecode, thetype) {
    "use strict";
    var data = {
        cod: thecode,
        typ: thetype,
    };
 
    paramsArray[0] = thecode;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionspost',
            action: 'changetype',
            cancelable: 0,
            data: data
    };

    invoke(params, changeTypePost_Ok, changeTypePost_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadPostsInit_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
        case 'OK':
            $('#the-posts-init').html(response.listactivities);
            $('#the-show-more').html(response.showmore);
            $('video.js_video-js').each(function(){ videojs($(this)[0], {}, function() {}); });
            $('audio.mep_audio').mediaelementplayer();
            activeSlimScrollers();
            $('.action_autosize').each(function(){
                autosize(this);
            });
            
            break;            
    }
}

function loadPostsInit_Error() {}

function loadPostsInit() {
    "use strict";

    var data = {};
    
    var params = {
        type: 'POST',
        withFile: false,
        module: 'drawsections',
        action: 'postsinit',
        cancelable: 1,
        data: data
    };

    invoke(params, loadPostsInit_Ok, loadPostsInit_Error);
    
}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadSavedPostInit_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
        case 'OK':
            $('#the-posts-init').html(response.listactivities);
            $('#the-show-more').html(response.showmore);
            $('video.js_video-js').each(function(){ videojs($(this)[0], {}, function() {}); });
            $('audio.mep_audio').mediaelementplayer();
            activeSlimScrollers();
            $('.action_autosize').each(function(){
                autosize(this);
            }) 
            break;            
    }
}

function loadSavedPostInit_Error() {}

function loadSavedPostInit() {
    "use strict";
    
    var data = {};
    
    var params = {
        type: 'POST',
        withFile: false,
        module: 'drawsections',
        action: 'savedpostinit',
        cancelable: 1,
        data: data
    };

    invoke(params, loadSavedPostInit_Ok, loadSavedPostInit_Error);
    
}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function createEvent_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlevent, 'dashboard-main-area', 'max');
            break;            
    }
}

function createEvent_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createEvent(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
	
	var nameevent = validationInput('empty', '#titleevent', diverror, txt_enter_name, bsubmit, false);
	if (!nameevent) return;
	
	var locationevent = validationInput('empty', '#locationevent', diverror, txt_enter_location, bsubmit, false);
	if (!locationevent) return;

	var datestart = validationInput('empty', '#datestart', diverror, txt_enter_datestart, bsubmit, false);
	if (!datestart) return;

	var timestart = validationInput('empty', '#timestart', diverror, txt_enter_timestart, bsubmit, false);
	if (!timestart) return;

	var dateend = validationInput('empty', '#dateend', diverror, txt_enter_dateend, bsubmit, false);
	if (!dateend) return;

	var timeend = validationInput('empty', '#timeend', diverror, txt_enter_timeend, bsubmit, false);
	if (!timeend) return;
    
	var descriptionevent = validationInput('empty', '#descriptionevent', diverror, txt_enter_description, bsubmit, false);
	if (!descriptionevent) return;
	
	paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var data = {
        ena: nameevent,
        elo: locationevent,
        ede: descriptionevent,
        dts: datestart,
        tms: timestart,
        dte: dateend,
        tme: timeend,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsevents',
            action: 'create',
            cancelable: 0,
            data: data
    };

    invoke(params, createEvent_Ok, createEvent_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function updateEvent_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            _SPACE_FULL = true;
            actionOnClick(response.urlevent, 'dashboard-main-area', 'max');
            break;            
    }
}

function updateEvent_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateEvent(diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');
	
	var nameevent = validationInput('empty', '#titleevent', diverror, txt_enter_name, bsubmit, false);
	if (!nameevent) return;
	
	var locationevent = validationInput('empty', '#locationevent', diverror, txt_enter_location, bsubmit, false);
	if (!locationevent) return;
    
	var datestart = validationInput('empty', '#datestart', diverror, txt_enter_datestart, bsubmit, false);
	if (!datestart) return;

	var timestart = validationInput('empty', '#timestart', diverror, txt_enter_timestart, bsubmit, false);
	if (!timestart) return;

	var dateend = validationInput('empty', '#dateend', diverror, txt_enter_dateend, bsubmit, false);
	if (!dateend) return;

	var timeend = validationInput('empty', '#timeend', diverror, txt_enter_timeend, bsubmit, false);
	if (!timeend) return;
    
	var descriptionevent = validationInput('empty', '#descriptionevent', diverror, txt_enter_description, bsubmit, false);
	if (!descriptionevent) return;

	paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var data = {
        code: codev,
        ena: nameevent,
        elo: locationevent,
        ede: descriptionevent,
        dts: datestart,
        tms: timestart,
        dte: dateend,
        tme: timeend,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsevents',
            action: 'update',
            cancelable: 0,
            data: data
    };

    invoke(params, updateEvent_Ok, updateEvent_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteEvent_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'myevents', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function deleteEvent_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deleteEvent(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: codev,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsevents',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteEvent_Ok, deleteEvent_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function actionEventInterested_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            if (paramsArray[0] == 1) {
                $('#area-action-selected').show();
            } else {
                $('#area-action-initial').show();
            }
            break;
    
        case 'OK':
            var type_change = response.change;
            switch (type_change) {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;                
            }
            
            $('#action_quitevent').html(text_yano_interested);
            $('#action_going').css('font-weight','normal');
            $('#action_interested').css('font-weight','500');
            $('#text-btn-result').html(response.txtbtn);
            $('#area-action-selected').show();
            
            break;
    }
    $('#preload-b-action').hide();
}

function actionEventInterested_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    if (paramsArray[0] == 1) {
        $('#area-action-selected').show();
    } else {
        $('#area-action-initial').show();
    }
}

function actionEventInterested(in_menue_merged) {
    "use strict";
    if (in_menue_merged == 1) {
        $('#area-action-selected').hide();
    } else {
        $('#area-action-initial').hide();
    }
    
    $('#preload-b-action').show();
    
    paramsArray[0] = in_menue_merged;

    var data = {
        cevent: code_event,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinevent',
            action: 'interested',
            cancelable: 0,
            data: data
    };

    invoke(params, actionEventInterested_Ok, actionEventInterested_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function actionEventGoing_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            if (paramsArray[0] == 1) {
                $('#area-action-selected').show();
            } else {
                $('#area-action-initial').show();
            }
            break;
    
        case 'OK':
            var type_change = response.change;
            switch (type_change) {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;                
            }
            
            $('#action_quitevent').html(text_yano_going);
            $('#action_going').css('font-weight','500');
            $('#action_interested').css('font-weight','normal');
            $('#text-btn-result').html(response.txtbtn);
            $('#area-action-selected').show();
            
            break;
    }
    $('#preload-b-action').hide();
}

function actionEventGoing_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    if (paramsArray[0] == 1) {
        $('#area-action-selected').show();
    } else {
        $('#area-action-initial').show();
    }
}

function actionEventGoing(in_menue_merged) {
    "use strict";
    if (in_menue_merged == 1) {
        $('#area-action-selected').hide();
    } else {
        $('#area-action-initial').hide();
    }
    
    $('#preload-b-action').show();
    
    paramsArray[0] = in_menue_merged;

    var data = {
        cevent: code_event,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinevent',
            action: 'going',
            cancelable: 0,
            data: data
    };

    invoke(params, actionEventGoing_Ok, actionEventGoing_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function actionQuitEvent_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#area-action-selected').show();
            break;
    
        case 'OK':
            $('#text-btn-result').html('');
            $('#area-action-initial').show();
            break;
    }
    $('#preload-b-action').hide();
}

function actionQuitEvent_Error(response) {
    "use strict";
    $('#preload-b-action').hide();
    $('#area-action-selected').show();
}

function actionQuitEvent() {
    "use strict";
    $('#area-action-selected').hide();
    
    $('#preload-b-action').show();


    var data = {
        cevent: code_event,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsinevent',
            action: 'quit',
            cancelable: 0,
            data: data
    };

    invoke(params, actionQuitEvent_Ok, actionQuitEvent_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function loadcategoryarticles_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[0]).html(response.categories);
            $(paramsArray[0]).removeAttr('disabled');
            break;            
    }
}

function loadcategoryarticles_Error(response) {
}

function loadcategoryarticles(idcat, msgcategory, msgsubcategory, divcategories, divsubcategories, idcompany) {
    "use strict";
	$(divcategories).html('<option value="-1">' + msgcategory + '</option>');
	$(divcategories).attr('disabled','true');
	$(divsubcategories).html('<option value="0">' + msgsubcategory + '</option>');
    
	paramsArray[0] = divcategories;
    
    var data = {
        idc: idcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getcategories',
            action: 'getcatarticles',
            cancelable: 0,
            data: data
    };

    invoke(params, loadcategoryarticles_Ok, loadcategoryarticles_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadsubcategoryarticles_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.subcategories);
            $(paramsArray[1]).removeAttr('disabled');
            break;            
    }
}

function loadsubcategoryarticles_Error(response) {
}

function loadsubcategoryarticles(idcat, idsubcat, msgcsubcategory, divsubcategories, idcompany) {
    "use strict";	
	$(divsubcategories).html('<option value="-1">' + msgcsubcategory + '</option>');
	$(divsubcategories).attr('disabled','true');
    
	paramsArray[1] = divsubcategories;
    
    var data = {
        idc: idcat,
        idsc: idsubcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getsubcategories',
            action: 'getsubcatarticles',
            cancelable: 0,
            data: data
    };

    invoke(params, loadsubcategoryarticles_Ok, loadsubcategoryarticles_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function loadcategoryproducts_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[0]).html(response.categories);
            $(paramsArray[0]).removeAttr('disabled');
            break;            
    }
}

function loadcategoryproducts_Error(response) {
}

function loadcategoryproducts(idcat, msgcategory, msgsubcategory, divcategories, divsubcategories, idcompany) {
    "use strict";
	$(divcategories).html('<option value="-1">' + msgcategory + '</option>');
	$(divcategories).attr('disabled','true');
	$(divsubcategories).html('<option value="0">' + msgsubcategory + '</option>');
    
	paramsArray[0] = divcategories;
    
    var data = {
        idc: idcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getcategories',
            action: 'getcatproducts',
            cancelable: 0,
            data: data
    };

    invoke(params, loadcategoryproducts_Ok, loadcategoryproducts_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function loadsubcategoryproducts_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.subcategories);
            $(paramsArray[1]).removeAttr('disabled');
            break;            
    }
}

function loadsubcategoryproducts_Error(response) {
}

function loadsubcategoryproducts(idcat, idsubcat, msgcsubcategory, divsubcategories, idcompany) {	
    "use strict";
	$(divsubcategories).html('<option value="-1">' + msgcsubcategory + '</option>');
	$(divsubcategories).attr('disabled','true');
    
	paramsArray[1] = divsubcategories;
    
    var data = {
        idc: idcat,
        idsc: idsubcat,
        icny: idcompany,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'getsubcategories',
            action: 'getsubcatproducts',
            cancelable: 0,
            data: data
    };

    invoke(params, loadsubcategoryproducts_Ok, loadsubcategoryproducts_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function publishArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'articles', 'dashboard-main-area-right', 'min');
            break;
    }
}

function publishArticle_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function publishArticle(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var titlearticle = validationInput('empty', '#titlearticle', diverror, txt_error_title, bsubmit, false);
	if (!titlearticle) return;

	var idcategory = validationInput('positive', '#categoryarticle', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryarticle', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var summaryarticle = validationInput('empty', '#summaryarticle', diverror, txt_error_summary, bsubmit, false);
	if (!summaryarticle) return;
    

    var thefile = $('#imagenfile').val();
    if (thefile != '') {
        var ext = thefile.split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            openandclose(diverror, txt_error_formatimage, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    } else {
        openandclose(diverror, txt_error_image, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

	var thecontent = tinyMCE.activeEditor.getContent();
	if (thecontent.length < 10) {
        openandclose(diverror, txt_error_content, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
		return;
	}

    var formData = new FormData(document.getElementById("form1"));
    formData.append("tta", titlearticle);
    formData.append("idca", idcategory);
    formData.append("idsca", idsubcategory);
    formData.append("smrya", summaryarticle);
    formData.append("conta", thecontent);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsarticles',
            action: 'publish',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, publishArticle_Ok, publishArticle_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function updateArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'articles', 'dashboard-main-area-right', 'min');
            break;
    }
}

function updateArticle_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateArticle(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var titlearticle = validationInput('empty', '#titlearticle', diverror, txt_error_title, bsubmit, false);
	if (!titlearticle) return;

	var idcategory = validationInput('positive', '#categoryarticle', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryarticle', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;

	var summaryarticle = validationInput('empty', '#summaryarticle', diverror, txt_error_summary, bsubmit, false);
	if (!summaryarticle) return;
    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') { 

        var thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_formatimage, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_image, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }

    }

	var thecontent = tinyMCE.activeEditor.getContent();
	if (thecontent.length < 10) {
        openandclose(diverror, txt_error_content, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
		return;
	}

    var formData = new FormData(document.getElementById("form1"));
    formData.append("codea", codart);
    formData.append("tta", titlearticle);
    formData.append("idca", idcategory);
    formData.append("idsca", idsubcategory);
    formData.append("smrya", summaryarticle);
    formData.append("conta", thecontent);
    formData.append("chgi", changeimg);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsarticles',
            action: 'update',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, updateArticle_Ok, updateArticle_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteArticle_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'articles', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function deleteArticle_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deleteArticle(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: codart,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsarticles',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteArticle_Ok, deleteArticle_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function createProduct_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'products', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createProduct_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createProduct(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var nameproduct = validationInput('empty', '#nameproduct', diverror, txt_error_name, bsubmit, false);
	if (!nameproduct) return;

	var descriptionproduct = validationInput('empty', '#descriptionproduct', diverror, txt_error_description, bsubmit, false);
	if (!descriptionproduct) return;

	var idcategory = validationInput('positive', '#categoryproduct', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryproduct', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;
    
	var typeproduct = validationInput('positive', '#typeproduct', diverror, txt_error_type, bsubmit, false);
	if (!typeproduct) return;

	var currencyproduct = validationInput('positive', '#currencyproduct', diverror, txt_error_currency, bsubmit, false);
	if (!currencyproduct) return;
    
	var priceproduct = validationInput('numberpositive', '#priceproduct', diverror, txt_error_price, bsubmit, false);
	if (!priceproduct) return;
    
	var locationproduct = validationInput('empty', '#locationproduct', diverror, txt_error_location, bsubmit, false);
	if (!locationproduct) return;

    var thefile = $('#imagenfile').val();
    if (thefile != '') {
        var ext = thefile.split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            openandclose(diverror, txt_error_formatphoto, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
    } else {
        openandclose(diverror, txt_error_photo, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }


    var formData = new FormData(document.getElementById("form1"));
    formData.append("namp", nameproduct);
    formData.append("desp", descriptionproduct);
    formData.append("idcp", idcategory);
    formData.append("idsp", idsubcategory);
    formData.append("typp", typeproduct);
    formData.append("curp", currencyproduct);
    formData.append("prip", priceproduct);
    formData.append("locp", locationproduct);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsproducts',
            action: 'create',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, createProduct_Ok, createProduct_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function updateProduct_dash_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'products', 'dashboard-main-area-right', 'min');
            break;
    }
}

function updateProduct_dash_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateProduct_dash(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var nameproduct = validationInput('empty', '#nameproduct', diverror, txt_error_name, bsubmit, false);
	if (!nameproduct) return;

	var descriptionproduct = validationInput('empty', '#descriptionproduct', diverror, txt_error_description, bsubmit, false);
	if (!descriptionproduct) return;

	var idcategory = validationInput('positive', '#categoryproduct', diverror, txt_error_category, bsubmit, false);
	if (!idcategory) return;

	var idsubcategory = validationInput('positive', '#subcategoryproduct', diverror, txt_error_subcategory, bsubmit, false);
	if (!idsubcategory) return;
    
	var typeproduct = validationInput('positive', '#typeproduct', diverror, txt_error_type, bsubmit, false);
	if (!typeproduct) return;

	var currencyproduct = validationInput('positive', '#currencyproduct', diverror, txt_error_currency, bsubmit, false);
	if (!currencyproduct) return;
    
	var priceproduct = validationInput('numberpositive', '#priceproduct', diverror, txt_error_price, bsubmit, false);
	if (!priceproduct) return;
    
	var locationproduct = validationInput('empty', '#locationproduct', diverror, txt_error_location, bsubmit, false);
	if (!locationproduct) return;

    
    var changeimg = $('#changeimg').val();
    
    if (changeimg == '1') { 

        var thefile = $('#imagenfile').val();
        if (thefile != '') {
            var ext = thefile.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                openandclose(diverror, txt_error_formatphoto, 1700)
                setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
                return;
            }
        } else {
            openandclose(diverror, txt_error_photo, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }

    }
    

    var formData = new FormData(document.getElementById("form1"));
    formData.append("codep", codpro);
    formData.append("namp", nameproduct);
    formData.append("desp", descriptionproduct);
    formData.append("idcp", idcategory);
    formData.append("idsp", idsubcategory);
    formData.append("typp", typeproduct);
    formData.append("curp", currencyproduct);
    formData.append("prip", priceproduct);
    formData.append("locp", locationproduct);
    formData.append("chgi", changeimg);
    
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsproducts',
            action: 'update',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, updateProduct_dash_Ok, updateProduct_dash_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteProduct_dash_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'products', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function deleteProduct_dash_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deleteProduct_dash(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: codpro,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsproducts',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteProduct_dash_Ok, deleteProduct_dash_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/


function viewRecentSearch() {
    "use strict";
     var data = {
        action: 'recentsearchtop',
    };

    $.ajax({
        type: 'POST',
        url: _SITE_URL + 'services/actionssearch',
        data: data,
        success: function(response) {
           switch (response.status) {
                case 'ERROR':
                    break;
                case 'OK':
                    $('#inside-info-search').html(response.result_search);
                    $('#link-more-search-top').attr('href', _SITE_URL + 'search/q:' + response.the_query);
                    break;            
           }
        }
    });    

}

/*******************************************************************/

$(document).on('click', '.the-smiles-chat', function() {
    $(this).next('.menusmiles-chat').toggle();
});

$(document).on('click', function(e) {
    if ($(e.target).hasClass('the-smiles-chat') || $(e.target).parents('.the-smiles-chat').length > 0 || $(e.target).hasClass('menusmiles-chat') || $(e.target).parents('.menusmiles-chat').length > 0) return;
    $('.menusmiles-chat').hide();
});

/*******************************************************************/


$(document).on('click', '.the-stickers-chat', function() {
    $(this).next('.menustickers-chat').toggle();
});

$(document).on('click', function(e) {
    if ($(e.target).hasClass('the-stickers-chat') || $(e.target).parents('.the-stickers-chat').length > 0 || $(e.target).hasClass('menustickers-chat') || $(e.target).parents('.menustickers-chat').length > 0) return;
    $('.menustickers-chat').hide();
});

/*******************************************************************/

$(document).on('click', '.ico-stickerscom', function() {
    $(this).next('.menustickers-comment').toggle();
});

$(document).on('click', function(e) {
    if ($(e.target).hasClass('ico-stickerscom') || $(e.target).parents('.ico-stickerscom').length > 0 || $(e.target).hasClass('menustickers-comment') || $(e.target).parents('.menustickers-comment').length > 0) return;
    $('.menustickers-comment').hide();
});

/*******************************************************************/

function createAlbum_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'albums', 'dashboard-main-area-right', 'min');
            break;
    }
}

function createAlbum_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function createAlbum(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var titlealbum = validationInput('empty', '#titlealbum', diverror, txt_error_title, bsubmit, false);
	if (!titlealbum) return;

	var descriptionalbum = $('#descriptionalbum').val();

	var privacyalbum = validationInput('zeroandpositive', '#privacyalbum', diverror, txt_error_privacy, bsubmit, false);
	if (!privacyalbum) return;
    
    var numphotos = $('#numphotos').val();
    
    if (numphotos > 0) {
        
        var thefile = $('#filesphotos').val();
        
        var thephotos = document.getElementById('filesphotos').files;
        
        var errorformat = false;
        
        for(var x = 0; x < thephotos.length; x++) {
            var ext = thephotos[x].name.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                errorformat = true;
                break;
            }
        }
        if (errorformat) {
            openandclose(diverror, txt_error_formatphoto, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    } else {
        openandclose(diverror, txt_error_photo, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

    var formData = new FormData(document.getElementById("form1"));
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsalbums',
            action: 'create',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, createAlbum_Ok, createAlbum_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function updateAlbum_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'albums', 'dashboard-main-area-right', 'min');
            break;
    }
}

function updateAlbum_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function updateAlbum(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
	var titlealbum = validationInput('empty', '#titlealbum', diverror, txt_error_title, bsubmit, false);
	if (!titlealbum) return;

	var descriptionalbum = $('#descriptionalbum').val();

	var privacyalbum = validationInput('zeroandpositive', '#privacyalbum', diverror, txt_error_privacy, bsubmit, false);
	if (!privacyalbum) return;

    var data = {
        tta: titlealbum,
        dca: descriptionalbum,
        pva: privacyalbum,
        cda: code_album,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsalbums',
            action: 'update',
            cancelable: 0,
            data: data
    };
    
    $('#preload-publish').show();

    invoke(params, updateAlbum_Ok, updateAlbum_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deleteAlbum_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'albums', 'dashboard-main-area-right', 'min');
            break;            
    }
}

function deleteAlbum_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
}

function deleteAlbum(diverror) {
    "use strict";
	paramsArray[0] = diverror;
    
    var data = {
        code: code_album,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsalbums',
            action: 'delete',
            cancelable: 0,
            data: data
    };

    invoke(params, deleteAlbum_Ok, deleteAlbum_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function addPhotosAlbum_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            $('#preload-publish').hide();
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            actionOnClick(_SITE_URL + 'albums/photos/a:' + response.codealbum, 'dashboard-main-area-right', 'min');
            break;
    }
}

function addPhotosAlbum_Error(response) {
    "use strict";
    $('#preload-publish').hide();
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() { $(paramsArray[1]).removeAttr('disabled'); }, 2500);
}

function addPhotosAlbum(diverror, bsubmit) {
    "use strict";
    $(bsubmit).attr('disabled','true');

    paramsArray[0] = diverror;
    paramsArray[1] = bsubmit;
    
    var numphotos = $('#numphotos').val();
    
    if (numphotos > 0) {
        
        var thefile = $('#filesphotos').val();
        
        var thephotos = document.getElementById('filesphotos').files;
        
        var errorformat = false;
        
        for(var x = 0; x < thephotos.length; x++) {
            var ext = thephotos[x].name.split('.').pop().toLowerCase();
            if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
                errorformat = true;
                break;
            }
        }
        if (errorformat) {
            openandclose(diverror, txt_error_formatphoto, 1700)
            setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
            return;
        }
        
    } else {
        openandclose(diverror, txt_error_photo, 1700)
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);
        return;
    }

    var formData = new FormData(document.getElementById("form1"));
    formData.append("coda", code_album);
    
    var params = {
            type: 'POST',
            withFile: true,
            module: 'actionsalbums',
            action: 'addphotos',
            cancelable: 0,
            data: formData
    };
    
    $('#preload-publish').show();

    invoke(params, addPhotosAlbum_Ok, addPhotosAlbum_Error);

}

/*__________________________________________________________________*/
/*__________________________________________________________________*/

function deletePhotosAlbum_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            alert(response.message);
            break;
    
        case 'OK':
            if (response.total == 1) {
                actionOnClick(_SITE_URL + 'albums', 'dashboard-main-area-right', 'min');
            } else {
                $("#photo_album_" + paramsArray[0]).fadeOut(500, function() { $("#photo_album_" + paramsArray[0]).remove(); });
            }
            break;
    }
}

function deletePhotosAlbum_Error(response) {
    "use strict";
    alert(msg_error_conection);
}

function deletePhotosAlbum(codephoto) {
    "use strict";
    paramsArray[0] = codephoto;

    var data = {
        codea: codealbum,
        codep: codephoto,
    };
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'actionsalbums',
            action: 'deletephoto',
            cancelable: 0,
            data: data
    };

    invoke(params, deletePhotosAlbum_Ok, deletePhotosAlbum_Error);

}
