/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

/**************************************************************/

function resetpassword_Ok(response) {
    "use strict";
    switch (response.status) {
        case 'ERROR':
            openandclose(paramsArray[0], response.message, 1700)
            setTimeout(function() { $(paramsArray[2]).removeAttr('disabled'); }, 2500);
            break;
    
        case 'OK':
            $(paramsArray[1]).html(response.msgok);
            $(paramsArray[3]).fadeOut('slow',function(){
                $(paramsArray[3]).hide(function(){
                    $(paramsArray[1]).fadeIn('slow');
                });
            });
            break;
    }
}

function resetpassword_Error(response) {
    "use strict";
    openandclose(paramsArray[0], msg_error_conection, 1700)
    setTimeout(function() {$(paramsArray[2]).removeAttr('disabled');}, 2500);
}

function resetpassword(divform, divok, diverror, bsubmit) {
    "use strict";
	$(bsubmit).attr('disabled','true');

	var passw01 = validationInput('empty', '#passw01', diverror, error_enter_pass, bsubmit, true);
	if (!passw01) return;

	var passw01 = validationInput('password', '#passw01', diverror, error_pass_num_char, bsubmit, true);
	if (!passw01) return;
    
	var passw02 = $('#passw02').val();
    
    if (passw01 != passw02) {
        openandclose(diverror, error_pass_not_match, 1700);
        setTimeout(function() { $(bsubmit).removeAttr('disabled'); }, 2500);   
        return;     
    }

    var data = {
        pasn: '' + CryptoJS.SHA256(passw01) + '',
        tcu: tcu,
        trk: trk,
    };
 
    paramsArray[0] = diverror;
    paramsArray[1] = divok;
    paramsArray[2] = bsubmit;
    paramsArray[3] = divform;
    
    var params = {
            type: 'POST',
            withFile: false,
            module: 'resetpass',
            action: 'reset',
            cancelable: 0,
            data: data
    };

    invoke(params, resetpassword_Ok, resetpassword_Error);

}