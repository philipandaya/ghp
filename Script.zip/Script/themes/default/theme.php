<?php
$current_theme = (object) array (
    'name' => 'Default Theme',
    'version' => '1.0',
    'description' => 'Default Theme for YaaX.',
    'author_name' => 'MCode Developer',
    'author_url' => 'http://www.mcodedeveloper.com',
    'author_email' => 'devs@mcodedeveloper.com',	
);	
?>