<?php
include('parts/_header.php');
include('parts/_bar-top.php');
include('parts/_signup-free.php');
include('parts/_foot.php');
include('parts/_footer.php');
?>