<div class="the_media_photo">

    <a href="<?php echo $D->theURLMain.($D->is_shared ? $D->shared->activity_who_does_it_username : $D->activity_who_does_it_username)?>/post/<?php echo $D->code_post_album?>" class="zoomeer" data-id="<?php echo $D->photo[0]->code?>" data-image="<?php echo $K->STORAGE_URL_ALBUMS_USERS?>thumb1/<?php echo $D->photo[0]->folder.'/'.$D->photo[0]->namefile?>" data-place="album"><div class="one_photo one_vert" style="background-image:url(<?php echo $K->STORAGE_URL_ALBUMS_USERS?>thumb2/<?php echo $D->photo[0]->folder.'/'.$D->photo[0]->namefile?>);"></div></a>

</div>