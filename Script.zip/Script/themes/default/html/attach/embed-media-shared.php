    <div class="inside-content-embed">

        <div class="area-embed">
            <div class="embed-responsive">
                <?php echo $D->shared->infoEmbed['e_html']?>
            </div>

            <div class="the-info-embed">
                <div class="title"><a href="<?php echo $D->shared->infoEmbed['e_url']?>" target="_blank"><?php echo $D->shared->infoEmbed['e_title']?></a></div>
                <div class="text"><?php echo $D->shared->infoEmbed['e_text']?></div>
                <div class="source"><?php echo $D->shared->infoEmbed['e_provider']?></div>
            </div>
        </div>

    </div>