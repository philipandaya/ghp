        <?php if(isset($D->js_script_max)) echo $D->js_script_max;?>

        <div id="<?php echo $D->id_container?>-main-area">

            <div id="login-init">
            
                <div id="titleform"><?php echo $this->lang('login_title'); ?></div>

                <div id="space-form">
                    <form id="formlogin" name="formlogin" method="post">
        
                    <div><input type="text" class="boxinput" name="theemail" id="theemail" placeholder="<?php echo $this->lang('login_email_placeholder')?>"></div>
                    <div id="alert-error-form" class="alert alert-red hide"></div>
                    <div id="areabutton"><button class="btn-lg-yellow" name="go_login_next" id="go_login_next" type="submit"><?php echo $this->lang('login_bsubmit')?></button></div>
                    
                    </form>  
                    
                    <script>
                        var error_theemail = stripslashes('<?php echo strJS($this->lang('login_error_email'))?>');
                
                        $('#go_login_next').on("click", function(){ 
                            login_next('#alert-error-form', '#go_login_next');
                            return false;
                        });
                
                    </script>

                                  
                </div>


            </div>

            <?php if (isset($D->titlePhantom) && !empty($D->titlePhantom)) { ?>
            <div id="newtitlesite" style="display:none;"><?php echo $D->titlePhantom?></div>
            <?php } ?>

            <?php $this->load_template('parts/_foot-auth.php'); ?>

        </div>
