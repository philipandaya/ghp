<div class="box-plan-membership">
    <div class="m-thename"><span id="pm_name_<?php echo($D->p_id_plan); ?>"><?php echo $D->p_name_plan; ?></span></div>
    <div class="m-theprice price-month"><?php echo $K->CURRENCY; ?> <?php echo number_format($D->p_price_monthly, 2); ?></div>
    <div class="m-thetime time-month"><?php echo $this->lang('admin_membership_month'); ?></div>

    <div class="m-theprice price-annual"><?php echo $K->CURRENCY; ?> <?php echo number_format($D->p_price_annual, 2); ?></div>
    <div class="m-thetime time-annual"><?php echo $this->lang('admin_membership_annual'); ?></div>
    
    <div class="m-theseparator"></div>

    <div class="m-theusers"><?php echo $D->p_max_users; ?> <?php echo $this->lang('admin_membership_users'); ?></div>
    
    <div class="m-theseparator"></div>

    <?php if ($K->WITH_CUST_DOM) { ?>

    <div class="m-theusers"><?php echo($D->p_w_cdomain == 0 ? $this->lang('admin_membership_no_cdomain') : '<span class="bold">'.$this->lang('admin_membership_with_cdomain').'</span>'); ?></div>
    
    <div class="m-theseparator"></div>

    <?php } ?>

    <div class="area_type_pay"><select id="type_pay-<?php echo($D->p_id_plan); ?>" class="select_pay"><?php echo $D->html_select_pays; ?></select></div>

    <div id="btngopay-<?php echo($D->p_id_plan); ?>" class="hide">
        <span class="mybtn-flat-blue" id="pm-<?php echo($D->p_id_plan); ?>"><?php echo $this->lang('admin_membership_buynow'); ?></span>
        <div id="pm-preload-<?php echo($D->p_id_plan); ?>" class="k-preloader hide"></div>
    </div>

    <input type="hidden" name="p_p_m_1_<?php echo($D->p_id_plan); ?>" id="p_p_m_1_<?php echo($D->p_id_plan); ?>" value="<?php echo $D->p_price_monthly; ?>">
    <input type="hidden" name="p_p_m_2_<?php echo($D->p_id_plan); ?>" id="p_p_m_2_<?php echo($D->p_id_plan); ?>" value="<?php echo $D->p_price_annual; ?>">
</div>

<script>

    $('#type_pay-<?php echo($D->p_id_plan); ?>').on('change', function(){
        var theselect = this.value;
        if (theselect == -1) {
            $('#btngopay-<?php echo($D->p_id_plan); ?>').hide();
        } else {
            $('#btngopay-<?php echo($D->p_id_plan); ?>').show();
        }
    });

    $('#pm-<?php echo($D->p_id_plan); ?>').on('click', function(){
        var thetypepay = $('#type_pay-<?php echo($D->p_id_plan); ?>').val();
        if (thetypepay != -1) {
            payNow(<?php echo($D->p_id_plan); ?>, thetypepay);
        }
    });

</script>
