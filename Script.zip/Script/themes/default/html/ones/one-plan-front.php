                        <div class="col-md-4">
                            <div class="pricing pricing-1 boxed boxed--lg boxed--border <?php echo($D->plan_popular ? 'boxed--emphasis' : ''); ?>">
                                <h3><?php echo $D->name_plan; ?></h3>
                                <span class="h2">
                                    <strong><?php echo $K->CURRENCY; ?> <?php echo $D->price_month_plan; ?></strong>
                                </span>
                                <span class="type--fine-print"><?php echo $this->lang('home_front_hero_txt_month'); ?></span>
                                <?php if ($D->plan_popular) { ?>
                                <span class="label"><?php echo $this->lang('home_front_hero_txt_more_popular'); ?></span>
                                <?php } ?>
                                <hr>
                                <ul>
                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo $D->max_users; ?> <?php echo $this->lang('home_front_hero_plan_ftr_users'); ?></span>
                                    </li>


                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo($D->sup_audios ? $this->lang('home_front_hero_plan_ftr_with_audios') : $this->lang('home_front_hero_plan_ftr_without_audios')); ?></span>
                                    </li>

                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo($D->sup_videos ? $this->lang('home_front_hero_plan_ftr_with_videos') : $this->lang('home_front_hero_plan_ftr_without_videos')); ?></span>
                                    </li>



                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo $this->lang('home_front_hero_plan_ftr_all_tools'); ?></span>
                                    </li>
                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo $this->lang('home_front_hero_plan_ftr_support'); ?></span>
                                    </li>
                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span><?php echo $this->lang('home_front_hero_plan_ftr_access'); ?></span>
                                    </li>
                                    
                                    <?php if ($K->WITH_CUST_DOM) { ?>
                                    <li>
                                        <span class="checkmark bg--primary-1"></span>
                                        <span <?php echo($D->w_cdomain == '0' ? '' : 'style="font-weight:600;"'); ?>><?php echo($D->w_cdomain == '0' ? $this->lang('home_front_hero_plan_ftr_no_cdomain') : $this->lang('home_front_hero_plan_ftr_with_cdomain')); ?></span>
                                    </li>
                                    <?php } ?>

                                </ul>
                                <a class="btn btn--primary" href="<?php echo $K->SITE_URL; ?>signup-free"><span class="btn__text" style="font-size:15px;"><?php echo $this->lang('home_front_hero_txt_free_trial'); ?></span></a>
                            </div>
                            <!--end of pricing-->
                        </div>