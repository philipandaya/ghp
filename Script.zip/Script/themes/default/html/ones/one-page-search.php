<div style="margin-bottom:20px;">

    <div style="float:left; margin-right:10px; width:90px; height:90px;"><a href="<?php echo($D->theURLCompany.$D->the_username_page)?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo $D->page_avatar?>"></a></div>

    <div style="padding:0 0 0 0px">

        <div><span class="link link-general bold" style="font-size:15px;"><a href="<?php echo($D->theURLCompany.$D->the_username_page)?>" rel="phantom-all" target="dashboard-main-area"><?php echo $D->the_title_page?></a></span></div>

        <div style="font-size:13px; color:#999999; font-weight:500;"><?php echo $D->the_category_page?></div>

        <div><?php echo $D->numlikes_page.' '.$D->txt_like?></div>

    </div>

    <div class="clear"></div>

</div>