<div class="myRow" id="item-<?php echo $D->idcompany; ?>">

    <div class="myCell avatar"><a href="<?php echo $K->SITE_URL.$D->usernamecompany; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo $D->one->avatar?>"></a></div>

    <div class="myCell name">
        <div style="margin-bottom:3px;"><span class="label-plan <?php echo $D->the_style; ?>"><?php echo $D->theplan_text; ?></span></div>
        <div><span class="link link-general bold"><a href="<?php echo $K->SITE_URL.$D->usernamecompany; ?>" rel="phantom-all" target="dashboard-main-area"><?php echo $D->one->allname?></a></span></div>

        <div class="actions2">

            <span><a href="<?php echo $K->SITE_URL?>superadmin/companies/edit/c:<?php echo $D->idcompany; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo getImageTheme('list-ico-edit.png')?>" class="ico"></a></span>

            <?php if ($D->idcompany != $D->me->idcompany) { ?>

            <span id="del-item1-<?php echo $D->idcompany; ?>"><img src="<?php echo getImageTheme('list-ico-delete.png')?>" class="ico"></span>

            <?php } ?>

        </div>

    </div>

    <div class="myCell actions">

        <span><a href="<?php echo $K->SITE_URL?>superadmin/companies/edit/c:<?php echo $D->idcompany; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo getImageTheme('list-ico-edit.png')?>" class="ico"></a></span>

        <?php if ($D->idcompany != $D->me->idcompany) { ?>

        <span id="del-item2-<?php echo $D->idcompany; ?>"><img src="<?php echo getImageTheme('list-ico-delete.png')?>" class="ico"></span>

        <?php } ?>

    </div>

</div>

<?php if ($D->idcompany != $D->me->idcompany) { ?>
<script>
(function($) {
    "use strict";
    
    $('#del-item1-<?php echo $D->idcompany; ?>, #del-item2-<?php echo $D->idcompany; ?>').on("click", function(){
        closeEmerged();
        _confirm(msg_delete_user, nothign, deleteCompanySA, <?php echo $D->idcompany; ?>);
    });
})(jQuery);
</script>

<?php } ?>