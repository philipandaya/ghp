<div class="one_photo_in_profile">
<a href="<?php echo $D->gph_urlphoto?>" class="zoomeer" data-id="<?php echo $D->gph_code?>" data-image="<?php echo $D->gph_media?>" data-place="list"><div class="photo_in_profile" style="background-image:url(<?php echo $K->STORAGE_URL_PHOTOS.'thumb3/'.$D->gph_folder.'/'.$D->gph_namefile?>); margin-bottom:3px;"></div></a>
</div>
