
<div class="box-activity-nofound">
	<div><?php echo $this->lang('global_txt_shared_nofound')?></div>
</div>
