<div class="one_video_in_profile">

<a href="<?php echo $D->gph_urlvideo?>" class="zoomeer" data-id="<?php echo $D->gph_code?>" data-image="<?php echo $D->gph_media?>" data-place="list">
    <div class="video_in_profile">

        <div class="video-js-responsive-container vjs-hd">
            <video class="video-js js_video-js vjs-big-play-centered" controls preload="auto" poster="">
                <source src="<?php echo $D->file_src?>">
            </video>
        </div>
    
    </div>
</a>

</div>
