<a href="<?php echo $D->url_notif?>" rel="phantom-all" target="dashboard-main-area" class="undecorated">
<div class="one-notif">
    <div class="avatar"><img src="<?php echo $D->avatar?>"></div>
    
    <div class="info">
        <div>
            <span class="name"><?php echo $D->name?></span> <span><?php echo $D->cadaction?></span> <span class="name"><?php echo $D->name2?></span>
        </div>
        <div class="thedate"><?php echo $D->thedate?></div>
    </div>

    <div class="clear"></div>
</div>
</a>