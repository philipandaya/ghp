<div class="one_audio_in_profile">

<a href="<?php echo $D->gph_urlvideo?>" class="zoomeer" data-id="<?php echo $D->gph_code?>" data-image="<?php echo $D->gph_media?>" data-place="list">
    <div class="audio_in_profile">

        <audio class="mep_audio" style="width: 100%;" controls>
    
                <source src="<?php echo $D->file_src?>">
    
        </audio>
    
    </div>
</a>

</div>
