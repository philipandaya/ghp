<div class="myRow" id="user-<?php echo $D->one->code; ?>">

    <div class="myCell avatar"><a href="<?php echo $K->SITE_URL; ?>admin/users/pending/details/u:<?php echo $D->one->code; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo $D->one->avatar?>"></a></div>

    <div class="myCell name">

        <div><span class="link link-general"><a href="<?php echo $K->SITE_URL; ?>admin/users/pending/details/u:<?php echo $D->one->code; ?>" rel="phantom-all" target="dashboard-main-area"><?php echo $D->one->allname?></a></span></div>

        <div class="actions2">

            <span><a href="<?php echo $K->SITE_URL; ?>admin/users/pending/details/u:<?php echo $D->one->code; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo getImageTheme('list-ico-info.png')?>" class="ico"></a></span>

        </div>

    </div>

    <div class="myCell actions">

        <span><a href="<?php echo $K->SITE_URL; ?>admin/users/pending/details/u:<?php echo $D->one->code; ?>" rel="phantom-all" target="dashboard-main-area"><img src="<?php echo getImageTheme('list-ico-info.png')?>" class="ico"></a></span>

    </div>

</div>
