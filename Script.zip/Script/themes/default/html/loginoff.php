<?php $this->load_template('parts/_header-off.php'); ?>

        <div id="area-form">
            <form id="formlogin" name="formlogin" method="post">

            <div class="nameitem"><?php echo $this->lang('off_login_username')?></div>
            <div><input type="text" class="boxinput" name="username" id="username" placeholder="<?php echo $this->lang('off_login_username')?>"></div>
            <div class="nameitem"><?php echo $this->lang('off_login_password')?></div>
            <div><input type="password" class="boxinput" name="password" id="password" placeholder="<?php echo $this->lang('off_login_password')?>"></div>

            <div id="areabutton"><button class="btn" name="go_login" id="go_login" type="submit"><?php echo $this->lang('off_login_blogin')?></button></div>
            <input id="login" name="login" type="hidden" value="ok">

            </form> 

        </div>

<?php $this->load_template('parts/_footer-off.php'); ?>