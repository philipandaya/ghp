<p><?php echo $this->lang('email_validation_hello'); ?></p>

<p><?php echo $this->lang('email_validation_msg01', array('#SITE_TITLE#'=>$K->SITE_TITLE)); ?><br>

<p><a href="<?php echo $D->linkvalidation ?>" target="_blank"><?php echo $D->linkvalidation ?></a></p>

<p><?php echo $this->lang('email_validation_msg02', array('#SITE_TITLE#'=>$K->SITE_TITLE)); ?></p>

<p><?php echo $this->lang('email_validation_signature', array('#SITE_TITLE#'=>$K->SITE_TITLE)); ?></p><br><br>