<p><?php echo $this->lang('email_notifcdomain_hello'); ?></p>

<p><?php echo $this->lang('email_notifcdomain_msg1'); ?><br><br>

<p><span style="font-weight:bold;"><?php echo $this->lang('email_notifcdomain_txt_user'); ?></span>: <?php echo $D->cd_user; ?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_notifcdomain_txt_company'); ?></span>: <?php echo $D->cd_company; ?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_notifcdomain_txt_url'); ?></span>: <?php echo $D->cd_customdomain; ?><br>

<p><?php echo $this->lang('email_notifcdomain_signature', array('#SITE_TITLE#'=>$K->SITE_TITLE)); ?></p><br><br>