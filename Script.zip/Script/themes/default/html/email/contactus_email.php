<p><?php echo $this->lang('email_contactus_hello'); ?></p>

<p><?php echo $this->lang('email_contactus_msg1'); ?><br><br>

<p><span style="font-weight:bold;"><?php echo $this->lang('email_contactus_txt_names'); ?></span>: <?php echo $D->c_names;?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_contactus_txt_company'); ?></span>: <?php echo $D->c_company;?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_contactus_txt_email'); ?></span>: <?php echo $D->c_email;?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_contactus_txt_phone'); ?></span>: <?php echo $D->c_phone;?><br>
<p><span style="font-weight:bold;"><?php echo $this->lang('email_contactus_txt_comment'); ?></span>: <?php echo $D->c_comment;?><br><br>

<p><?php echo $this->lang('email_contactus_signature', array('#SITE_TITLE#'=>$K->SITE_TITLE)); ?></p><br><br>