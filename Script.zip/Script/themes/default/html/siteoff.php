<?php $this->load_template('parts/_header-off.php'); ?>

    <div class="space-logo">
        <div class="logo"><img src="<?php echo getImageMisc($K->ISOTIPO_HOME_OFF); ?>"></div>
    </div>
    <div class="space-message1"><?php echo $this->lang('off_title')?></div>
    <div class="space-message2"><?php echo $this->lang('off_message')?></div>

<?php $this->load_template('parts/_footer-off.php'); ?>