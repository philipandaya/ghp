        <?php if(isset($D->js_script_res)) echo $D->js_script_res; ?>

        <div id="<?php echo $D->id_container?>-main-area">

            <div id="login-init">
            
                <div id="titleform"><?php echo $this->lang('resetpass_title'); ?></div>

                <div id="space-form">
                
                    <?php if ($D->status_reset == 0) { ?>
                    <div id="msg-error-reset" class="space_reset_msg_error"><?php echo($this->lang('resetpass_msg1')); ?></div>
                    <?php } ?>
                    
                    <?php if ($D->status_reset == 1) { ?>
                
                    <form id="formresetpass" name="formresetpass" method="post">
        
                    <div style="margin-bottom:20px;"><input type="password" class="boxinput" name="passw01" id="passw01" placeholder="<?php echo $this->lang('resetpass_newpass')?>"></div>
                    <div><input type="password" class="boxinput" name="passw02" id="passw02" placeholder="<?php echo $this->lang('resetpass_re_newpass')?>"></div>
                                        
                    <div id="alert-error-form" class="alert alert-red hide"></div>
                    <div id="areabutton"><button class="btn-lg-blue" name="go_resetpassword" id="go_resetpassword" type="submit"><?php echo $this->lang('resetpass_bupdate')?></button></div>
                    
                    </form>
                    
                    <div id="divok" class="space_reset_msg_ok"></div>
                    
                    <?php } ?>
                    
                    
                    
                    <?php if ($D->status_reset == 1) { ?>
                    
                    <script>
                        var error_enter_pass = stripslashes('<?php echo strJS($this->lang('resetpass_msg_error1'))?>');
                        var error_pass_num_char = stripslashes('<?php echo strJS($this->lang('resetpass_msg_error2'))?>');
                        var error_pass_not_match = stripslashes('<?php echo strJS($this->lang('resetpass_msg_error3'))?>');
                        
                        var tcu = '<?php echo $D->thecodeuser; ?>';
                        var trk = '<?php echo $D->reset_key; ?>';

                
                        $('#go_resetpassword').on("click", function(){ 
                            resetpassword('#formresetpass', '#divok', '#alert-error-form', '#go_resetpassword');
                            return false;
                        });
                
                    </script>
                    
                    <?php } ?>

                                  
                </div>


            </div>

            <?php if (isset($D->titlePhantom) && !empty($D->titlePhantom)) { ?>
            <div id="newtitlesite" style="display:none;"><?php echo $D->titlePhantom?></div>
            <?php } ?>

            <?php //$this->load_template('parts/_foot-auth.php'); ?>

        </div>
