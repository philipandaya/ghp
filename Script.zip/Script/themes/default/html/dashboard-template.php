<?php $this->load_template('parts/_header.php'); ?>

<div id="dashboard-all-content">

    <div id="dashboard-top-area">
        <?php $this->load_template('parts/_top-inside.php'); ?>
    </div>

    <?php $this->load_template($D->file_in_template); ?>

    <div id="dashboard-foot-area"><?php /**/ ?></div>

</div>

<?php $this->load_template('parts/_footer.php'); ?>