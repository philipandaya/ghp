<div class="space-actions-admin-dash">
    
    <div class="saad-inside">
    
        <div class="title-box-info"><?php echo $this->lang('dashboard_statistic_title'); ?></div>
    
        <a href="<?php echo $K->SITE_URL; ?>admin/membership" rel="phantom-all" target="dashboard-main-area">
        <div class="saad-area-1" style="padding:0 10px;">
            <div class="saad-box-text"><?php echo $this->lang('dashboard_statistic_users'); ?></div>
            <div class="content-bar">
                <div class="the-value-bar <?php echo($D->company_num_users >= $D->theplan_max_users ? 'tvb-red' : ''); ?>" style="width:<?php echo($D->company_num_users >= $D->theplan_max_users ? '100' : $D->theplan_percent_users); ?>%;"></div>
            </div>
            <div class="saad-box-text"><?php echo $D->company_num_users; ?> <?php echo $this->lang('dashboard_statistic_of'); ?> <?php echo $D->theplan_max_users; ?></div>
        </div>
        </a>
        <a href="<?php echo $K->SITE_URL; ?>admin/membership" rel="phantom-all" target="dashboard-main-area">
        <div class="saad-area-2" style="padding:0 10px;">
            <div class="saad-box-text"><?php echo $this->lang('dashboard_statistic_days'); ?></div>
            <div class="content-bar">
                <div class="the-value-bar <?php echo($D->hasExpired ? 'tvb-red' : ''); ?>" style="width:<?php echo($D->hasExpired ? '100' : $D->theplan_percent_days); ?>%;"></div>
            </div>
            <div class="saad-box-text"><?php echo $D->the_diference_days; ?> <?php echo $this->lang('dashboard_statistic_of'); ?> <?php echo $D->theplan_days; ?></div>
        </div>
        </a>
        <div class="clear"></div>
    </div>
</div>