<div id="langs-pseudo-foot" class="space-box" style="margin-top:0;">
<?php
    $D->list_languages = array();
    foreach(get_available_languages(FALSE) as $k=>$v) {
        ?>
        <?php if ($K->LANGUAGE != $k) { ?>
        <span class="one-option-lang-foot oolf-active"><a href="#" rel="language" data-lang="<?php echo $k; ?>"><span><?php echo $v->name; ?></span></a></span>
        <?php } else { ?>
        <span class="one-option-lang-foot oolf-inactive"><?php echo $v->name; ?></span>
        <?php } ?>
        <?php
    }
?>
</div>

<div style="padding:10px 8px 0; margin-bottom:20px;">

    <?php if (isset($D->different_companies) && !$D->different_companies) { ?>
    
    <div style="line-height:24px;">
    <?php
    $statics = getStaticsFootCompany($D->company_id);
    if ($statics) {
        foreach ($statics as $onest) { ?>
        <span class="link link-secondary" style="padding-right:10px;"><a href="<?php echo $D->theURLCompany.'info/'.$onest->url?>" <?php echo($D->_IS_LOGGED ? 'rel="phantom-all" target="dashboard-main-area"' : '') ?>><span style="word-wrap: break-word;"><?php echo $onest->title ?></span></a></span>
    <?php 
        }
    } ?>
    </div>
    
    <?php } ?>    
    
    <div style="color:#9fa0ab; margin-top:5px;"><?php echo $D->company_name_out; ?> &copy; <?php echo date('Y'); ?></div>
</div>