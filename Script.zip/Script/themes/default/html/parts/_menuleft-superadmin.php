<div id="menuleft-admin" class="super">

    <div style="text-align:center; font-weight:500; font-size:14px; padding:4px 0 10px;" class="ellipsis"><?php echo $this->lang('superadmin_menu_title'); ?></div>
    <div class="separatorm "></div>
    
    <div class="tab-separator-grey"><?php echo $this->lang('superadmin_menu_system_options'); ?></div>

    <div>
    
        <div id="opt_sadm_general" title="<?php echo($this->lang('superadmin_menu_general')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/general" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_general' ? 'active' : '')?>">
                <div id="icom-sadm-general" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-general.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_general')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>

        <div id="opt_sadm_currencies_system" title="<?php echo($this->lang('superadmin_menu_currencies_system')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/currencies-system" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_currencies_system' ? 'active' : '')?>">
                <div id="icom-sadm-currencies-system" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-currenciesystem.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_currencies_system')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_sadm_gateways" title="<?php echo($this->lang('superadmin_menu_gateways')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/gateways" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_gateways' ? 'active' : '')?>">
                <div id="icom-sadm-gateways" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-gateways.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_gateways')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_customdomains" title="<?php echo($this->lang('superadmin_menu_customdomains')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/customdomains" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_customdomains' ? 'active' : '')?>">
                <div id="icom-sadm-customdomains" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-customdomains.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_customdomains')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_plans" title="<?php echo($this->lang('superadmin_menu_plans')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/plans" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_plans' ? 'active' : '')?>">
                <div id="icom-sadm-plans" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-plans.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_plans')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_globalbrand" title="<?php echo($this->lang('superadmin_menu_globalbrand')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/globalbrand" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_globalbrand' ? 'active' : '')?>">
                <div id="icom-sadm-globalbrand" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-globalbrand.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_globalbrand')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>

    <div>
    
        <div id="opt_sadm_staticpages" title="<?php echo($this->lang('superadmin_menu_static_pages')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/static-pages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_staticpages' ? 'active' : '')?>">
                <div id="icom-sadm-staticpages" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-static-pages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_static_pages')); ?></div>
                <div id="left-num-sadm-staticpages" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
            
        <div class="separatorm "></div>

    </div>

    <div>
    
        <div id="opt_sadm_myadsdash" title="<?php echo($this->lang('superadmin_menu_myads_dashboard')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/myads/dashboard" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_myadsdash' ? 'active' : '')?>">
                <div id="icom-sadm-myadsdash" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-myadsdash.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_myads_dashboard')); ?></div>
                <div id="left-num-sadm-myadsdash" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
            
        <div id="opt_sadm_myadsprof" title="<?php echo($this->lang('superadmin_menu_myads_profile')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/myads/profile" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_myadsprof' ? 'active' : '')?>">
                <div id="icom-sadm-myadsprof" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-myadsprof.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_myads_profile')); ?></div>
                <div id="left-num-sadm-myadsprof" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>

        <div class="separatorm "></div>

    </div>

    
    <div>
    
        <div id="opt_sadm_themes" title="<?php echo($this->lang('superadmin_menu_themes')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/themes" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_themes' ? 'active' : '')?>">
                <div id="icom-sadm-themes" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-themes.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_themes')); ?></div>
                <div id="left-num-sadm-themes" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    
    <div>
    
        <div id="opt_sadm_lang" title="<?php echo($this->lang('superadmin_menu_languages')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/languages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_lang' ? 'active' : '')?>">
                <div id="icom-sadm-lang" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-languages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_languages')); ?></div>
                <div id="left-num-sadm-lang" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_timez" title="<?php echo($this->lang('superadmin_menu_timezone')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/timezone" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_timez' ? 'active' : '')?>">
                <div id="icom-sadm-timez" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-timezone.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_timezone')); ?></div>
                <div id="left-num-sadm-timez" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
    </div>


    <div class="tab-separator-grey"><?php echo $this->lang('superadmin_menu_company_options'); ?></div>


    <div>
    
        <div id="opt_sadm_companies" title="<?php echo($this->lang('superadmin_menu_companies')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/companies" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_companies' ? 'active' : '')?>">
                <div id="icom-sadm-companies" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-companies.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_companies')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>


    
    <div>
    
        <div id="opt_sadm_users" title="<?php echo($this->lang('superadmin_menu_user_list')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/users" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_users' ? 'active' : '')?>">
                <div id="icom-sadm-users" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-users.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_user_list')); ?></div>
                <div id="left-num-sadm-users" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_sadm_users_inactives" title="<?php echo($this->lang('superadmin_menu_users_inactive')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/users/inactive" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_users_inactives' ? 'active' : '')?>">
                <div id="icom-sadm-users-inactive" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-user-inactive.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_users_inactive')); ?></div>
                <div id="left-num-sadm-users-inactive" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_sadm_users_reqdelete" title="<?php echo($this->lang('superadmin_menu_request_delete')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/users/reqdelete" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_users_reqdelete' ? 'active' : '')?>">
                <div id="icom-sadm-users-reqdelete" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-user-req-del.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_request_delete')); ?></div>
                <div id="left-num-sadm-users-reqdelete" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_sadm_users_admins" title="<?php echo($this->lang('superadmin_menu_users_admin')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/users/admins" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_users_admins' ? 'active' : '')?>">
                <div id="icom-sadm-users-admins" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-users-admin.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_users_admin')); ?></div>
                <div id="left-num-sadm-users-admins" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm"></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_pages" title="<?php echo($this->lang('superadmin_menu_pages_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/pages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_pages' ? 'active' : '')?>">
                <div id="icom-sadm-pages" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-pages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_pages_created')); ?></div>
                <div id="left-num-sadm-pages" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_sadm_pages_categories" title="<?php echo($this->lang('superadmin_menu_pages_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/pages/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_pages_categories' ? 'active' : '')?>">
                <div id="icom-sadm-pages-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-pages-categories.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_pages_categories')); ?></div>
                <div id="left-num-sadm-pages-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_groups" title="<?php echo($this->lang('superadmin_menu_groups_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/groups" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_groups' ? 'active' : '')?>">
                <div id="icom-sadm-groups" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-groups.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_groups_created')); ?></div>
                <div id="left-num-sadm-groups" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_products" title="<?php echo($this->lang('superadmin_menu_products_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/products" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_products' ? 'active' : '')?>">
                <div id="icom-sadm-products" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-products.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_products_created')); ?></div>
                <div id="left-num-sadm-products" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_sadm_products_categories" title="<?php echo($this->lang('superadmin_menu_products_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/products/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_products_categories' ? 'active' : '')?>">
                <div id="icom-sadm-products-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-cat-products.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_products_categories')); ?></div>
                <div id="left-num-sadm-products-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_articles" title="<?php echo($this->lang('superadmin_menu_articles_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/articles" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_articles' ? 'active' : '')?>">
                <div id="icom-sadm-articles" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-articles.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_articles_created')); ?></div>
                <div id="left-num-sadm-articles" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_sadm_articles_categories" title="<?php echo($this->lang('superadmin_menu_articles_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/articles/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_articles_categories' ? 'active' : '')?>">
                <div id="icom-sadm-articles-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-cat-articles.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_articles_categories')); ?></div>
                <div id="left-num-sadm-articles-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
     
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_sadm_games" title="<?php echo($this->lang('superadmin_menu_games')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/games" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_games' ? 'active' : '')?>">
                <div id="icom-sadm-games" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-games.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_games')); ?></div>
                <div id="left-num-sadm-games" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
        
        <div id="opt_sadm_currencies_companies" title="<?php echo($this->lang('superadmin_menu_currencies_companies')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/currencies-companies" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_currencies' ? 'active' : '')?>">
                <div id="icom-sadm-currencies-companies" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-currencies.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_currencies_companies')); ?></div>
                <div id="left-num-sadm-currencies-companies" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>

        <div id="opt_sadm_adssetting" title="<?php echo($this->lang('superadmin_menu_ads_settings')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/ads/setting" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_adssetting' ? 'active' : '')?>">
                <div id="icom-sadm-adssetting" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-settings-ads.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_ads_settings')); ?></div>
                <div id="left-num-sadm-adssetting" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_sadm_adsdash" title="<?php echo($this->lang('superadmin_menu_ads_dashboard')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/ads/dashboard" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_adsdash' ? 'active' : '')?>">
                <div id="icom-sadm-adsdash" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-ads-basic-d.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_ads_dashboard')); ?></div>
                <div id="left-num-sadm-adsdash" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_sadm_adsprof" title="<?php echo($this->lang('superadmin_menu_ads_profile')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/ads/profile" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_adsprof' ? 'active' : '')?>">
                <div id="icom-sadm-adsprof" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-ads-basic-p.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_ads_profile')); ?></div>
                <div id="left-num-sadm-adsprof" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
            
        <div id="opt_sadm_staticpages_companies" title="<?php echo($this->lang('superadmin_menu_static_pages_companies')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>superadmin/static-pages-companies" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_sadm_staticpages_companies' ? 'active' : '')?>">
                <div id="icom-sadm-staticpages-companies" class="ico-mini"><img src="<?php echo getImageTheme('ico-superadmin-static-pages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('superadmin_menu_static_pages_companies')); ?></div>
                <div id="left-num-sadm-staticpages-companies" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
    </div>
    
    
</div>

<div class="mrg30B"></div>

<script>$('div#dashboard-main-area-left').theiaStickySidebar({additionalMarginTop: 51});</script>
