    <div id="space-forms-actions"></div>   

    <div id="login-company" class="space-box">
        
        <div id="space-login-c">

            <div id="titleform"><?php echo $this->lang('company_login_title'); ?></div>
    
            <div id="area-form">
                <form id="formlogin" name="formlogin" method="post">
    
                <div><input type="text" class="boxinput" name="username" id="username" placeholder="<?php echo $this->lang('company_login_username_or_email')?>" value="<?php echo $D->the_email_in_login; ?>"></div>
                <div id="alert-username" class="alert alert-red hide"></div>
                
    
                <div style="margin-top:30px;"><input type="password" class="boxinput" name="password" id="password" placeholder="<?php echo $this->lang('company_login_password')?>"></div>
                <div id="alert-password" class="alert alert-red hide"></div>
                <div id="link-forgot"><?php echo $this->lang('company_login_forgot_password')?></div>
    
                <div id="alert-error-form" class="alert alert-red hide"></div>
                <div id="areabutton"><button class="btn-lg-yellow" name="go_login" id="go_login" type="submit"><?php echo $this->lang('company_login_bsubmit')?></button></div>

                <?php if ($D->sett_comp_allow_register) { ?>
                <div id="link-register"><?php echo $this->lang('company_login_link_register')?></div>
                <?php } ?>
                
                </form>
                
                <script>
            
                    var error_username = stripslashes('<?php echo strJS($this->lang('company_login_error_username_empty'))?>');
                    var error_password = stripslashes('<?php echo strJS($this->lang('company_login_error_password_empty'))?>');
                    var ccompany = '<?php echo $D->codecompany; ?>';

                    (function($) {
                        "use strict";

                        $('#go_login').on("click", function(){ 
                            login('#alert-error-form', '#go_login');
                            return false;
                        });
                        
                        <?php if (!empty($D->the_email_in_login)) { ?>
                        $('#password').focus();
                        <?php } ?>
                        
                        goAnchor('#space-forms-actions');
                    })(jQuery);
                </script>
    
            </div>
    
        </div>
        
        <div id="recovery-pass-company">
        
            <div id="space-recovery-pass-c">
            
                <div id="titleform"><?php echo $this->lang('company_login_reset_title'); ?></div>  
            
                <form id="formreset" name="formreset" method="post">
    
                    <div><input type="text" class="boxinput" name="email_rec" id="email_rec" placeholder="<?php echo $this->lang('company_login_reset_username')?>"></div>
                    <div id="alert-email-rec" class="alert alert-red hide"></div>
        
                    <div id="alert-error-form-rec" class="alert alert-red hide"></div>
                    <div id="areabutton"><button class="btn-lg-green" name="go_reset" id="go_reset" type="submit"><?php echo $this->lang('company_login_reset_bsubmit')?></button></div>
                    
                    <div id="link-login"><?php echo $this->lang('company_login_link_login')?></div>
    
                </form>
                
                <script>
                    var error_email = stripslashes('<?php echo strJS($this->lang('company_login_reset_error_email'))?>');

                    (function($) {
                        "use strict";

                        $('#go_reset').on('click', function(){ 
                            resetpass('#formreset', '#divok', '#alert-error-form-rec', '#go_reset');
                            return false;
                        });
                    })(jQuery);
                </script>
                
            </div>
            
            <div id="divok" class="space_reset_msg_ok hide"></div>
        
        </div>

        <?php if ($D->sett_comp_allow_register) { ?>

        <div id="register-user-company">
            
            <div id="space-register-c">  
            
                <div id="titleform"><?php echo $this->lang('company_register_title'); ?></div>  
            
                <form id="formregister" name="formregister" method="post">
    
                    <div><input type="text" class="boxinput" name="firstname_signup" id="firstname_signup" placeholder="<?php echo $this->lang('signup_firstname')?>"></div>

                    <div style="margin-top:10px;"><input type="text" class="boxinput" name="lastname_signup" id="lastname_signup" placeholder="<?php echo $this->lang('signup_lastname')?>"></div>

                    <div style="margin-top:10px;"><input type="text" class="boxinput" name="email_signup" id="email_signup" placeholder="<?php echo $this->lang('signup_email')?>"></div>

                    <div style="margin-top:10px;"><input type="text" class="boxinput" name="username_signup" id="username_signup" placeholder="<?php echo $this->lang('signup_username')?>"></div>
                    
                    <div style="margin-top:10px;"><input type="password" class="boxinput" name="password_signup" id="password_signup" placeholder="<?php echo $this->lang('signup_password')?>"></div>


                    <div style="margin-top:15px; text-align:center;">
                    
                        <div class="title_block_form"><?php echo $this->lang('signup_birthday')?></div>
                    
                        <span>
                        <select name="bmonth_signup" id="bmonth_signup" class="boxcombo">
                        <option value="-1"><?php echo $this->lang('signup_birthday_month')?>:</option>
                        <option value="1"><?php echo $this->lang('signup_birthday_jan')?></option>
                        <option value="2"><?php echo $this->lang('signup_birthday_feb')?></option>
                        <option value="3"><?php echo $this->lang('signup_birthday_mar')?></option>
                        <option value="4"><?php echo $this->lang('signup_birthday_apr')?></option>
                        <option value="5"><?php echo $this->lang('signup_birthday_may')?></option>
                        <option value="6"><?php echo $this->lang('signup_birthday_jun')?></option>
                        <option value="7"><?php echo $this->lang('signup_birthday_jul')?></option>
                        <option value="8"><?php echo $this->lang('signup_birthday_aug')?></option>
                        <option value="9"><?php echo $this->lang('signup_birthday_sep')?></option>
                        <option value="10"><?php echo $this->lang('signup_birthday_oct')?></option>
                        <option value="11"><?php echo $this->lang('signup_birthday_nov')?></option>
                        <option value="12"><?php echo $this->lang('signup_birthday_dec')?></option>
                        </select>
                        </span>
    
                        <span>
                        <select name="bday_signup" id="bday_signup" class="boxcombo">
                        <option value="-1"><?php echo $this->lang('signup_birthday_day')?>:</option>
                        <?php for ($x=1; $x<=31; $x++) { ?>
                        <option value="<?php echo $x?>"><?php echo $x?></option>
                        <?php } ?>          
                        </select>
                        </span>
    
                        <span>
                        <select name="byear_signup" id="byear_signup" class="boxcombo">
                        <option value="-1"><?php echo $this->lang('signup_birthday_year')?>:</option>
                        <?php for ($x=date("Y"); $x>=(date("Y")-110); $x--) { ?>
                        <option value="<?php echo $x?>"><?php echo $x?></option>
                        <?php } ?>                
                        </select>
                        </span>

                    
                    </div>
                    
                    
                    <div style="margin-top:15px; text-align:center;">
                    
                        <div class="title_block_form"><?php echo $this->lang('signup_gender')?></div>

                        <div id="rgender">
                            <span><input name="sex" value="1" id="sex1" type="radio"><label><?php echo $this->lang('signup_gender_male')?></label></span>
                            <span class="spaceradio"><input name="sex" value="2" id="sex2" type="radio"><label><?php echo $this->lang('signup_gender_female')?></label></span>
                        </div>
                    </div>

        
                    <div id="alert-error-form-register" class="alert alert-red hide" style="margin-top:15px;"></div>
                    <div id="areabutton"><button class="btn-lg-blue" name="go_register" id="go_register" type="submit"><?php echo $this->lang('company_register_bsignup')?></button></div>
                    
                    <input name="valGender" type="hidden" id="valGender" value="">
                    
                    <div id="link-login-2"><?php echo $this->lang('company_login_link_login')?></div>
    
                </form>

                <div id="divok-register" class="space_register_msg_ok hide"></div>
                
                <script>

                    var error_firstname = stripslashes('<?php echo strJS($this->lang('signup_error_firstname'))?>');
                    var error_lastname = stripslashes('<?php echo strJS($this->lang('signup_error_lastname'))?>');
                    var error_email = stripslashes('<?php echo strJS($this->lang('signup_error_email'))?>');
                    var error_username = stripslashes('<?php echo strJS($this->lang('signup_error_username'))?>');
                    var error_password = stripslashes('<?php echo strJS($this->lang('signup_error_password'))?>');
                    var error_birthday1 = stripslashes('<?php echo strJS($this->lang('signup_error_age_empty'))?>');
                    var error_birthday2 = stripslashes('<?php echo strJS($this->lang('signup_error_age'))?>');
                    var error_gender = stripslashes('<?php echo strJS($this->lang('signup_error_gender'))?>');
                    var ccpny = '<?php echo $D->codecompany; ?>';
                    var aftreg = '<?php echo $D->reg_after_register; ?>';

                    (function($) {
                        "use strict";

                        $("input[name=sex]").click(function () {
                            $('#valGender').val($(this).val());
                        });

                        $('#go_register').click(function(){ 
                            registerUserC('#formregister', '#divok-register', '#alert-error-form-register', '#go_register');
                            return false;
                        })
                        
                    })(jQuery);
                </script>
                
            </div>
        
        </div>
        <?php } ?>
        
        <script>
        (function($) {
            "use strict";

            $('#link-forgot').on('click', function(){
                $('#space-login-c').slideUp('slow', function(){
                    $('#recovery-pass-company').slideDown('slow');
                    goAnchor('#space-forms-actions');
                    $('#email_rec').focus();
                });
            });
    
            $('#link-login').on('click', function(){
                $('#recovery-pass-company').slideUp('slow', function(){
                    $('#space-login-c').slideDown('slow');
                    goAnchor('#space-forms-actions');
                });
            });

            <?php if ($D->sett_comp_allow_register) { ?>
            $('#link-register').on('click', function(){
                $('#space-login-c').slideUp('slow', function(){
                    $('#register-user-company').slideDown('slow');
                    goAnchor('#space-forms-actions');
                });
            });

            $('#link-login-2').on('click', function(){
                $('#register-user-company').slideUp('slow', function(){
                    $('#space-login-c').slideDown('slow');
                    goAnchor('#space-forms-actions');
                });
            });
            
            <?php } ?>
        
        })(jQuery);
        </script>

    </div>
