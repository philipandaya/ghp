<div class="boxax">
    <div class="boxax-header centered"><?php echo $this->lang('global_txt_advertising'); ?></div>
    <div class="boxax-body" style="padding:10px 12px;">

        <div id="announcement_free">
            <div class="ann-free-msg"><?php echo $this->lang('global_announcement_text',array('#SITE_TITLE#'=>'<br><span class="afm-themarc">'.$K->SITE_TITLE.'</span>')); ?></div>
            
            <div><a href="<?php echo $K->SITE_URL?>signup-free"><span class="afm-btnfree"><?php echo $this->lang('global_announcement_button'); ?></span></a></div>
            
            <div class="ann-free-subs"><?php echo $this->lang('global_announcement_subtext1'); ?></div>
            <div class="ann-free-subs"><?php echo $this->lang('global_announcement_subtext2'); ?></div>

        
        </div>
    
    </div>
</div>
<div style="margin-bottom:10px;"></div>