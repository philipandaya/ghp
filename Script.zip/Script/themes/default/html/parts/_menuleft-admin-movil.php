<div id="menuleft" class="slimscrollers">

    <div style="text-align:center; font-weight:500; font-size:14px; padding:4px 0 10px;" class="ellipsis"><?php echo $this->lang('admin_menu_title'); ?></div>
    <div class="separatorm "></div>
    
    <div>
    
        <div id="opt_adm_general" title="<?php echo($this->lang('admin_menu_general')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/general" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_general' ? 'active' : '')?>">
                <div id="icom-adm-general" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-general.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_general')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_mainmodules" title="<?php echo($this->lang('admin_menu_main_modules')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/mainmodules" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_mainmodules' ? 'active' : '')?>">
                <div id="icom-adm-mainmodules" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-main-modules.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_main_modules')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_membership" title="<?php echo($this->lang('admin_menu_membership')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/membership" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_membership' ? 'active' : '')?>">
                <div id="icom-adm-membership" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-membership.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_membership')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_yourbrand" title="<?php echo($this->lang('admin_menu_yourbrand')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/yourbrand" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_yourbrand' ? 'active' : '')?>">
                <div id="icom-adm-yourbrand" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-yourbrand.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_yourbrand')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <?php if ($K->WITH_CUST_DOM) { ?>
        <?php if ($D->company_with_cdomain == 1) { ?>
    <div>
    
        <div id="opt_adm_customdomain" title="<?php echo($this->lang('admin_menu_customdomain')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/customdomain" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_customdomain' ? 'active' : '')?>">
                <div id="icom-adm-customdomain" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-customdomain.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_customdomain')); ?></div>
                
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm"></div>
    
    </div>
        <?php } ?>
    <?php } ?>
    
    <div>

        <div id="opt_adm_registration_settings" title="<?php echo($this->lang('admin_menu_registration_settings')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/registrationsettings" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_registration_settings' ? 'active' : '')?>">
                <div id="icom-adm-registration-settings" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-userregistration.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_registration_settings')); ?></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>

        <div id="opt_adm_users" title="<?php echo($this->lang('admin_menu_user_list')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/users" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_users' ? 'active' : '')?>">
                <div id="icom-adm-users" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-users.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_user_list')); ?></div>
                <div id="left-num-adm-users" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_users_inactives" title="<?php echo($this->lang('admin_menu_users_inactive')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/users/inactive" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_users_inactives' ? 'active' : '')?>">
                <div id="icom-adm-users-inactive" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-user-inactive.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_users_inactive')); ?></div>
                <div id="left-num-adm-users-inactive" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_adm_users_reqdelete" title="<?php echo($this->lang('admin_menu_request_delete')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/users/reqdelete" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_users_reqdelete' ? 'active' : '')?>">
                <div id="icom-adm-users-reqdelete" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-user-req-del.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_request_delete')); ?></div>
                <div id="left-num-adm-users-reqdelete" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_users_admins" title="<?php echo($this->lang('admin_menu_users_admin')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/users/admins" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_users_admins' ? 'active' : '')?>">
                <div id="icom-adm-users-admins" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-users-admin.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_users_admin')); ?></div>
                <div id="left-num-adm-users-admins" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_users_pending" title="<?php echo($this->lang('admin_menu_users_pending')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/users/pending" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_users_pending' ? 'active' : '')?>">
                <div id="icom-adm-users-pending" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-users-pending.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_users_pending')); ?></div>
                <div id="left-num-adm-users-pending" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_pages" title="<?php echo($this->lang('admin_menu_pages_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/pages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_pages' ? 'active' : '')?>">
                <div id="icom-adm-pages" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-pages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_pages_created')); ?></div>
                <div id="left-num-adm-pages" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_pages_categories" title="<?php echo($this->lang('admin_menu_pages_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/pages/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_pages_categories' ? 'active' : '')?>">
                <div id="icom-adm-pages-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-pages-categories.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_pages_categories')); ?></div>
                <div id="left-num-adm-pages-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_groups" title="<?php echo($this->lang('admin_menu_groups_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/groups" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_groups' ? 'active' : '')?>">
                <div id="icom-adm-groups" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-groups.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_groups_created')); ?></div>
                <div id="left-num-adm-groups" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_products" title="<?php echo($this->lang('admin_menu_products_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/products" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_products' ? 'active' : '')?>">
                <div id="icom-adm-products" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-products.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_products_created')); ?></div>
                <div id="left-num-adm-products" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div id="opt_adm_products_categories" title="<?php echo($this->lang('admin_menu_products_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/products/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_products_categories' ? 'active' : '')?>">
                <div id="icom-adm-products-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-cat-products.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_products_categories')); ?></div>
                <div id="left-num-adm-products-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_articles" title="<?php echo($this->lang('admin_menu_articles_created')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/articles" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_articles' ? 'active' : '')?>">
                <div id="icom-adm-articles" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-articles.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_articles_created')); ?></div>
                <div id="left-num-adm-articles" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_articles_categories" title="<?php echo($this->lang('admin_menu_articles_categories')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/articles/categories" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_articles_categories' ? 'active' : '')?>">
                <div id="icom-adm-articles-categories" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-cat-articles.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_articles_categories')); ?></div>
                <div id="left-num-adm-articles-categories" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
     
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_games" title="<?php echo($this->lang('admin_menu_games')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/games" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_games' ? 'active' : '')?>">
                <div id="icom-adm-games" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-games.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_games')); ?></div>
                <div id="left-num-adm-games" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_currencies" title="<?php echo($this->lang('admin_menu_currencies')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/currencies" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_currencies' ? 'active' : '')?>">
                <div id="icom-adm-currencies" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-currencies.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_currencies')); ?></div>
                <div id="left-num-adm-currencies" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>

    <?php if ($K->ALLOW_ADVERTISING_ON_USER_ACCOUNT) { ?>
    
    <div>
    
        <div id="opt_adm_adsdash" title="<?php echo($this->lang('admin_menu_ads_dashboard')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/ads/dashboard" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_adsdash' ? 'active' : '')?>">
                <div id="icom-adm-pages" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-ads-basic-d.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_ads_dashboard')); ?></div>
                <div id="left-num-adm-adsdash" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
        
        <div id="opt_adm_adsprof" title="<?php echo($this->lang('admin_menu_ads_profile')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/ads/profile" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_adsprof' ? 'active' : '')?>">
                <div id="icom-adm-pages" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-ads-basic-p.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_ads_profile')); ?></div>
                <div id="left-num-adm-adsprof" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>

    <?php } ?>
    
    <div>
    
        <div id="opt_adm_themes" title="<?php echo($this->lang('admin_menu_themes')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/themes" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_themes' ? 'active' : '')?>">
                <div id="icom-adm-plugins" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-themes.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_themes')); ?></div>
                <div id="left-num-adm-themes" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    
    <div>
    
        <div id="opt_adm_lang" title="<?php echo($this->lang('admin_menu_languages')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/languages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_lang' ? 'active' : '')?>">
                <div id="icom-adm-lang" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-languages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_languages')); ?></div>
                <div id="left-num-adm-lang" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_timez" title="<?php echo($this->lang('admin_menu_timezone')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/timezone" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_timez' ? 'active' : '')?>">
                <div id="icom-adm-timez" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-timezone.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_timezone')); ?></div>
                <div id="left-num-adm-timez" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_adm_staticpages" title="<?php echo($this->lang('admin_menu_static_pages')); ?>">
            <a href="<?php echo $K->SITE_URL; ?>admin/static-pages" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_adm_staticpages' ? 'active' : '')?>">
                <div id="icom-adm-staticpages" class="ico-mini"><img src="<?php echo getImageTheme('ico-admin-static-pages.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo($this->lang('admin_menu_static_pages')); ?></div>
                <div id="left-num-adm-staticpages" class="txt-notif"></div>
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
    </div>
    
    <div class="mrg30B"></div>
    
</div>