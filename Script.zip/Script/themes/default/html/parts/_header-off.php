<!DOCTYPE html>
<head>
    <title><?php echo (isset($D->page_title)?$D->page_title:$K->SITE_TITLE); ?></title>
	<meta http-equiv="cleartype" content="on">
	<meta name="HandheldFriendly" content="True">
	<meta name="MobileOptimized" content="320">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?php echo $K->SITE_URL ?>" />
    <?php if ($K->FAVICON_TYPE == 0) { ?><link href="<?php echo getImageMisc($K->FAVICON_FILE); ?>" rel="shortcut icon"/><?php } ?>
    <?php if ($K->FAVICON_TYPE == 1) { ?><link rel="icon" type="image/png" href="<?php echo getImageMisc($K->FAVICON_FILE); ?>"/><?php } ?>    
    <link href="<?php echo $K->SITE_URL.'themes/'.$K->THEME;?>/css/off.css?v=<?php echo $K->VERSION; ?>" type="text/css" rel="stylesheet" media="all" />
    <?php require_once('_analytics.php');?>
</head>
<body class="back">
<div id="wrapper">