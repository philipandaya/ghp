
    <?php echo $D->thefootcompany; ?>