<div class="box-activity-no-item">
	<div class="inside-text">
    	<?php echo $D->message_text_empty; ?>
    </div>
</div>