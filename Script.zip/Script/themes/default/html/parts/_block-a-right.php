<?php if (!empty($D->html_ads_dashboard)) { ?>
<div class="boxax">
    <div class="boxax-header"><?php echo $this->lang('global_txt_advertising'); ?></div>
    <div class="boxax-body"><?php echo $D->html_ads_dashboard; ?></div>
</div>
<div style="margin-bottom:10px;"></div>
<?php } ?>

<?php if (isset($D->SHOW_ANNOUNCEMENT_FREE) && $D->SHOW_ANNOUNCEMENT_FREE) { ?>

<?php $this->load_template('parts/_announcement-free-profile.php'); ?>

<?php } ?>