
<div id="space-dashright">

    <?php if (!empty($D->html_myads_dash)) { ?>
    <div class="boxax">
        <div class="boxax-header"><?php echo $this->lang('global_txt_advertising'); ?></div>
        <div class="boxax-body"><?php echo $D->html_myads_dash; ?></div>
    </div>
    <div style="margin-bottom:10px;"></div>
    <?php } ?>

    <?php $this->load_template('parts/_block-a-right.php'); ?>

</div>


<?php $this->load_template('parts/_pseudo-foot.php'); ?>