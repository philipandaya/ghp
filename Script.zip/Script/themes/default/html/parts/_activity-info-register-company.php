<div class="box-activity centered">

    <div class="mrg20T"><img src="<?php echo $D->the_avatar_company_min; ?>"></div>

    <div class="mrg10T bold" style="font-size:15px;"><?php echo $D->the_title?></div>

    <div class="mrg10T mrg20B"><?php echo $this->lang('company_joined_when', array('#SITE_TITLE#'=>$K->SITE_TITLE))?> <?php echo date($this->lang('global_format_date'), $D->the_register_date)?></div>

</div>