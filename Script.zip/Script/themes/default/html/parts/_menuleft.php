<div id="menuleft">
    
    <a href="<?php echo $D->theURLCompany.$D->minicard_theusername; ?>" rel="phantom-all" target="dashboard-main-area" title="<?php echo $D->minicard_theallnameuser; ?>">
        <div id="left-infouser">
            <div id="avatar"><img src="<?php echo $D->minicard_theavatar; ?>"></div>
            <div id="username" class="ellipsis"><?php echo $D->minicard_thefirstnameuser; ?></div>
            <div class="clear"></div>
        </div>
    </a>
    
    <div>
    
        <div id="opt_ml_newsfeed" title="<?php echo $this->lang('dashboard_mleft_news_feed'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>dashboard" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_newsfeed' ? 'active' : '')?>">
                    <div id="icom-news" class="ico-mini"><img src="<?php echo getImageTheme('i-m-news.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_news_feed'); ?></div>
                    <div id="left-num-newsfeed" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <div id="opt_ml_messages" title="<?php echo $this->lang('dashboard_mleft_messages'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>messages" rel="phantom-all" target="dashboard-main-area">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_messages' ? 'active' : '')?>">
                    <div id="icom-messages" class="ico-mini"><img src="<?php echo getImageTheme('i-m-messages.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_messages'); ?></div>
                    <div id="left-num-messages" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <div id="opt_ml_albums" title="<?php echo $this->lang('dashboard_mleft_albums'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>albums" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_albums' ? 'active' : '')?>">
                    <div id="icom-albums" class="ico-mini"><img src="<?php echo getImageTheme('i-m-albums.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_albums'); ?></div>
                    <div id="left-num-albums" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>  

        <?php if ($D->sett_comp_mod_marketplace) { ?>

        <div id="opt_ml_myproducts" title="<?php echo $this->lang('dashboard_mleft_myproducts'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>products" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_myproducts' ? 'active' : '')?>">
                    <div id="icom-myproducts" class="ico-mini"><img src="<?php echo getImageTheme('i-m-myproducts.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_myproducts'); ?></div>
                    <div id="left-num-myproducts" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <?php } ?>

        <?php if ($D->sett_comp_mod_events) { ?>

        <div id="opt_ml_myevents" title="<?php echo $this->lang('dashboard_mleft_myevents'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>myevents" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_myevents' ? 'active' : '')?>">
                    <div id="icom-myevents" class="ico-mini"><img src="<?php echo getImageTheme('i-m-myevents.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_myevents'); ?></div>
                    <div id="left-num-myevents" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>  

        <?php } ?>

        <?php if ($D->sett_comp_mod_library) { ?>
    
        <div id="opt_ml_myarticles" title="<?php echo $this->lang('dashboard_mleft_myarticles'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>articles" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_myarticles' ? 'active' : '')?>">
                    <div id="icom-myarticles" class="ico-mini"><img src="<?php echo getImageTheme('i-m-myarticles.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_myarticles'); ?></div>
                    <div id="left-num-myarticles" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>  

        <?php } ?>
    
        <div id="opt_ml_savedp" title="<?php echo $this->lang('dashboard_mleft_saved_post'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>saved" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_savedp' ? 'active' : '')?>">
                    <div id="icom-savedp" class="ico-mini"><img src="<?php echo getImageTheme('i-m-saved.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_saved_post'); ?></div>
                    <div id="left-num-savedp" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>      
    
    </div>
    <div class="separatorm "></div>
    
    <?php if ($D->sett_comp_mod_pages) { ?>
    
    <div class="titleseparator"><?php echo $this->lang('dashboard_mleft_pages_title'); ?></div>
    
    <div>
    
        <div id="opt_ml_pagesfeed" title="<?php echo $this->lang('dashboard_mleft_pages_feed'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>pages/feed" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_pagesfeed' ? 'active' : '')?>">
                    <div id="icom-pages" class="ico-mini"><img src="<?php echo getImageTheme('i-m-pages.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_pages_feed'); ?></div>
                    <div id="left-num-pagesfeed" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div> 
        
        <div id="opt_ml_yourpages" title="<?php echo $this->lang('dashboard_mleft_your_pages'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>pages" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_yourpages' ? 'active' : '')?>">
                    <div id="icom-yourpages" class="ico-mini"><img src="<?php echo getImageTheme('i-m-yourpages.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_your_pages'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>     
    
        <div id="opt_ml_addpage" title="<?php echo $this->lang('dashboard_mleft_create_page'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>pages/create" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_addpage' ? 'active' : '')?>">
                    <div id="icom-addpage" class="ico-mini"><img src="<?php echo getImageTheme('i-m-addpage.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_create_page'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>   
    
        <div id="opt_ml_searchpages" title="<?php echo $this->lang('dashboard_mleft_search_pages'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>pages/search" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_searchpages' ? 'active' : '')?>">
                    <div id="icom-searchpages" class="ico-mini"><img src="<?php echo getImageTheme('i-m-searchpages.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_search_pages'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>  
    
    </div>
    <div class="separatorm "></div>
    
    <?php } ?>

    <?php if ($D->sett_comp_mod_groups) { ?>
    
    <div class="titleseparator"><?php echo $this->lang('dashboard_mleft_groups_title'); ?></div>
    
    <div>
    
        <div id="opt_ml_groupsfeed" title="<?php echo $this->lang('dashboard_mleft_groups_feed'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>groups/feed" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_groupsfeed' ? 'active' : '')?>">
                    <div id="icom-groupsfeed" class="ico-mini"><img src="<?php echo getImageTheme('i-m-newsgroups.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_groups_feed'); ?></div>
                    <div id="left-num-groupsfeed" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
    
        <div id="opt_ml_yourgroups" title="<?php echo $this->lang('dashboard_mleft_your_groups'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>groups" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_yourgroups' ? 'active' : '')?>">
                    <div id="icom-yourgroups" class="ico-mini"><img src="<?php echo getImageTheme('i-m-yourgroups.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_your_groups'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>
    
        <div id="opt_ml_addgroup" title="<?php echo $this->lang('dashboard_mleft_create_group'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>groups/create" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_addgroup' ? 'active' : '')?>">
                    <div id="icom-addgroup" class="ico-mini"><img src="<?php echo getImageTheme('i-m-addgroup.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_create_group'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>
    
        <div id="opt_ml_searchgroups" title="<?php echo $this->lang('dashboard_mleft_search_groups'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>groups/search" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_searchgroups' ? 'active' : '')?>">
                    <div id="icom-searchgroups" class="ico-mini"><img src="<?php echo getImageTheme('i-m-searchgroups.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_search_groups'); ?></div>
                    
                    <div class="clear"></div>
                </div>
            </a>
        </div>
    
    </div>
    <div class="separatorm "></div>

    <?php } ?>
    
    <div class="titleseparator"><?php echo $this->lang('dashboard_mleft_explore_title'); ?></div>
    
    <div>

        <?php if ($D->sett_comp_mod_games) { ?>
    
        <div id="opt_ml_games" title="<?php echo $this->lang('dashboard_mleft_games'); ?>">
            <a href="<?php echo $D->theURLCompany; ?>games" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_games' ? 'active' : '')?>">
                    <div id="icom-games" class="ico-mini"><img src="<?php echo getImageTheme('i-m-games.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_games'); ?></div>
                    <div id="left-num-games" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>

        <?php } ?>

        <?php if ($D->sett_comp_mod_marketplace) { ?>

        <div id="opt_ml_marketplace" title="<?php echo $this->lang('dashboard_mleft_marketplace'); ?>">
            <a href="<?php echo $D->theURLCompany; ?>marketplace" rel="phantom-all" target="dashboard-main-area">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_marketplace' ? 'active' : '')?>">
                    <div id="icom-marketplace" class="ico-mini"><img src="<?php echo getImageTheme('i-m-marketplace.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_marketplace'); ?></div>
                    <div id="left-num-marketplace" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <?php } ?>
    
        <?php if ($D->sett_comp_mod_events) { ?>
        
        <div id="opt_ml_events" title="<?php echo $this->lang('dashboard_mleft_events'); ?>">
            <a href="<?php echo $D->theURLCompany; ?>events" rel="phantom" target="dashboard-main-area-right">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_events' ? 'active' : '')?>">
                    <div id="icom-events" class="ico-mini"><img src="<?php echo getImageTheme('i-m-events.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_events'); ?></div>
                    <div id="left-num-events" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <?php } ?>

        <?php if ($D->sett_comp_mod_library) { ?>
    
        <div id="opt_ml_library" title="<?php echo $this->lang('dashboard_mleft_library'); ?>">
            <a href="<?php echo $D->theURLCompany; ?>library" rel="phantom-max" target="dashboard-main-area">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_library' ? 'active' : '')?>">
                    <div id="icom-library" class="ico-mini"><img src="<?php echo getImageTheme('i-m-library.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_library'); ?></div>
                    <div id="left-num-library" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>

        <?php } ?>
    
        <div id="opt_ml_directory" title="<?php echo $this->lang('dashboard_mleft_directory'); ?>">
            <a href="<?php echo $D->theURLCompany; ?>directory" rel="phantom-max" target="dashboard-main-area">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_directory' ? 'active' : '')?>">
                    <div id="icom-directory" class="ico-mini"><img src="<?php echo getImageTheme('i-m-directory.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_directory'); ?></div>
                    <div id="left-num-library" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
        
        <div id="opt_ml_friendsl" title="<?php echo $this->lang('dashboard_mleft_friends'); ?>">
            <a href="<?php echo $D->theURLCompany.$this->user->info->user_username; ?>/friends" rel="phantom-max" target="dashboard-main-area">
                <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_ml_friendsl' ? 'active' : '')?>">
                    <div id="icom-friendsl" class="ico-mini"><img src="<?php echo getImageTheme('i-m-friends.png'); ?>"></div>
                    <div class="txt-opc ellipsis"><?php echo $this->lang('dashboard_mleft_friends'); ?></div>
                    <div id="left-num-friendsl" class="txt-notif"></div>
                    <div class="clear"></div>
                </div>
            </a>
        </div>
    
    </div>
    
</div>

<div class="mrg30B"></div>

<script>$('div#dashboard-main-area-left').theiaStickySidebar({additionalMarginTop: 51});</script>
