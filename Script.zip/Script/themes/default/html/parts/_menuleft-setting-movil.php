<div id="menuleft" class="slimscrollers">

    <div id="bar-title" class="ellipsis"><?php echo $this->lang('setting_menu_title'); ?></div>
    <div class="separatorm "></div>
    
    <div>
    
        <div id="opt_set_account" title="<?php echo $this->lang('setting_menu_account'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>settings/account" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_set_account' ? 'active' : '')?>">
                <div id="icom-set-acount" class="ico-mini"><img src="<?php echo getImageTheme('ico-set-account.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo $this->lang('setting_menu_account'); ?></div>
    
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_set_profile" title="<?php echo $this->lang('setting_menu_profile'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>settings/profile" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_set_profile' ? 'active' : '')?>">
                <div id="icom-set-profile" class="ico-mini"><img src="<?php echo getImageTheme('ico-set-profile.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo $this->lang('setting_menu_profile'); ?></div>
    
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_set_privacy" title="<?php echo $this->lang('setting_menu_privacy'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>settings/privacy" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_set_privacy' ? 'active' : '')?>">
                <div id="icom-set-privacy" class="ico-mini"><img src="<?php echo getImageTheme('ico-set-privacy.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo $this->lang('setting_menu_privacy'); ?></div>
    
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_set_blocked" title="<?php echo $this->lang('setting_menu_blocked'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>settings/blocked" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_set_blocked' ? 'active' : '')?>">
                <div id="icom-set-blocked" class="ico-mini"><img src="<?php echo getImageTheme('ico-set-blocking.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo $this->lang('setting_menu_blocked'); ?></div>
    
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
        <div class="separatorm "></div>
    
    </div>
    
    <div>
    
        <div id="opt_set_delete" title="<?php echo $this->lang('setting_menu_delete'); ?>">
            <a href="<?php echo $K->SITE_URL; ?>settings/delete" rel="phantom" target="dashboard-main-area-right">
            <div class="opc-menu-left <?php (isset($D->id_menu) && $D->id_menu == 'opt_set_delete' ? 'active' : '')?>">
                <div id="icom-set-delete" class="ico-mini"><img src="<?php echo getImageTheme('ico-set-delete.png'); ?>"></div>
                <div class="txt-opc ellipsis"><?php echo $this->lang('setting_menu_delete'); ?></div>
    
                <div class="clear"></div>
            </div>
            </a>
        </div>
    
    </div>
    
    <div class="mrg30B"></div>
    
</div>
