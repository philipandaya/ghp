<div class="space-action-ok">
    <div class="sao-msg01"><?php echo $this->lang('admin_users_add_you_have'); ?> <a href="<?php echo $D->theurl_user_new; ?>" rel="phantom-all" target="dashboard-main-area"><?php echo $D->name_user_new; ?></a>.</div>
    <div class="sao-space-btn"><a href="<?php echo $K->SITE_URL?>admin/users/add" rel="phantom" target="dashboard-main-area-right"><span class="mybtn-flat-green"><?php echo $this->lang('admin_users_add_bother')?></span></a></div>
</div>