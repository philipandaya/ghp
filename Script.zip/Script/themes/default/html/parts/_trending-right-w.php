<div class="box-activity" style="margin-bottom:10px;">

    <div class="sugestion-peoples">
    
        <div class="title-bar"><?php echo $this->lang('global_txt_trending'); ?></div>
        
        <div class="the-body">
        
            <div class="list-sug-people">
                <?php echo $D->html_hashtags; ?>
            </div>
        
        </div>
    
    
    </div>
    
</div>