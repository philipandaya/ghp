
                <div class="box-white mrg30B">

                    <div class="mrg50T mrg30B" style="font-size:16px; font-weight:500;"><p class="centered"><?php echo $this->lang('profile_group_isrestricted')?></p></div>

                    <div class="mrg50B" style="font-size:14px;"><p class="centered"><?php echo $this->lang('profile_group_isrestricted_msg')?></p></div>

                </div>
