<?php
if (isset($this->params->info_who) && $this->params->info_who == 1) {
    $cad_username_company = '';
    $cad_company_name = $K->COMPANY;
    $show_options_basic = TRUE;
} else {
    $cad_username_company = $D->company_username_out.'/';
    $cad_company_name = $D->company_name_out;
    $show_options_basic = FALSE;
}

if (isset($K->wCusDomain) && $K->wCusDomain) $cad_username_company = '';
?>
    <div id="foot-general">

        <div class="separator"></div>

        <div id="space-foot-one">
        
            <?php if (!$show_options_basic) { ?>
        
            <span class="opc-foot">
                <a href="<?php echo $K->SITE_URL.$cad_username_company; ?>marketplace" <?php echo($D->_IS_LOGGED ? 'rel="phantom-all" target="dashboard-main-area"' : '') ?>><span class="opc-foot-text"><?php echo $this->lang('global_opc_foot_marketplace'); ?></span></a>
            </span>
            
            <span class="opc-foot">
                <a href="<?php echo $K->SITE_URL.$cad_username_company; ?>library" <?php echo($D->_IS_LOGGED ? 'rel="phantom-all" target="dashboard-main-area"' : '') ?>><span class="opc-foot-text"><?php echo $this->lang('global_opc_foot_library'); ?></span></a>
            </span>
            
            <?php } ?>

        <?php

        if (empty($cad_username_company)) {
            $statics = getStaticsFoot();
        } else {
            $statics = getStaticsFootCompany($D->company_id);
        }

        if ($statics) {

            foreach ($statics as $onest) { ?>

            <span class="opc-foot">
                <a href="<?php echo $K->SITE_URL.$cad_username_company.'info/'.$onest->url?>" <?php echo($D->_IS_LOGGED ? 'rel="phantom-all" target="dashboard-main-area"' : '') ?>><span class="opc-foot-text"><?php echo $onest->title ?></span></a>
            </span>

        <?php 
            }
        }
        ?>

        </div>

        <div id="space-foot-two">

            <?php echo $cad_company_name; ?> &copy; <?php echo date('Y'); ?>

        </div>

        <div class="clear"></div>

    </div>