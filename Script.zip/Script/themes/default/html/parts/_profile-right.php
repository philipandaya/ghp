<?php if (!empty($D->html_myads_prof)) { ?>
<div class="boxax">
    <div class="boxax-header"><?php echo $this->lang('global_txt_advertising'); ?></div>
    <div class="boxax-body"><?php echo $D->html_myads_prof; ?></div>
</div>
<div style="margin-bottom:10px;"></div>
<?php } ?>


<div id="space-profright" style="margin-top:10px;">

    <?php $this->load_template('parts/_block-a-right-profile.php'); ?>

</div>

<div style="margin-bottom:10px;"></div>

<script>
$('#profile-main-area-right').theiaStickySidebar({additionalMarginTop: 61});
</script>
