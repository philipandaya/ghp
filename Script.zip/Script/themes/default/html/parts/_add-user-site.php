<div class="space-actions-admin-dash">
    <div class="saad-inside">
        <a href="<?php echo $K->SITE_URL; ?>admin/users/add" rel="phantom-all" target="dashboard-main-area">
        <div class="saad-area-1">
            <div class="saad-box-icon"><img src="<?php echo getImageTheme('ico-add-user.png'); ?>" alt=""></div>
            <div class="saad-box-text"><?php echo $this->lang('dashboard_txt_add_user'); ?></div>
        </div>
        </a>
        <a href="<?php echo $K->SITE_URL; ?>admin/users" rel="phantom-all" target="dashboard-main-area">
        <div class="saad-area-2">
            <div class="saad-box-icon"><img src="<?php echo getImageTheme('ico-list-users.png'); ?>" alt=""></div>
            <div class="saad-box-text"><?php echo $this->lang('dashboard_txt_user_list'); ?></div>
        </div>
        </a>
        <div class="clear"></div>
    </div>
</div>