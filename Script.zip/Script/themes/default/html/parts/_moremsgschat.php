<div id="space-btn-more-msgs-chat-<?php echo $D->codeu; ?>" class="chat-spacebtn-moremsgs">
    <span id="bmoremsgschat-<?php echo $D->codeu; ?>" class="chat-bmoremsgs"><?php echo $this->lang('global_chat_more_msgs'); ?></span>
</div>
<div id="preload-moremsgschat-<?php echo $D->codeu; ?>" class="k-preloader hide"></div>

<script>
    $('#bmoremsgschat-<?php echo $D->codeu; ?>').on('click', function(e){
        e.preventDefault();
        moreMsgsInChat('<?php echo $D->codeu; ?>');
    });
</script>
<div id="space-more-msgs-chat-<?php echo $D->codeu; ?>"></div>