    <script> var msg_error_conection = stripslashes('<?php echo strJS($this->lang('global_txt_cannotperform'))?>'); </script>
    <div id="topbar-basic">
        <div class="spacetop">

            <a href="<?php echo $K->SITE_URL;?>" title="<?php htmlspecialchars($K->SITE_TITLE); ?>">
                <div id="logo">
                    <span id="logo-normal"><img src="<?php echo((isset($D->logo_company_bar_top) && !empty($D->logo_company_bar_top)) ? $D->logo_company_bar_top : getImageMisc($K->LOGOTIPO_OUT)); ?>"></span>
                    <span id="logo-mini"><img src="<?php echo((isset($D->isotipo_resp_company_bar_top) && !empty($D->isotipo_resp_company_bar_top)) ? $D->isotipo_resp_company_bar_top : getImageMisc($K->ISOTIPO_OUT)); ?>">"></span>
                </div>
            </a>            
            
            
            
            <div id="options-top-basic">
                <div id="opc_login_top" class="opc-menu-top-basic">
                    <a href="<?php echo $K->SITE_URL; ?>login"><?php echo $this->lang('global_txt_login'); ?></a>
                </div>
                <div class="clear"></div>
            </div>            
            
        </div>
    </div>

    <div class="clear"></div>

    <div id="space-below-top-basic"></div>

    <div id="item-card" class="_emerged"></div>

    <!-- layout modal -->

    <div id="the-modal" class="hide">
        <div id="the-modal-content"></div>
    </div>

    <script>

	$('#item-card').mouseleave(function() {
		$('#item-card').hide();
	});

    </script>