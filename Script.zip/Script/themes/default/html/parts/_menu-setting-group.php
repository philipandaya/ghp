    <div class="box-for-menu">

        <span class="one-opc"><a href="<?php echo $D->theURLCompany.$D->username?>/settings" <?php echo($D->_IS_LOGGED ? 'rel="phantom" target="profile-content-area"' : '') ?>><?php echo $this->lang('setting_group_opc_settings')?></a></span>

        <span class="one-opc"><a href="<?php echo $D->theURLCompany.$D->username?>/requests" <?php echo($D->_IS_LOGGED ? 'rel="phantom" target="profile-content-area"' : '') ?>><?php echo $this->lang('setting_group_opc_requests')?></a></span>

    </div>