<div class="box-activity">

    <div id="logo-welcome"><img src="<?php echo((isset($D->img_welcome_dash) && !empty($D->img_welcome_dash)) ? $D->img_welcome_dash : getImageMisc($K->IMG_WELCOME_DASH)); ?>"></div>
    <div id="msg-welcome"><?php echo $this->lang('dashboard_welcome', array('#SITE_TITLE#' => ((isset($D->name_company_welcome) && !empty($D->name_company_welcome)) ? '<br><span class="bold">'.$D->name_company_welcome.'</span>' : '<br><span class="bold">'.$K->SITE_TITLE.'</span>')))?></div>

</div>