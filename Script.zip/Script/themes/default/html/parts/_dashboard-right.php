<div id="space-dashright">

    <div>
        <?php if ($D->_IS_ADMIN_USER) { ?>
        
        <?php $this->load_template('parts/_status-plan.php'); ?>
        
        <?php $this->load_template('parts/_add-user-site.php'); ?>
        
        <?php } ?>


        <?php if (!empty($D->html_myads_dash)) { ?>
        <div class="boxax">
            <div class="boxax-header"><?php echo $this->lang('global_txt_advertising'); ?></div>
            <div class="boxax-body"><?php echo $D->html_myads_dash; ?></div>
        </div>
        <div style="margin-bottom:10px;"></div>
        <?php } ?>


    <?php if (isset($D->html_hashtags) && !empty($D->html_hashtags)) { ?>
    <?php $this->load_template('parts/_trending-right-w.php'); ?>
    <?php } ?>


    <?php if (isset($D->SHOW_SUGGESTIONS_PEOPLE) && $D->SHOW_SUGGESTIONS_PEOPLE) { ?>

    <?php $this->load_template('parts/_users-right-w.php'); ?>

    <?php } ?>

    <?php $this->load_template('parts/_block-a-right.php'); ?>


    </div>

</div>

<?php $this->load_template('parts/_pseudo-foot.php'); ?>

<script>
$('#dashboard-main-right').theiaStickySidebar({additionalMarginTop:62});
</script>