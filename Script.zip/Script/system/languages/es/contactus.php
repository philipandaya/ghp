<?php	
$lang = array (
    
    'contactus_title' => 'Escríbenos un comentario',
    'contactus_subtitle' => 'Responderemos todas tus preguntas que tengas sobre nuestro servicio.',

    'contactus_form_names' => 'Nombres',
    'contactus_form_company' => 'Empresa',
    'contactus_form_email' => 'Correo electrónico',
    'contactus_form_phone' => 'Teléfono',
    'contactus_form_comment' => 'Tu comentario',
    'contactus_form_bsend' => 'Enviar formulario',

    'contactus_form_error_names' => 'Debes ingresar tus nombres',
    'contactus_form_error_company' => 'Debes ingresar el nombre de tu empresa',
    'contactus_form_error_email' => 'Debes ingresar un email válido',
    'contactus_form_error_phone' => 'Debes ingresar un número de teléfono',
    'contactus_form_error_comment' => 'Debes ingresar un comentario',

    'contactus_form_msgok_01' => 'Hemos recibido tu mensaje.',
    'contactus_form_msgok_02' => 'Te responderemos a la brevedad posible.',
    'contactus_form_msgok_03' => 'Gracias por escribirnos.',


);	
?>