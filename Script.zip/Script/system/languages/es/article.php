<?php 
$lang = array(
    'article_demo' => 'Demo',
);
?>