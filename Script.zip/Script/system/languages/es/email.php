<?php     
    $lang = array(

        'email_validation_subject' => 'Confirma tu cuenta en #SITE_TITLE#',
        'email_validation_hello' => 'Hola,',          
        'email_validation_msg01' => 'Para confirmar su registro en #SITE_TITLE#, por favor siga el siguiente enlace:',
        'email_validation_msg02' => 'En caso de que no se haya registrado en nuestro servicio, simplemente ignore este mensaje.',
        'email_validation_signature' => 'Un cordial saludo,<br/><br/>#SITE_TITLE#',
        
        'email_recovery_subject' => 'Recuperación de contraseña en #SITE_TITLE#',
        'email_recovery_hello' => 'Hola,',
        'email_recovery_msg1' => 'Para restaurar su contraseña en #SITE_TITLE#, por favor siga el siguiente enlace:',
        'email_recovery_msg2' => 'En caso de que no haya solicitado una recuperación de contraseña, simplemente ignore este mensaje.',
        'email_recovery_signature' => 'Un cordial saludo,<br/><br/>#SITE_TITLE#',
        
        'email_contactus_subject' => 'Un mensaje desde #SITE_TITLE#',
        'email_contactus_hello' => 'Hola,',
        'email_contactus_msg1' => 'Un mensaje, con los siguientes datos, ha sido recibido desde el sitio web:',
        'email_contactus_txt_names' => 'Nombres',
        'email_contactus_txt_company' => 'Empresa',
        'email_contactus_txt_email' => 'Email',
        'email_contactus_txt_phone' => 'Teléfono',
        'email_contactus_txt_comment' => 'Comentario',
        'email_contactus_signature' => 'Saludos,<br/><br/>#SITE_TITLE#',

        'email_notifcdomain_subject' => 'Activación de un Dominio Personalizado en #SITE_TITLE#',
        'email_notifcdomain_hello' => 'Hola,',
        'email_notifcdomain_msg1' => 'Un usuario ha solicitado activación de su Dominio Personalizado.',
        'email_notifcdomain_txt_user' => 'Usuario',
        'email_notifcdomain_txt_company' => 'Empresa',
        'email_notifcdomain_txt_url' => 'URL del Dominio Personalizado',
        'email_notifcdomain_signature' => 'Saludos,<br/><br/>#SITE_TITLE#',
    
    );     
?>