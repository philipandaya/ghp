<?php
$lang = array (
    'login_title_page' => 'Iniciar sesión en #SITE_TITLE#',
    'login_title' => 'Ingresar',
    'login_email' => 'Correo electrónico',
    'login_email_placeholder' => 'Ingresa tu email',
    'login_bsubmit' => 'Siguiente',   

    'login_error_email' => 'Debes ingresar un email válido.',  
    
    /*******************************/
    /********* INIT v1.2.0 *********/

    'resetpass_title_page' => 'Restablecer Contraseña',
    'resetpass_title' => 'Restablecer Contraseña',
    'resetpass_newpass' => 'Nueva contraseña',
    'resetpass_re_newpass' => 'Reingrese nueva contraseña',
    'resetpass_bupdate' => 'Actualizar contraseña',
    'resetpass_msg1' => '¡Error al restaurar la contraseña!',
    'resetpass_msg_error1' => 'Debes ingresar una nueva contraseña',
    'resetpass_msg_error2' => 'Las contraseñas deben tener entre 6 a 20 caracteres',
    'resetpass_msg_error3' => 'Las contraseñas no concuerdan',
    'resetpass_msg4' => 'Ingresar ahora',
    'resetpass_msg_ok' => '¡Reinicio de Contraseña exitoso!',


    /********** END v1.2.0 *********/
    /*******************************/

  
);
?>