<?php
$current_language = (object) array (
    'name'  => 'Español',
    'author_name' => 'MCode Developer',
    'author_url' => 'https://www.mcodedeveloper.com',
);
?>