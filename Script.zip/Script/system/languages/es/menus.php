<?php	
$lang = array(
    'dashboard_mleft_news_feed' => 'Noticias',
    'dashboard_mleft_messages' => 'Mensajes',
    'dashboard_mleft_photos' => 'Fotos',
    'dashboard_mleft_events' => 'Eventos',
    'dashboard_mleft_myproducts' => 'Mis Productos',
    'dashboard_mleft_marketplace' => 'Marketplace',
    'dashboard_mleft_myarticles' => 'Mis Artículos',
    'dashboard_mleft_library' => 'Librería',
    'dashboard_mleft_myevents' => 'Mis Eventos',
    
    'dashboard_mleft_pages_title' => 'Páginas',
    'dashboard_mleft_pages_feed' => 'Noticias de Páginas',
    'dashboard_mleft_your_pages' => 'Tus Páginas',
    'dashboard_mleft_create_page' => 'Crear Página',
    'dashboard_mleft_search_pages' => 'Buscar Páginas',
    
    'dashboard_mleft_groups_title' => 'Grupos',
    'dashboard_mleft_groups_feed' => 'Noticias de Grupos',
    'dashboard_mleft_your_groups' => 'Tus Grupos',
    'dashboard_mleft_create_group' => 'Crear Grupo',
    'dashboard_mleft_search_groups' => 'Buscar Grupos',
    
    'dashboard_mleft_ads_title' => 'Anuncios',
    'dashboard_mleft_your_ads' => 'Tus Anuncios',
    'dashboard_mleft_create_ads' => 'Crear Anuncio',
	
    'dashboard_mleft_explore_title' => 'Explorar',
    'dashboard_mleft_saved_post' => 'Guardado',
    'dashboard_mleft_friends' => 'Lista de Amigos',
    'dashboard_mleft_directory' => 'Directorio',

    'dashboard_mleft_albums' => 'Albums',

    'dashboard_mleft_games' => 'Juegos',


    'admin_menu_title' => 'Admin',

    'admin_menu_general' => 'Configuración General',
    
    'admin_menu_membership' => 'Tu Membresía',
    
    'admin_menu_yourbrand' => 'Tu Marca',

    'admin_menu_user_list' => 'Lista de Usuarios',
    'admin_menu_users_inactive' => 'Usuarios Inactivos',
    'admin_menu_request_delete' => 'Solicitudes de Eliminación',
    'admin_menu_users_admin' => 'Usuarios Administradores',

    'admin_menu_pages_created' => 'Páginas creadas',
    'admin_menu_pages_categories' => 'Categorías de Páginas',
    
    'admin_menu_products_created' => 'Productos creados',
    'admin_menu_products_categories' => 'Categorías de Productos',
    
    'admin_menu_articles_created' => 'Artículos creados',
    'admin_menu_articles_categories' => 'Categorías de Artículos',

    'admin_menu_groups_created' => 'Grupos creados',

    'admin_menu_posts_reported' => 'Posts denunciados',
    'admin_menu_comments_reported' => 'Comentarios denunciados',

    'admin_menu_users_ads' => 'Anuncios de Usuarios',
    'admin_menu_plans_ads' => 'Planes para anuncios',
    'admin_menu_basic_ads' => 'Anuncio básico',
    'admin_menu_config_ads' => 'Configuración de anuncios',

    'admin_menu_ads_dashboard' => 'Anuncios en Dashboard',
    'admin_menu_ads_profile' => 'Anuncios en Perfil',
    
    'admin_menu_games' => 'Juegos',

    'admin_menu_themes' => 'Temas',
    
    'admin_menu_currencies' => 'Monedas',

    'admin_menu_languages' => 'Idiomas',
    
    'admin_menu_timezone' => 'Timezone',

    'admin_menu_static_pages' => 'Páginas Estáticas',


    'setting_menu_title' => 'Configuración',

    'setting_menu_account' => 'Tu Cuenta',
    'setting_menu_profile' => 'Editar Perfil',
    'setting_menu_privacy' => 'Tu Privacidad',
    'setting_menu_blocked' => 'Usuarios Bloqueados',
    'setting_menu_delete' => 'Eliminar Cuenta',
    
    'superadmin_menu_title' => 'Super Admin',

    'superadmin_menu_general' => 'Configuración General',
    
    'superadmin_menu_plans' => 'Planes',

    'superadmin_menu_companies' => 'Empresas',
    
    'superadmin_menu_gateways' => 'Pasarelas de Pago',
    
    'superadmin_menu_globalbrand' => 'Marca Global',
    
    'superadmin_menu_user_list' => 'Lista de Usuarios',
    'superadmin_menu_users_inactive' => 'Usuarios Inactivos',
    'superadmin_menu_request_delete' => 'Solicitudes de Eliminación',
    'superadmin_menu_users_admin' => 'Usuarios Administradores',

    'superadmin_menu_pages_created' => 'Páginas creadas',
    'superadmin_menu_pages_categories' => 'Categorías de Páginas',
    
    'superadmin_menu_products_created' => 'Productos creados',
    'superadmin_menu_products_categories' => 'Categorías de Productos',
    
    'superadmin_menu_articles_created' => 'Artículos creados',
    'superadmin_menu_articles_categories' => 'Categorías de Artículos',

    'superadmin_menu_groups_created' => 'Grupos creados',

    'superadmin_menu_posts_reported' => 'Posts denunciados',
    'superadmin_menu_comments_reported' => 'Comentarios denunciados',

    'superadmin_menu_users_ads' => 'Anuncios de Usuarios',
    'superadmin_menu_plans_ads' => 'Planes para anuncios',
    'superadmin_menu_basic_ads' => 'Anuncio básico',
    'superadmin_menu_config_ads' => 'Configuración de anuncios',

    'superadmin_menu_ads_dashboard' => 'Anuncios en Dashboard',
    'superadmin_menu_ads_profile' => 'Anuncios en Perfil',
    
    'superadmin_menu_games' => 'Juegos',

    'superadmin_menu_themes' => 'Temas',
    
    'superadmin_menu_currencies_system' => 'Monedas - Sistema',
    'superadmin_menu_currencies_companies' => 'Monedas - Empresas',

    'superadmin_menu_languages' => 'Idiomas',
    
    'superadmin_menu_timezone' => 'Timezone',

    'superadmin_menu_static_pages' => 'Sistema - Páginas Estáticas',
    'superadmin_menu_static_pages_companies' => 'Empresas - Static Pages',
    
    /*******************************/
    /********* INIT v1.2.0 *********/
    
    'admin_menu_customdomain' => 'Dominio Personalizado',

    'superadmin_menu_customdomains' => 'Dominios Personalizados',

    /*******************************/
    /********** END v1.2.0 *********/


    /*******************************/
    /********* INIT v1.2.5 *********/
    
    'admin_menu_main_modules' => 'Módulos Principales',

    'admin_menu_registration_settings' => 'Configuración de Registro',

    'admin_menu_users_pending' => 'Usuarios pendientes de aprobación',

    /*******************************/
    /********** END v1.2.5 *********/


    /*******************************/
    /********* INIT v1.3.0 *********/

    'superadmin_menu_system_options' => 'Opciones del Sistema',
    'superadmin_menu_company_options' => 'Opciones de las Empresas',

    'superadmin_menu_myads_dashboard' => 'Mis Anuncios (Dashboard)',
    'superadmin_menu_myads_profile' => 'Mis Anuncios (Profile)',

    'superadmin_menu_ads_settings' => 'Configuración de Publicidad',


    /*******************************/
    /********** END v1.3.0 *********/


);	
?>