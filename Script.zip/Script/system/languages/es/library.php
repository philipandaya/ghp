<?php 
$lang = array(
    'library_title_page' => 'Librería | #COMPANY#',
    'library_description' => 'Artículos escritos por los usuarios de #COMPANY#',
    'library_title' => 'Librería',
    'library_empty' => 'No se han encontrado artículos para mostrar.',
    'library_txt_by' => 'Por',
    
    'library_txt_categories' => 'Categorías',
    'library_txt_subcategories' => 'Subcategorías',
    'library_txt_all' => 'Todo',
    'library_txt_filter' => 'Filtrar',
    'library_btn_filter' => 'Filtrar', 

);
?>