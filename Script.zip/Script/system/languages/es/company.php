<?php
$lang = array (
    'company_joined_when' => 'Se unió a <strong>#SITE_TITLE#</strong> el',
    
    'company_login_title' => 'Ingresar',
    'company_login_username_or_email' => 'Nombre de usuario o email',
    'company_login_password' => 'Contraseña',
    'company_login_bsubmit' => 'Iniciar sesión',
    'company_login_forgot_password' => '¿Olvidaste tu contraseña?',
    
    'company_login_reset_title' => 'Reiniciar tu contraseña',
    'company_login_reset_username' => 'Nombre de usuario o Email',
    'company_login_reset_bsubmit' => 'Reiniciar contraseña',
    'company_login_link_login' => 'Ingresar',
    
    'company_login_error_username_empty' => 'Debes ingresar un nombre de usuario.',
    'company_login_error_password_empty' => 'Debes ingresar una contraseña.',
    'company_login_error_username' => 'El nombre de usuario es incorrecto.',
    'company_login_error_password' => 'La contraseña es incorrecta.',
    'company_login_error_incorrect' => 'El usuario o la contraseña son incorrectos.',

    'company_txt_settings' => 'Configuración',

    /*******************************/
    /********* INIT v1.2.0 *********/

    'company_login_reset_username' => 'Tu Email',
    
    'company_login_reset_error_email' => 'Debes ingresar un email válido.',
    'company_login_reset_error_nonregistered' => 'Tu email no está registrado.',
    'company_login_reset_ok' => "Te hemos enviado un email, revísalo.",


    /********** END v1.2.0 *********/
    /*******************************/


    /*******************************/
    /********* INIT v1.2.5 *********/

    'company_login_link_register' => 'Crear una Cuenta',

    'company_register_title' => 'Crea una cuenta',
    'company_register_bsignup' => 'Registrarse',


    /********** END v1.2.5 *********/
    /*******************************/

);
?>