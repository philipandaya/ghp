<?php
$lang = array (

    'off_title' => 'Actualmente estamos en mantenimiento',
    'off_message' => 'Sentimos la demora, nuestro sitio ya está casi listo...',

    'off_login_username' => 'Usuario',
    'off_login_password' => 'Contraseña',

    'off_login_blogin' => 'Ingresar',


);
?>