<?php	
$lang = array (
    'signup_title_page' => 'Sign Up for #SITE_TITLE#',


    'signup_free_title' => 'Cuenta de Prueba GRATIS',
    'signup_free_subtitle_1' => 'Descrubre',
    'signup_free_subtitle_2' => 'ahora mismo.',
    
    'signup_free_box_title' => 'Cuenta de Prueba GRATIS',
    'signup_free_box_subtitle' => '100% Gratis',

    'signup_free_box_free' => 'GRATIS',
    'signup_free_box_daysfree' => 'días gratis',
    'signup_free_box_users' => 'usuarios',
    'signup_free_box_alltools' => 'Todas las herramientas',
    
    'signup_free_form_yourcompany' => 'Tu Empresa',
    'signup_free_form_companyname' => 'Nombre de tu Empresa',
    'signup_free_form_phone' => 'Teléfono',
    'signup_free_form_usernamecny' => "Username en #SITE_TITLE#",

    'signup_free_form_yourpersonalinfo' => 'Tu información personal',
    'signup_free_form_yourpersonalinfo_firstname' => 'Nombres',
    'signup_free_form_yourpersonalinfo_lastname' => 'Apellidos',
    'signup_free_form_yourpersonalinfo_email' => 'Email',
    
    'signup_free_form_accesssystem' => 'Acceso al sistema',
    'signup_free_form_accesssystem_username' => 'Usuario',
    'signup_free_form_accesssystem_password' => 'Contraseña',

    'signup_free_form_clic_accept_1' => 'Al hacer clic en el siguiente botón acepta nuestros',
    'signup_free_form_clic_accept_2' => 'Términos de Uso',
    
    'signup_free_form_bcreate' => 'Crear Cuenta',

    'signup_free_form_error_name_company' => 'Debes ingresar el nombre de tu empresa',
    'signup_free_form_error_phone' => 'Debes ingresar el teléfono de tu empresa',
    'signup_free_form_error_username_company' => 'Debes elegir un Username válido para tu empresa',
    'signup_free_form_error_firstname' => 'Debes ingresar tus nombres',
    'signup_free_form_error_lastname' => 'Debes ingresar tus apellidos',
    'signup_free_form_error_email' => 'Debes ingresar tu email válido',
    'signup_free_form_error_username' => 'Debes ingresar un Username válido',
    'signup_free_form_error_password' => 'Debes ingresar una contraseña',
    
    'signup_free_form_error_user_company_not_available' => 'El Username para tu empresa no está disponible',
    'signup_free_form_error_email_other_person' => 'El email ingresado es usado por otra persona',
    'signup_free_form_error_user_not_available' => 'El Username que has elegido no está disponible',
    
    'signup_free_default_statics_page_privacypolicy_title' => "Política de Privacidad",
    'signup_free_default_statics_page_privacypolicy_texthtml' => "Texto de la Política de Privacidad aquí...",
    'signup_free_default_statics_page_termsuse_title' => "Términos de uso",
    'signup_free_default_statics_page_termsuse_texthtml' => "Texto de los Términos de Uso aquí...",
    'signup_free_default_statics_page_aboutus_title' => "Acerca de Nosotros",
    'signup_free_default_statics_page_aboutus_texthtml' => "Texto Acerca de Nosotros aquí...",

    'signup_free_default_category_page_name' => "Categoría Demo para Páginas",
    'signup_free_default_subcategory_page_name' => "Sub Categoría Demo para Páginas",

    'signup_free_default_category_product_name' => "Categoría Demo para Productos",
    'signup_free_default_subcategory_product_name' => "Sub Categoría Demo para Productos",

    'signup_free_default_category_articles_name' => "Categoría Demo para Artículos",
    'signup_free_default_subcategory_articles_name' => "Sub Categoría Demo para Artículos",


);	
?>