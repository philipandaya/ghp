<?php 
$lang = array(
    'marketplace_title_page' => 'Marketplace | #COMPANY#',
    'marketplace_description' => 'Tienda de productos de #COMPANY#',
    'marketplace_title' => 'Marketplace',
    'marketplace_empty' => 'No se han encontrado productos para mostrar.',

    'marketplace_txt_categories' => 'Categorías',
    'marketplace_txt_subcategories' => 'Subcategorías',
    'marketplace_txt_all' => 'Todo',
    'marketplace_txt_filter' => 'Filtrar',
    'marketplace_btn_filter' => 'Filtrar',

);
?>