<?php	
$lang = array(
    'home_title_page' => '#SITE_TITLE# - Plataforma SaaS para crear redes sociales',

    'home_front_menu_msgtop' => '#SITE_TITLE# | Plataforma SaaS para crear redes sociales.',
    'home_front_menu_login' => 'Ingresar',    

    'home_front_menu_home' => 'INICIO',
    'home_front_menu_contactus' => 'CONTACTENOS',
    'home_front_menu_freetrial' => 'Prueba Gratis',
    'home_front_menu_seeplans' => 'Ver Planes',
    
    'home_front_hero_part01' => 'Te presentamos a',
    'home_front_hero_part02' => 'tu plataforma SaaS para crear',
    'home_front_hero_part03' => 'tu propia red social.',

    'home_front_hero_bmeetplans' => 'Conoce nuestros planes',
    'home_front_hero_linkpart01' => 'O empieza una',
    'home_front_hero_linkpart02' => 'Prueba Gratis',

    'home_front_hero_msgtools01' => 'Crea tu propia',
    'home_front_hero_msgtools02' => 'Red Social',
    'home_front_hero_msgtools03' => 'con todas las herramientas disponibles',
    
    'home_front_hero_tool_timeline' => 'Linea de Tiempo',
    'home_front_hero_tool_chat' => 'Chat',
    'home_front_hero_tool_groups' => 'Grupos',
    'home_front_hero_tool_events' => 'Eventos',
    'home_front_hero_tool_likes' => 'Likes',
    'home_front_hero_tool_comments' => 'Comentarios',
    'home_front_hero_tool_profiles' => 'Perfiles',
    'home_front_hero_tool_shares' => 'Compartir',
    'home_front_hero_tool_marketplace' => 'Marketplace',
    'home_front_hero_tool_pages' => 'Páginas',
    'home_front_hero_tool_library' => 'Librería',
    'home_front_hero_tool_more' => 'Y más, mucho más',

    'home_front_hero_msg_plans01' => 'Tenemos los mejores planes y los mejores precios que se adecuarán a tus requerimientos',
    'home_front_hero_msg_plans02' => 'Todas los planes son de acceso inmediato luego de la creación de tu cuenta. ',

    'home_front_hero_txt_month' => 'Mes',

    'home_front_hero_txt_more_popular' => 'Más popular',
    'home_front_hero_txt_buy_plan' => 'Comprar Plan',
    'home_front_hero_txt_free_trial' => 'Prueba Gratis',
    
    'home_front_hero_plan_ftr_users' => 'usuarios',
    'home_front_hero_plan_ftr_all_tools' => 'Todas las herramientas',
    'home_front_hero_plan_ftr_support' => 'Soporte 24/7',
    'home_front_hero_plan_ftr_access' => 'Acceso inmediato',

    'home_front_hero_msg_action01' => 'Regístrate ahora con una prueba gratis',
    'home_front_hero_msg_action02' => 'y empieza a usar',
    
    'home_front_hero_msg_bactionstart' => 'Iniciar mi prueba gratis',
    
    'home_front_hero_msg_refer01' => 'Sin ningún pago, ni uso de tarjeta.',
    'home_front_hero_msg_refer02' => 'Y puedes dar de baja en cualquier momento.',

    'home_front_hero_msg_explanation01' => 'Con',
    'home_front_hero_msg_explanation02' => 'puedes crear tu',
    'home_front_hero_msg_explanation03' => 'propia red social',
    'home_front_hero_msg_explanation04' => 'para tu',
    'home_front_hero_msg_explanation_txt_0' => 'empresa',
    'home_front_hero_msg_explanation_txt_1' => 'empresa, universidad, colegio, club deportivo, iglesia',

    /*******************************/
    /********* INIT v1.2.0 *********/
    
    'home_front_hero_plan_ftr_with_cdomain' => 'Con dominio Personalizado',
    'home_front_hero_plan_ftr_no_cdomain' => 'Sin Dominio Personalizado',

    'home_front_hero_plan_ftr_with_audios' => 'Posts con Audios',
    'home_front_hero_plan_ftr_without_audios' => 'Posts sin Audios',

    'home_front_hero_plan_ftr_with_videos' => 'Posts con Videos',
    'home_front_hero_plan_ftr_without_videos' => 'Posts sin Videos',
    
    /********** END v1.2.0 *********/
    /*******************************/
);
?>