<?php
$current_language = (object) array (
    'name'  => 'English',
    'author_name' => 'MCode Developer',
    'author_url' => 'https://www.mcodedeveloper.com',
);
?>