<?php
$lang = array (

    'off_title' => 'We are currently under maintenance',
    'off_message' => 'We are truly sorry for our delay, but our website is coming...',

    'off_login_username' => 'Username',
    'off_login_password' => 'Password',

    'off_login_blogin' => 'Log In',

);
?>