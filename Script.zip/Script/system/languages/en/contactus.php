<?php	
$lang = array (
    
    'contactus_title' => 'Write us a comment',
    'contactus_subtitle' => 'We will answer all your questions about our service.',

    'contactus_form_names' => 'Names',
    'contactus_form_company' => 'Company',
    'contactus_form_email' => 'Email',
    'contactus_form_phone' => 'Phone',
    'contactus_form_comment' => 'Your comment',
    'contactus_form_bsend' => 'Send form',
    
    'contactus_form_error_names' => 'You must enter your names',
    'contactus_form_error_company' => 'You must enter the name of your company',
    'contactus_form_error_email' => 'You must enter a valid email',
    'contactus_form_error_phone' => 'You must enter a phone number',
    'contactus_form_error_comment' => 'You must enter a comment',
    
    'contactus_form_msgok_01' => 'We have received your message.',
    'contactus_form_msgok_02' => 'We will respond as soon as possible.',
    'contactus_form_msgok_03' => 'Thanks for writing to us.',

);	
?>