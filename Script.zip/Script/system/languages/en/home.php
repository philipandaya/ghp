<?php
$lang = array(
    'home_title_page' => '#SITE_TITLE# - SaaS platform to create social networks',

    'home_front_menu_msgtop' => '#SITE_TITLE# | SaaS platform to create social networks.',    
    'home_front_menu_login' => 'Login',
        
    'home_front_menu_home' => 'HOME',
    'home_front_menu_contactus' => 'CONTACT US',
    'home_front_menu_freetrial' => 'Free Trial',
    'home_front_menu_seeplans' => 'See plans',
    
    'home_front_hero_part01' => 'We introduce you to',
    'home_front_hero_part02' => 'your SaaS platform to create',
    'home_front_hero_part03' => 'your own Social Network.',

    'home_front_hero_bmeetplans' => 'Meet our plans',
    'home_front_hero_linkpart01' => 'Or start a',
    'home_front_hero_linkpart02' => 'Free Trial',
    
    'home_front_hero_msgtools01' => 'Create your own',
    'home_front_hero_msgtools02' => 'Social Network',
    'home_front_hero_msgtools03' => 'with all available tools',

    'home_front_hero_tool_timeline' => 'Timeline',
    'home_front_hero_tool_chat' => 'Chat',
    'home_front_hero_tool_groups' => 'Groups',
    'home_front_hero_tool_events' => 'Events',
    'home_front_hero_tool_likes' => 'Likes',
    'home_front_hero_tool_comments' => 'Comments',
    'home_front_hero_tool_profiles' => 'Profiles',
    'home_front_hero_tool_shares' => 'Shares',
    'home_front_hero_tool_marketplace' => 'Marketplace',
    'home_front_hero_tool_pages' => 'Pages',
    'home_front_hero_tool_library' => 'Library',
    'home_front_hero_tool_more' => 'And more, much more',
    
    'home_front_hero_msg_plans01' => 'We have the best plans and the best prices that will suit your requirements',
    'home_front_hero_msg_plans02' => 'All plans are immediately accessible after the creation of your account.',

    'home_front_hero_txt_month' => 'Month',

    'home_front_hero_txt_more_popular' => 'More popular',
    'home_front_hero_txt_buy_plan' => 'Buy Plan',
    'home_front_hero_txt_free_trial' => 'Free Trial',

    'home_front_hero_plan_ftr_users' => 'users',
    'home_front_hero_plan_ftr_all_tools' => 'All tools',
    'home_front_hero_plan_ftr_support' => '24/7 support',
    'home_front_hero_plan_ftr_access' => 'Immediate access',

    'home_front_hero_msg_action01' => 'Sign up now with a free trial',
    'home_front_hero_msg_action02' => 'and start using',
    
    'home_front_hero_msg_bactionstart' => 'Start my free trial',
    
    'home_front_hero_msg_refer01' => 'Without any payment, or use of card.',
    'home_front_hero_msg_refer02' => 'And you can unsubscribe at any time.',
    
    'home_front_hero_msg_explanation01' => 'With',
    'home_front_hero_msg_explanation02' => 'you can create your',
    'home_front_hero_msg_explanation03' => 'own social network',
    'home_front_hero_msg_explanation04' => 'for your',
    'home_front_hero_msg_explanation_txt_0' => 'business',
    'home_front_hero_msg_explanation_txt_1' => 'business, university, school, sports club, church',

    /*******************************/
    /********* INIT v1.2.0 *********/
    
    'home_front_hero_plan_ftr_with_cdomain' => 'With Custom Domain',
    'home_front_hero_plan_ftr_no_cdomain' => 'No Custom Domain',
    
    'home_front_hero_plan_ftr_with_audios' => 'Posts with Audios',
    'home_front_hero_plan_ftr_without_audios' => 'Posts without Audios',

    'home_front_hero_plan_ftr_with_videos' => 'Posts with Videos',
    'home_front_hero_plan_ftr_without_videos' => 'Posts without Videos',

    /********** END v1.2.0 *********/
    /*******************************/
);
?>