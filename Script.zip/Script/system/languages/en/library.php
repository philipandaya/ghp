<?php 
$lang = array(
    'library_title_page' => 'Library | #COMPANY#',
    'library_description' => 'Articles written by #COMPANY# users',
    'library_title' => 'Library',
    'library_empty' => 'No articles found to show.',
    'library_txt_by' => 'By',
    
    'library_txt_categories' => 'Categories',
    'library_txt_subcategories' => 'Subcategories',
    'library_txt_all' => 'All',
    'library_txt_filter' => 'Filter',
    'library_btn_filter' => 'Filter',   

);
?>