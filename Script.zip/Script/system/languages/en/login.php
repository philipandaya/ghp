<?php
$lang = array (
    'login_title_page' => 'Log into #SITE_TITLE#',
    'login_title' => 'Login',
    'login_email' => 'Email',
    'login_email_placeholder' => 'Enter your email',
    'login_bsubmit' => 'Next',

    'login_error_email' => 'You must enter a valid email.',

    /*******************************/
    /********* INIT v1.2.0 *********/

    'resetpass_title_page' => 'Reset Password',
    'resetpass_title' => 'Reset Password',
    'resetpass_newpass' => 'New password',
    'resetpass_re_newpass' => 'Re-enter new password',
    'resetpass_bupdate' => 'Update password',
    'resetpass_msg1' => 'Failed to reset the password!',
    'resetpass_msg_error1' => 'You must enter a new password',
    'resetpass_msg_error2' => 'Passwords must be between 6 to 20 characters',
    'resetpass_msg_error3' => 'Passwords do not match',
    'resetpass_msg4' => 'Login now',
    'resetpass_msg_ok' => 'Successful reset password!',



    /********** END v1.2.0 *********/
    /*******************************/


);
?>