<?php 
$lang = array(
    'marketplace_title_page' => 'Marketplace | #COMPANY#',
    'marketplace_description' => '#COMPANY# product store',
    'marketplace_title' => 'Marketplace',
    'marketplace_empty' => 'No products found to show.',

    'marketplace_txt_categories' => 'Categories',
    'marketplace_txt_subcategories' => 'Subcategories',
    'marketplace_txt_all' => 'All',
    'marketplace_txt_filter' => 'Filter',
    'marketplace_btn_filter' => 'Filter',    

);
?>