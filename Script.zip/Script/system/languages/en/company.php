<?php
$lang = array (
    'company_joined_when' => 'Joined <strong>#SITE_TITLE#</strong> on',

    'company_login_title' => 'Login',
    'company_login_username_or_email' => 'Username or email',
    'company_login_password' => 'Password',
    'company_login_bsubmit' => 'Log In',
    'company_login_forgot_password' => 'Forgot your password?',
    
    'company_login_reset_title' => 'Reset your password',
    'company_login_reset_username' => 'Username or Email',
    'company_login_reset_bsubmit' => 'Reset password',
    'company_login_link_login' => 'Login',
    
    'company_login_error_username_empty' => 'You must enter a username.',
    'company_login_error_password_empty' => 'You must enter a password.',    
    'company_login_error_username' => 'The username is incorrect.',
    'company_login_error_password' => 'The password is incorrect.',
    'company_login_error_incorrect' => 'The username or password are incorrect.',

    'company_txt_settings' => 'Settings',
    
    /*******************************/
    /********* INIT v1.2.0 *********/

    'company_login_reset_username' => 'Your Email',
    
    'company_login_reset_error_email' => 'You must enter a valid email address.',
    'company_login_reset_error_nonregistered' => 'Your email is not registered.',
    'company_login_reset_ok' => "We've sent an email, check it.",


    /********** END v1.2.0 *********/
    /*******************************/


    /*******************************/
    /********* INIT v1.2.5 *********/

    'company_login_link_register' => 'Create an account',

    'company_register_title' => 'Create a New Account',
    'company_register_bsignup' => 'Sign Up',


    /********** END v1.2.5 *********/
    /*******************************/

    
);
?>