<?php	
$lang = array (
    'signup_free_title_page' => 'Sign Up for #SITE_TITLE#',
    
    
    'signup_free_title' => 'FREE Trial Account',
    'signup_free_subtitle_1' => 'Discover',
    'signup_free_subtitle_2' => 'right now.',

    'signup_free_box_title' => 'FREE Trial Account',
    'signup_free_box_subtitle' => '100% Free',
    
    'signup_free_box_free' => 'FREE',
    'signup_free_box_daysfree' => 'days free',
    'signup_free_box_users' => 'users',
    'signup_free_box_alltools' => 'All tools',
    
    'signup_free_form_yourcompany' => 'Your Company',
    'signup_free_form_companyname' => 'Company Name',
    'signup_free_form_phone' => 'Phone',
    'signup_free_form_usernamecny' => "Username in #SITE_TITLE#",

    'signup_free_form_yourpersonalinfo' => 'Your personal information',
    'signup_free_form_yourpersonalinfo_firstname' => 'Firstname',
    'signup_free_form_yourpersonalinfo_lastname' => 'Lastname',
    'signup_free_form_yourpersonalinfo_email' => 'Email',
    
    'signup_free_form_accesssystem' => 'Access to the system',
    'signup_free_form_accesssystem_username' => 'Username',
    'signup_free_form_accesssystem_password' => 'Password',
    
    'signup_free_form_clic_accept_1' => 'By clicking on the following button you accept our',
    'signup_free_form_clic_accept_2' => 'Terms of Use',
    
    'signup_free_form_bcreate' => 'Create Account',
    
    'signup_free_form_error_name_company' => 'You must enter the name of your company',
    'signup_free_form_error_phone' => "You must enter your company's phone number",
    'signup_free_form_error_username_company' => 'You must choose a valid Username for your company',
    'signup_free_form_error_firstname' => 'You must enter your firstname',
    'signup_free_form_error_lastname' => 'You must enter your lastname',
    'signup_free_form_error_email' => 'You must enter your valid email',
    'signup_free_form_error_username' => 'You must enter a valid Username',
    'signup_free_form_error_password' => 'You must enter a password',

    'signup_free_form_error_user_company_not_available' => 'The Username for your company is not available',
    'signup_free_form_error_email_other_person' => 'The email entered is used by another person',
    'signup_free_form_error_user_not_available' => 'The Username you have chosen is not available',

    'signup_free_default_statics_page_privacypolicy_title' => "Privacy Policy",
    'signup_free_default_statics_page_privacypolicy_texthtml' => "Text Privacy Policy here...",
    'signup_free_default_statics_page_termsuse_title' => "Terms of Use",
    'signup_free_default_statics_page_termsuse_texthtml' => "Text Terms of Use here...",
    'signup_free_default_statics_page_aboutus_title' => "About Us",
    'signup_free_default_statics_page_aboutus_texthtml' => "Text about here...",
    
    'signup_free_default_category_page_name' => "Category Demo for Pages",
    'signup_free_default_subcategory_page_name' => "Sub Category Demo for Pages",

    'signup_free_default_category_product_name' => "Category Demo for Products",
    'signup_free_default_subcategory_product_name' => "Sub Category Demo for Products",

    'signup_free_default_category_articles_name' => "Category Demo for Articles",
    'signup_free_default_subcategory_articles_name' => "Sub Category Demo for Articles",


);	
?>