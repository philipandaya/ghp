<?php	
$lang = array(
    'dashboard_mleft_news_feed' => 'News Feed',
    'dashboard_mleft_messages' => 'Messages',
    'dashboard_mleft_photos' => 'Photos',
    'dashboard_mleft_events' => 'Events',
    'dashboard_mleft_myproducts' => 'My Products',
    'dashboard_mleft_marketplace' => 'Marketplace',
    'dashboard_mleft_myarticles' => 'My Articles',
    'dashboard_mleft_library' => 'Library',
    'dashboard_mleft_myevents' => 'My Events',
    
    'dashboard_mleft_pages_title' => 'Pages',
    'dashboard_mleft_pages_feed' => 'Pages Feed',
    'dashboard_mleft_your_pages' => 'Your Pages',
    'dashboard_mleft_create_page' => 'Create Page',
    'dashboard_mleft_search_pages' => 'Search Pages',
    
    'dashboard_mleft_groups_title' => 'Groups',
    'dashboard_mleft_groups_feed' => 'Groups Feed',
    'dashboard_mleft_your_groups' => 'Your Groups',
    'dashboard_mleft_create_group' => 'Create Group',
    'dashboard_mleft_search_groups' => 'Search Groups',
    
    'dashboard_mleft_ads_title' => 'Ads',
    'dashboard_mleft_your_ads' => 'Your Ads',
    'dashboard_mleft_create_ads' => 'Create Ads',
	
    'dashboard_mleft_explore_title' => 'Explore',
    'dashboard_mleft_saved_post' => 'Saved',
    'dashboard_mleft_friends' => 'Friends list',
    'dashboard_mleft_directory' => 'Directory',
    
    'dashboard_mleft_albums' => 'Albums',
    
    'dashboard_mleft_games' => 'Games',
    
    
    'admin_menu_title' => 'Admin',

    'admin_menu_general' => 'General Setting',
    
    'admin_menu_membership' => 'Your Membership',
    
    'admin_menu_yourbrand' => 'Your Brand',

    'admin_menu_user_list' => 'User List',
    'admin_menu_users_inactive' => 'Users Inactive',
    'admin_menu_request_delete' => 'Request Delete',
    'admin_menu_users_admin' => 'Users Admin',

    'admin_menu_pages_created' => 'Pages Created',
    'admin_menu_pages_categories' => 'Pages Categories',

    'admin_menu_products_created' => 'Products Created',
    'admin_menu_products_categories' => 'Products Categories',

    'admin_menu_articles_created' => 'Articles Created',
    'admin_menu_articles_categories' => 'Articles Categories',

    'admin_menu_groups_created' => 'Groups Created',

    'admin_menu_posts_reported' => 'Posts Reported',
    'admin_menu_comments_reported' => 'Comments Reported',

    'admin_menu_users_ads' => 'Users Ads',
    'admin_menu_plans_ads' => 'Plans Ads',
    'admin_menu_basic_ads' => 'Basic Ads',
    'admin_menu_config_ads' => 'Config Ads',
    
    'admin_menu_ads_dashboard' => 'Ads in Dashboard',
    'admin_menu_ads_profile' => 'Ads in Profile',

    'admin_menu_games' => 'Games',

    'admin_menu_themes' => 'Themes',
    
    'admin_menu_currencies' => 'Currencies',

    'admin_menu_languages' => 'Languages',
    
    'admin_menu_timezone' => 'Timezone',

    'admin_menu_static_pages' => 'Static Pages',
    
    
    'setting_menu_title' => 'Settings',

    'setting_menu_account' => 'Account Settings',
    'setting_menu_profile' => 'Edit Profile',
    'setting_menu_privacy' => 'Your Privacy',
    'setting_menu_blocked' => 'Blocked Users',
    'setting_menu_delete' => 'Delete Account',

    'superadmin_menu_title' => 'Super Admin',

    'superadmin_menu_general' => 'General Setting',
    
    'superadmin_menu_plans' => 'Plans',
    
    'superadmin_menu_companies' => 'Companies',
    
    'superadmin_menu_gateways' => 'Payment Gateways',
    
    'superadmin_menu_globalbrand' => 'Global Brand',

    'superadmin_menu_user_list' => 'User List',
    'superadmin_menu_users_inactive' => 'Users Inactive',
    'superadmin_menu_request_delete' => 'Request Delete',
    'superadmin_menu_users_admin' => 'Users Admin',

    'superadmin_menu_pages_created' => 'Pages Created',
    'superadmin_menu_pages_categories' => 'Pages Categories',

    'superadmin_menu_products_created' => 'Products Created',
    'superadmin_menu_products_categories' => 'Products Categories',

    'superadmin_menu_articles_created' => 'Articles Created',
    'superadmin_menu_articles_categories' => 'Articles Categories',

    'superadmin_menu_groups_created' => 'Groups Created',

    'superadmin_menu_posts_reported' => 'Posts Reported',
    'superadmin_menu_comments_reported' => 'Comments Reported',

    'superadmin_menu_users_ads' => 'Users Ads',
    'superadmin_menu_plans_ads' => 'Plans Ads',
    'superadmin_menu_basic_ads' => 'Basic Ads',
    'superadmin_menu_config_ads' => 'Config Ads',
    
    'superadmin_menu_ads_dashboard' => 'Ads in Dashboard',
    'superadmin_menu_ads_profile' => 'Ads in Profile',

    'superadmin_menu_games' => 'Games',

    'superadmin_menu_themes' => 'Themes',
    
    'superadmin_menu_currencies_system' => 'Currencies - System',
    'superadmin_menu_currencies_companies' => 'Currencies - Companies',

    'superadmin_menu_languages' => 'Languages',
    
    'superadmin_menu_timezone' => 'Timezone',

    'superadmin_menu_static_pages' => 'System - Static Pages',
    'superadmin_menu_static_pages_companies' => 'Companies - Static Pages',
    
    /*******************************/
    /********* INIT v1.2.0 *********/
    
    'admin_menu_customdomain' => 'Custom Domain',

    'superadmin_menu_customdomains' => 'Custom Domains',

    /*******************************/
    /********** END v1.2.0 *********/


    /*******************************/
    /********* INIT v1.2.5 *********/
    
    'admin_menu_main_modules' => 'Main Modules',

    'admin_menu_registration_settings' => 'Registration Settings',

    'admin_menu_users_pending' => 'Users pending approval',

    /*******************************/
    /********** END v1.2.5 *********/


    /*******************************/
    /********* INIT v1.3.0 *********/

    'superadmin_menu_system_options' => 'System Options',
    'superadmin_menu_company_options' => 'Company Options',

    'superadmin_menu_myads_dashboard' => 'My Ads (Dashboard)',
    'superadmin_menu_myads_profile' => 'My Ads (Profile)',

    'superadmin_menu_ads_settings' => 'Ads Setting',


    /*******************************/
    /********** END v1.3.0 *********/

);
?>