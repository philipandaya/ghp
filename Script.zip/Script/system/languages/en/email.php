<?php 
    $lang = array(
    
        'email_validation_subject' => 'Confirm your account in #SITE_TITLE#',
        'email_validation_hello' => 'Hello,',  
        'email_validation_msg01' => 'To confirm your registration in #SITE_TITLE#, please use the following link:',
        'email_validation_msg02' => 'In case you have not requested a registration, please disregard this message.',
        'email_validation_signature' => 'Regards,<br/><br/>#SITE_TITLE#',
        
        'email_recovery_subject' => 'Forgotten Password in #SITE_TITLE#',
        'email_recovery_hello' => 'Hello,',
        'email_recovery_msg1' => 'To restore your password in #SITE_TITLE#, please use the following link:',
        'email_recovery_msg2' => 'In case you have not requested a password recovery, please disregard this message.',
        'email_recovery_signature' => 'Regards,<br/><br/>#SITE_TITLE#',
        
        'email_contactus_subject' => 'A message from #SITE_TITLE#',
        'email_contactus_hello' => 'Hello,',
        'email_contactus_msg1' => 'A message, with the following data, has been received from the website:',
        'email_contactus_txt_names' => 'Names',
        'email_contactus_txt_company' => 'Company',
        'email_contactus_txt_email' => 'Email',
        'email_contactus_txt_phone' => 'Phone',
        'email_contactus_txt_comment' => 'Comment',
        'email_contactus_signature' => 'Regards,<br/><br/>#SITE_TITLE#',

        'email_notifcdomain_subject' => 'Activation of Custom Domain in #SITE_TITLE#',
        'email_notifcdomain_hello' => 'Hello,',
        'email_notifcdomain_msg1' => 'A user has requested activation of their custom domain.',
        'email_notifcdomain_txt_user' => 'User',
        'email_notifcdomain_txt_company' => 'Company',
        'email_notifcdomain_txt_url' => 'URL Custom Domain',
        'email_notifcdomain_signature' => 'Regards,<br/><br/>#SITE_TITLE#',
    
    );
?>