<?php   
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
    
    $this->load_extract_controller('_info-company-dash');

    if (!$D->sett_comp_mod_pages) $this->globalRedirect('dashboard');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

    $D->id_menu = 'opt_ml_searchpages';
    
    $this->load_extract_controller('_load-menus');
    
    $this->load_extract_controller('_pre-dashboard');

    /****************************************************************************/

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {
            $for_load = 'min/pages-search.php';
		} else {
            $for_load = 'max/pages-search.php';
		}

        $D->titlePhantom = $this->lang('dashboard_pages_search_title_p', array('#COMPANY#'=>$D->company_name));

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

        $D->page_title = $this->lang('dashboard_pages_search_title_p', array('#COMPANY#'=>$D->company_name));

        $D->file_in_template = 'max/pages-search.php';
        $this->load_template('dashboard-template.php');

    }

?>