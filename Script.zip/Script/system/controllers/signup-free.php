<?php   
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    if ($D->_IS_LOGGED) $this->globalRedirect('dashboard');

	$this->loadLanguage('global.php');
	$this->loadLanguage('home.php');
	$this->loadLanguage('signup-free.php');

    /***********************************************/
    
    $D->plan_free = $this->db2->fetch_field("SELECT value FROM settings WHERE word='PLAN_FREE' LIMIT 1");
    $json = json_decode($D->plan_free);
    $D->max_users = $json->max_user;
    $D->num_days = $json->days;


    /***********************************************/
    
    $this->load_extract_controller('_required-out');
    
	$D->is_home = TRUE;    

    $D->page_title = $this->lang('home_title_page', array('#SITE_TITLE#'=>$K->SITE_TITLE));

	$this->load_template('front/signup-free.php');
?>