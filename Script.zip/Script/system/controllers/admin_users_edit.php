<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');

	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /****************************************************************/    
    /****************************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->codeuser = '';
	if ($this->param('u')) $D->codeuser = $this->param('u');
    $D->codeuser = $the_sanitaze->str_nohtml($D->codeuser, 11);
    if (empty($D->codeuser)) $this->globalRedirect($K->SITE_URL.'admin/users');

    $info_user = $this->db2->fetch("SELECT iduser FROM users WHERE idcompany=".$D->company_id." AND code='".$D->codeuser."' LIMIT 1");
    if (!$info_user) $this->globalRedirect($K->SITE_URL.'admin/users');
    
    $D->iduser = $info_user->iduser;

    $D->me = $this->user->info;

    $D->the_user = $this->db2->fetch("SELECT * FROM users WHERE idcompany=".$D->company_id." AND iduser=".$D->iduser." LIMIT 1");

    $D->verified = $D->the_user->verified;
    $D->active = $D->the_user->active;
    $D->isadministrador = $D->the_user->is_admin;
    $D->leveladmin = $D->the_user->leveladmin;

    $D->firstname = stripslashes($D->the_user->firstname);
    $D->lastname = stripslashes($D->the_user->lastname);
    $D->the_name_user = stripslashes($D->the_user->firstname).' '.stripslashes($D->the_user->lastname);
    $D->gender = $D->the_user->gender;
    $D->born = explode('-', $D->the_user->birthday);

    $D->currentcity = stripslashes($D->the_user->currentcity);
    $D->hometown = stripslashes($D->the_user->hometown);

    $D->email = stripslashes($D->the_user->user_email);

    $D->username = stripslashes($D->the_user->user_username);

    $D->privacy = $D->the_user->privacy;
    $D->who_write_on_my_wall = $D->the_user->who_write_on_my_wall;
    $D->who_can_see_friends = $D->the_user->who_can_see_friends;
    $D->who_can_see_liked_pages = $D->the_user->who_can_see_liked_pages;
    $D->who_can_see_joined_groups = $D->the_user->who_can_see_joined_groups;
    $D->who_can_sendme_messages = $D->the_user->who_can_sendme_messages;

    $D->who_can_see_birthdate = $D->the_user->who_can_see_birthdate;
    $D->who_can_see_location = $D->the_user->who_can_see_location;
    $D->who_can_see_about_me = $D->the_user->who_can_see_about_me;

    $D->chat = $D->the_user->chat;

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');
    $D->js_script_min .= $this->designer->getStringJS('sha256');

    $D->id_menu = 'opt_adm_users';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-users-edit.php';

		} else {

            $for_load = 'max/admin-users-edit.php';

		}

        $D->titlePhantom = $this->lang('admin_users_title_page').' | '.$D->the_name_user;

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_users_title_page').' | '.$D->the_name_user;    	

        $D->file_in_template = 'max/admin-users-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>