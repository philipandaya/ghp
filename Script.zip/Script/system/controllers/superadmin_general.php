<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');

	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /****************************************************************/    
    /****************************************************************/

    $D->site_status = $K->SITE_LIVE;
    $D->site_privacy = $K->SITE_PRIVACY;
    $D->site_company = stripslashes($K->COMPANY);
    $D->site_title = stripslashes($K->SITE_TITLE);
    $D->site_keywords = stripslashes($K->SEO_KEYWORDS);
    $D->site_description = stripslashes($K->SEO_DESCRIPTION);

    $D->mail_fromname = stripslashes($K->MAIL_FROMNAME);
    $D->mail_from = stripslashes($K->MAIL_FROM);
    
    $D->mail_withphpmailer = $K->MAIL_WITH_PHPMAILER;
    $D->mail_host = stripslashes($K->MAIL_HOST);
    $D->mail_ssl = stripslashes($K->MAIL_SSL);
    $D->mail_port = stripslashes($K->MAIL_PORT);
    $D->mail_username = stripslashes($K->MAIL_USERNAME);
    $D->mail_password = stripslashes($K->MAIL_PASSWORD);
    
    $D->api_key_google = stripslashes($K->KEY_API_GOOGLE);
    
    $D->currency_site = stripslashes($K->CURRENCY);
    
    $D->email_contact = stripslashes($K->EMAIL_CONTACT);

    $D->go_with_gdpr = stripslashes($K->WITH_GDPR);
    
    /****************************************************************/    
    /****************************************************************/

    $the_curr_system = $this->db2->fetch_all("SELECT * FROM currencies ORDER BY name ASC");

    $D->html_select_curr = '';

    foreach ($the_curr_system as $oneitem) {
        $thecurr_name = stripslashes($oneitem->name);
        $thecurr_code_iso = stripslashes($oneitem->code_iso);
        $thecurr_symbol = stripslashes($oneitem->symbol);
        
        $D->html_select_curr .= '<option value="'.$thecurr_code_iso.'"'.($thecurr_code_iso == $D->currency_site ? 'selected="selected"' : '').'>'.$thecurr_name.' ('.$thecurr_symbol.')</option>';
    }

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_general';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-general.php';

		} else {

            $for_load = 'max/superadmin-general.php';

		}

        $D->titlePhantom = $this->lang('superadmin_general_title_page');

        $html .= $this->load_template($for_load, FALSE);

        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_general_title_page');    	

        $D->file_in_template = 'max/superadmin-general.php';
        $this->load_template('dashboard-template.php');

	}

?>