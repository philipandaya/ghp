<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
$f = '';
if ($this->param('f') && !empty($this->param('f'))) $f = $this->param('f');

$o = '';
if ($this->param('o') && !empty($this->param('o'))) $o = $this->param('o');

if (empty($f) || empty($o)) die();

header("Content-Disposition:attachment; filename=$o");
readfile($K->STORAGE_URL_ATTACH_MESSAGES.$f);