<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    if ($this->params->info_who == 2) {
        $this->load_extract_controller('_info-company');
    } else $this->load_extract_controller('_info-company-dash');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');

    if ($D->_IS_LOGGED) {
        $this->loadLanguage('dashboard.php');
    	$D->me = $this->user->info;
    }

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->urlpage = '';
	if ($this->param('info')) $D->urlpage = $this->param('info');
    $D->urlpage = $the_sanitaze->str_nohtml($D->urlpage);
    if (empty($D->urlpage)) $this->globalRedirect($K->SITE_URL);
    
    if ($this->params->info_who == 1) {
        $the_static = $this->db2->fetch("SELECT * FROM statics WHERE url='".$D->urlpage."' LIMIT 1");
    } else {
        $the_static = $this->db2->fetch("SELECT * FROM statics_companies WHERE idcompany=".$D->company_id_out." AND url='".$D->urlpage."' LIMIT 1");
    }
    
    if (!$the_static) $this->globalRedirect($K->SITE_URL);
    $D->static_title = stripslashes($the_static->title);
    $D->static_texthtml = stripslashes($the_static->texthtml);

    $D->id_container = 'site';

	if ($D->isPhantom) {

        $html = '';

        if ($D->_IS_LOGGED) {

            $D->id_container = 'dashboard';
            $this->load_extract_controller('_load-menus');

        }

        if ($D->layout_size == 'min') {
            $for_load = 'min/info.php';
        } else {
            $for_load = 'max/info.php';
        }

        if ($this->params->info_who == 1) {
            $D->titlePhantom = $D->static_title.' | '.$K->SITE_TITLE;
        } else {
            $D->titlePhantom = $D->static_title.' | '.$D->company_name_out;
        }

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        if ($this->params->info_who == 1) {
            $D->page_title = $D->static_title.' | '.$K->SITE_TITLE;
        } else {
            $D->page_title = $D->static_title.' | '.$D->company_name_out;
        }

        if ($D->_IS_LOGGED) {
            
            $D->id_container = 'dashboard';
            $this->load_extract_controller('_load-menus');

            $this->load_extract_controller('_required-dashboard');
            $this->load_extract_controller('_dashboard-bar-top');

            $D->file_in_template = 'max/info.php';
            $this->load_template('dashboard-template.php');

        } else {

            if (!isset($D->string_js) || !is_array($D->string_js)) $D->string_js = array();
            array_push($D->string_js, 'moment.locale("'.$K->LANGUAGE.'");');

            $this->load_extract_controller('_required-out');

            $D->file_in_template = 'max/info.php';
            $this->load_template('site-template.php');

        }

    }

?>