<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /****************************************************************/    
    /****************************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->idcompany = '';
	if ($this->param('c')) $D->idcompany = $this->param('c');
    $D->idcompany = $the_sanitaze->int($D->idcompany);
    if ($D->idcompany <= 0) $this->globalRedirect($K->SITE_URL.'superadmin/companies');

    $info_company = $this->db2->fetch("SELECT idcompany FROM companies WHERE idcompany=".$D->idcompany." LIMIT 1");
    if (!$info_company) $this->globalRedirect($K->SITE_URL.'superadmin/companies');

    $D->me = $this->user->info;

    $D->the_company = $this->db2->fetch("SELECT * FROM companies WHERE idcompany=".$D->idcompany." LIMIT 1");

    $D->name_company = stripslashes($D->the_company->name);
    $D->phone_company = stripslashes($D->the_company->phone);
    $D->username_company = $D->the_company->username;
    
    $json_plan = json_decode($D->the_company->theplan);
    $D->theplan_max_users = $json_plan->max_user;
    $D->theplan_days = $json_plan->days;
    $D->theplan_sup_videos = $json_plan->post_types->video;
    $D->theplan_sup_audios = $json_plan->post_types->audio;

    $D->company_with_cdomain = 0;
    if (isset($json_plan->cdomain)) { $D->company_with_cdomain = $json_plan->cdomain; }
    
    $D->company_url_cdomain = '';
    if ($K->WITH_CUST_DOM) $D->company_url_cdomain = stripslashes($D->the_company->custom_domain);

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_companies';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-companies-edit.php';

		} else {

            $for_load = 'max/superadmin-companies-edit.php';

		}

        $D->titlePhantom = $this->lang('superadmin_users_title_page').' | '.$D->name_company;

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_users_title_page').' | '.$D->name_company;    	

        $D->file_in_template = 'max/superadmin-companies-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>