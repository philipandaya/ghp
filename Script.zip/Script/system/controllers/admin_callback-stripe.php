<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

if (!$D->_IS_LOGGED) $this->globalRedirect('login');
if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

$the_sanitaze = new sanitize(); // init sanitaze

if ($this->param('sid')) $idsesion = $this->param('sid');
$idsesion = $the_sanitaze->str_nohtml($idsesion);
if (empty($idsesion)) $this->globalRedirect($K->SITE_URL.'admin/membership');

if ($this->param('cr')) $thereference = $this->param('cr');
$thereference = $the_sanitaze->str_nohtml($thereference);
if (empty($thereference)) $this->globalRedirect($K->SITE_URL.'admin/membership');

$theorder = $this->db2->fetch("SELECT * FROM orders WHERE idcompany=".$this->user->info->idcompany." AND payment_id='".$thereference."' AND status='PENDING' LIMIT 1");

if (!$theorder) $this->globalRedirect($K->SITE_URL.'admin/membership');

include('helpers/Stripe/init.php');
            
\Stripe\Stripe::setApiKey($K->STRIPE_SECRET_KEY);

try {
    $sessionData = \Stripe\Checkout\Session::retrieve($idsesion);

    if (empty($sessionData)) {
        $this->globalRedirect($K->SITE_URL.'admin/membership/payfailed');
    }
    
    $stripeData = \Stripe\PaymentIntent::retrieve($sessionData->payment_intent);

} catch (Exception $e) {
    $this->globalRedirect($K->SITE_URL.'admin/membership/payfailed');
}

//var_dump($stripeData);

if (isset($stripeData['status']) and $stripeData['status'] == "succeeded") {

    $email_notifications = $K->EMAIL_NOTIFICATION_STRIPE;

    $more_info = explode(":", $theorder->data);
    $codeuser = $more_info[0];
    $idplan = $more_info[1];
    $time_plan = $more_info[2];
    $days_add = 30;
    if ($time_plan == 1) $days_add = 31;
    if ($time_plan == 2) $days_add = 365;

    $theplan = $this->db2->fetch_field("SELECT settings FROM plans WHERE idplan=".$idplan." LIMIT 1");
    
    $codecompany = $this->db2->fetch_field("SELECT code FROM companies WHERE idcompany=".$this->user->info->idcompany." LIMIT 1");

    $this->db2->query("INSERT INTO pays SET codecompany='".$codecompany."', codeuser='".$this->user->info->code."', whendate='".time()."', txn_id='', item_name='Membership', payment_status='".$stripeData['status']."', payment_amount='".number_format($stripeData->amount/100,2)."', payment_currency='".$stripeData->currency."', payer_email='".$this->user->info->user_email."', payment_type='instant', custom='".$theorder->data."', invoice='', first_name='".stripslashes($this->user->info->firstname)."', last_name='".stripslashes($this->user->info->firstname)."', address_name='', address_country='".$_SERVER['REMOTE_ADDR']."', address_country_code='', address_zip='', address_state='', address_city='', address_street='', infoplan='".$theplan."'");
    
    $json1 = json_decode($theplan);
    $p_storage = $json1->storage;
    $p_max_users = $json1->max_user;
    $p_sup_videos = $json1->post_types->video;  
    $p_sup_audios = $json1->post_types->audio;
    
    $p_with_cdomain = 0;
    if ($K->WITH_CUST_DOM) {
        if (isset($json1->cdomain)) { $p_with_cdomain = $json1->cdomain; }
    }
    
    $theplan_company = $this->db2->fetch_field("SELECT theplan FROM companies WHERE code='".$codecompany."' LIMIT 1");  
    $json2 = json_decode($theplan_company);
    
    $storage = $json2->storage;
    $num_days = $json2->days;
    $init = $json2->init;
    
    $the_today = time();
    $one_day = 60 * 60 * 24;
    $total_time = $init + ($num_days * $one_day);
    
    $missing_days = 0;

    if ($total_time > $the_today) $missing_days = round(($total_time - $the_today)/$one_day);
    
    
    $plan_end = array('storage' => $p_storage, 'max_user' => $p_max_users, 'post_types' => array('video' => $p_sup_videos, 'audio' => $p_sup_audios), 'days' => ($missing_days + $days_add), 'plan' => $idplan, 'cdomain' => $p_with_cdomain, 'init' => time());

    $this->db2->query("UPDATE companies SET theplan='".json_encode($plan_end)."' WHERE code='".$codecompany."' LIMIT 1"); 


    
    $this->db2->query("UPDATE orders SET status='PAID' WHERE idcompany=".$this->user->info->idcompany." AND payment_id='".$thereference."' AND status='PENDING' LIMIT 1");


    if ($K->MAIL_WITH_PHPMAILER) @sendMail_PHPMailer($email_notifications, 'New payment was successfully', "New payment was successfully recieved by Paystack. From ".stripslashes($this->user->info->firstname).' '.stripslashes($this->user->info->lastname));
    else @sendEmail($email_notifications, 'New payment was successfully', "New payment was successfully recieved by Paystack. From ".stripslashes($this->user->info->firstname).' '.stripslashes($this->user->info->lastname));
    
    $this->globalRedirect($K->SITE_URL.'admin/membership/payok');

} else {
    if ($K->MAIL_WITH_PHPMAILER) @sendMail_PHPMailer($email_notifications, 'Payment declined', "The payment was not accepted by Paystack. Payment attempt made by: ".stripslashes($this->user->info->firstname).' '.stripslashes($this->user->info->lastname));
    else @sendEmail($email_notifications, 'Payment declined', "The payment was not accepted by Paystack. Payment attempt made by: ".stripslashes($this->user->info->firstname).' '.stripslashes($this->user->info->lastname));

    $this->globalRedirect($K->SITE_URL.'admin/membership/payfailed');
}
?>