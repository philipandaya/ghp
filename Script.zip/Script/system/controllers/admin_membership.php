<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /****************************************************************/    
    /****************************************************************/

    $D->company_num_users = $this->db2->fetch_field("SELECT count(iduser) FROM users WHERE idcompany=".$this->user->info->idcompany." LIMIT 1");
    if (!$D->company_num_users) $D->company_num_users = 0;
    
    $D->theplan_company = $this->db2->fetch("SELECT theplan FROM companies WHERE idcompany=".$this->user->info->idcompany." LIMIT 1");
    
    $D->theplan_max_users = 0;
    $D->theplan_percent_users = 0;
    $D->theplan_days = 0;
    $D->the_diference_days = 0;
    $D->theplan_percent_days = 0;
    
    if ($D->theplan_company) {
        $json_plan = json_decode($D->theplan_company->theplan);
        $D->theplan_max_users = $json_plan->max_user;
        $D->theplan_percent_users = ($D->company_num_users * 100) / $D->theplan_max_users;

        $D->theplan_init = $json_plan->init;
        $D->theplan_days = $json_plan->days;

        $the_today = time();
                
        $one_day = 60 * 60 * 24;
        
        $the_diference = $the_today - $D->theplan_init;
        
        $D->the_diference_days = round($the_diference / $one_day);
        
        $D->theplan_percent_days = ($D->the_diference_days * 100) / $D->theplan_days;
        
        $D->hasExpired = expiredTime($D->theplan_init, $D->theplan_days);
        
    }

    /****************************************************************/
    /****************************************************************/

    $D->html_select_pays = '<option value="-1" selected="selected">'.$this->lang('admin_general_txt_choose_pay').'</option>';
    if ($K->WITH_PAYPAL) $D->html_select_pays .= '<option value="PayPal">'.$this->lang('admin_general_txt_pay_with').' PayPal</option>';

    if ($K->WITH_STRIPE) $D->html_select_pays .= '<option value="Stripe">'.$this->lang('admin_general_txt_pay_with').' Stripe</option>';

    if ($K->WITH_PAYSTACK) $D->html_select_pays .= '<option value="Paystack">'.$this->lang('admin_general_txt_pay_with').' Paystack</option>';

    /****************************************************************/
    /****************************************************************/

    $D->the_plans = '';
    
    $D->plan_1 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=1 LIMIT 1");
    $json1 = json_decode($D->plan_1->settings);
    $D->p_id_plan = $D->plan_1->idplan;
    $D->p_name_plan = stripslashes($D->plan_1->name);
    $D->p_price_monthly = $D->plan_1->monthly_price;
    $D->p_price_annual = $D->plan_1->annual_price;
    $D->p_max_users = $json1->max_user;
    $D->p_sup_videos = $json1->post_types->video;
    $D->p_sup_audios = $json1->post_types->audio;
    $D->p_is_popular = $json1->popular;
    
    if ($K->WITH_CUST_DOM) $D->p_w_cdomain = $json1->cdomain;
    
    if ($D->theplan_max_users <= $D->p_max_users) {
        $D->the_plans .= $this->load_template('ones/one-plan-membership.php', FALSE);
    }
    
    $D->plan_2 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=2 LIMIT 1");
    $json2 = json_decode($D->plan_2->settings);
    $D->p_id_plan = $D->plan_2->idplan;
    $D->p_name_plan = stripslashes($D->plan_2->name);
    $D->p_price_monthly = $D->plan_2->monthly_price;
    $D->p_price_annual = $D->plan_2->annual_price;
    $D->p_max_users = $json2->max_user;
    $D->p_sup_videos = $json2->post_types->video;
    $D->p_sup_audios = $json2->post_types->audio;
    $D->p_is_popular = $json2->popular;

    if ($K->WITH_CUST_DOM) $D->p_w_cdomain = $json2->cdomain;

    if ($D->theplan_max_users <= $D->p_max_users) {
        $D->the_plans .= $this->load_template('ones/one-plan-membership.php', FALSE);
    }
    
    $D->plan_3 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=3 LIMIT 1");
    $json3 = json_decode($D->plan_3->settings);
    $D->p_id_plan = $D->plan_3->idplan;
    $D->p_name_plan = stripslashes($D->plan_3->name);
    $D->p_price_monthly = $D->plan_3->monthly_price;
    $D->p_price_annual = $D->plan_3->annual_price;
    $D->p_max_users = $json3->max_user;
    $D->p_sup_videos = $json3->post_types->video;
    $D->p_sup_audios = $json3->post_types->audio;
    $D->p_is_popular = $json3->popular;

    if ($K->WITH_CUST_DOM) $D->p_w_cdomain = $json3->cdomain;
        
    if ($D->theplan_max_users <= $D->p_max_users) {
        $D->the_plans .= $this->load_template('ones/one-plan-membership.php', FALSE);
    }

    /****************************************************************/
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_membership';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-membership.php';

		} else {

            $for_load = 'max/admin-membership.php';

		}

        $D->titlePhantom = $this->lang('admin_membership_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_membership_title_page');    	

        $D->file_in_template = 'max/admin-membership.php';
        $this->load_template('dashboard-template.php');

	}

?>