<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/

    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->codestatic = '';
	if ($this->param('s')) $D->codestatic = $this->param('s');
    $D->codestatic = $the_sanitaze->str_nohtml($D->codestatic);
    if (empty($D->codestatic)) $this->globalRedirect($K->SITE_URL.'admin/static-pages');

    $info_static = $this->db2->fetch("SELECT * FROM statics_companies WHERE code='".$D->codestatic."' LIMIT 1");

    if (!$info_static) $this->globalRedirect($K->SITE_URL.'admin/static-pages');

    $D->title = stripslashes($info_static->title);
    $D->html = stripslashes($info_static->texthtml);
    $D->url = stripslashes($info_static->url);
    $D->infoot = $info_static->show_in_foot;

    /************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_staticpages';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-static-pages-edit.php';

		} else {

            $for_load = 'max/admin-static-pages-edit.php';

		}

        $D->titlePhantom = $this->lang('admin_static_pages_edit_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_static_pages_edit_title_page');    	

        $D->file_in_template = 'max/admin-static-pages-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>