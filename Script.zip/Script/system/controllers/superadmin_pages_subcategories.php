<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->idcat = '';
	if ($this->param('c')) $D->idcat = $this->param('c');
    $D->idcat = $the_sanitaze->int($D->idcat);
    if ($D->idcat <= 0) $this->globalRedirect($K->SITE_URL.'superadmin/pages/categories');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /****************************************************************/    
    /****************************************************************/

    $D->name_category = $this->db2->fetch_field("SELECT name FROM pages_cat WHERE idcategory=".$D->idcat." LIMIT 1");

    if (!$D->name_category) $this->globalRedirect($K->SITE_URL.'superadmin/pages/categories');

    $items = $this->db2->fetch_all("SELECT * FROM pages_cat WHERE idfather=".$D->idcat." ORDER BY name ASC");

    $D->html_items = '';

    foreach ($items as $oneitem) {
        $D->one = $oneitem;
        $D->one->name = stripslashes($oneitem->name);
        $D->html_items .= $this->load_template('ones/one-subcategory-page.php', FALSE);
    }

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_pages_categories';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-pages-subcategories.php';

		} else {

            $for_load = 'max/superadmin-pages-subcategories.php';

		}

        $D->titlePhantom = $this->lang('superadmin_pages_subcategories_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_pages_subcategories_title_page');    	

        $D->file_in_template = 'max/superadmin-pages-subcategories.php';
        $this->load_template('dashboard-template.php');

	}

?>