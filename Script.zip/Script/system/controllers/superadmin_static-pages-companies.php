<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /************************************************/

    $D->items_statics = '';

    $statics = $this->db2->fetch_all('SELECT * FROM statics_companies ORDER BY idstatic DESC');
    $D->numstatics = count($statics);
    foreach($statics as $onestatic) {
        $D->onestatic = $onestatic;
        $D->onestatic->title = stripslashes($onestatic->title);
        
        $thecompany = $this->network->getCompanyById($D->onestatic->idcompany);
        $D->stpc_idcompany = $D->onestatic->idcompany;
        $D->stpc_usernamecompany = $thecompany->username;
        $D->stpc_namecompany = $thecompany->name;
        
        $D->items_statics .= $this->load_template('ones/one-static-page-companies.php', FALSE);
    }

    /************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_staticpages_companies';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-static-pages-companies.php';

		} else {

            $for_load = 'max/superadmin-static-pages-companies.php';

		}

        $D->titlePhantom = $this->lang('superadmin_static_pages_companies_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_static_pages_companies_title_page');    	

        $D->file_in_template = 'max/superadmin-static-pages-companies.php';
        $this->load_template('dashboard-template.php');

	}

?>