<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('settings.php');

    /****************************************************************/    
    /****************************************************************/

    $D->firstname = stripslashes($this->user->info->firstname);
    $D->lastname = stripslashes($this->user->info->lastname);
    $D->gender = $this->user->info->gender;
    $D->born = explode('-', $this->user->info->birthday);
    $D->hometown = stripslashes($this->user->info->hometown);
    $D->currentcity = stripslashes($this->user->info->currentcity);
    $D->aboutme = stripslashes($this->user->info->aboutme);

    /****************************************************************/    
    /****************************************************************/

    $D->id_menu = 'opt_set_profile';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';
            
		if ($D->layout_size == 'min') {

            $for_load = 'min/settings-profile.php';

		} else {

            $for_load = 'max/settings-profile.php';

		}

        $D->titlePhantom = $this->lang('setting_profile_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('setting_profile_title_page');

        $D->file_in_template = 'max/settings-profile.php';
        $this->load_template('dashboard-template.php');

	}

?>