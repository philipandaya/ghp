<?php   
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
    
    $this->load_extract_controller('_info-company-dash');

    if (!$D->sett_comp_mod_pages) $this->globalRedirect('dashboard');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');
    
    $D->show_more = FALSE;
    $D->the_list_items = '';
    
    /****************************************************************************/
    
    $res = $this->db2->query("SELECT * FROM pages WHERE idcompany=".$D->company_id." AND idcreator=".$this->user->info->iduser." ORDER BY idpage DESC LIMIT 0, ".($K->ITEMS_PER_PAGE + 1));
    $total_items = $this->db2->num_rows();

    $count_regs = 0;
    while ($obj = $this->db2->fetch_object($res)) {
        
        $D->page = $obj;
        $D->page->title = stripslashes($D->page->title);
        $D->page->puname = stripslashes($D->page->puname);

        if (empty($D->page->avatar) || $D->page->avatar == $K->DEFAULT_AVATAR_PAGE) {
            $cover_tmp_name = pathinfo($K->AVATAR_PAGE_TMP, PATHINFO_FILENAME);
            $cover_tmp_extension = pathinfo($K->AVATAR_PAGE_TMP, PATHINFO_EXTENSION);
            $D->page->avatar = getImageMisc($cover_tmp_name.'_min2.'.$cover_tmp_extension);
        } else {
            $D->page->avatar = $K->STORAGE_URL_AVATARS_PAGE.'min2/'.$D->page->code.'/'.$D->page->avatar;
        }
        
		$D->nameCategory = stripslashes($this->network->getNameCatPage($D->page->idsubcat));
        
        $D->page_last = FALSE;
        if ($total_items < $count_regs + 2) $D->page_last = TRUE;
        
        $D->the_list_items .= $this->load_template('ones/one-page.php', FALSE);

        $count_regs++;
        if ($count_regs >= $K->ITEMS_PER_PAGE) break;

    }
    
    if ($total_items > $K->ITEMS_PER_PAGE) $D->show_more = TRUE;

    /****************************************************************************/

    $D->id_menu = 'opt_ml_yourpages';
    
    $this->load_extract_controller('_load-menus');
    
    $this->load_extract_controller('_pre-dashboard');

    /****************************************************************************/
    
	if ($D->isPhantom) {

        $html = '';
        
		if ($D->layout_size == 'min') {
            $for_load = 'min/pages.php';
		} else {
            $for_load = 'max/pages.php';
		}
        
        $D->titlePhantom = $this->lang('dashboard_pages_title_your_p', array('#COMPANY#'=>$D->company_name));

        $html .= $this->load_template($for_load, FALSE);
        echo $html;
        
	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');
        
        $D->page_title = $this->lang('dashboard_pages_title_your_p', array('#COMPANY#'=>$D->company_name));

        $D->file_in_template = 'max/pages.php';
        $this->load_template('dashboard-template.php');
        
    }
?>