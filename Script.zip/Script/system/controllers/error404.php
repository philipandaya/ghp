<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    if ($D->_IS_LOGGED) {
        $this->load_extract_controller('_info-company-dash');
    }
    
    $D->menu_footer = FALSE;

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');

    if ($D->_IS_LOGGED) {
        $this->loadLanguage('dashboard.php');
    	$D->me = $this->user->info;
    }

    $D->id_container = 'site';

    $D->msg01 = $this->lang('global_txt_404_sorry');
    $D->msg02 = $this->lang('global_txt_404_broken');

	if ($D->isPhantom) {

        $html = '';

        if ($D->_IS_LOGGED) {

            $D->id_container = 'dashboard';
            $this->load_extract_controller('_load-menus');

        }

        if ($D->layout_size == 'min') {
            $for_load = 'min/error404.php';
        } else {
            $for_load = 'max/error404.php';
        }

        $D->titlePhantom = $this->lang('global_txt_404_title_page').(isset($D->company_name) ? ' | '.$D->company_name : '');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $D->page_title = $this->lang('global_txt_404_title_page').(isset($D->company_name) ? ' | '.$D->company_name : '');

        if ($D->_IS_LOGGED) {
            
            $D->id_container = 'dashboard';
            $this->load_extract_controller('_load-menus');

            $this->load_extract_controller('_required-dashboard');
            $this->load_extract_controller('_dashboard-bar-top');

            $D->file_in_template = 'max/error404.php';
            $this->load_template('dashboard-template.php');

        } else {

            if (!isset($D->string_js) || !is_array($D->string_js)) $D->string_js = array();
            array_push($D->string_js, 'moment.locale("'.$K->LANGUAGE.'");');

            $this->load_extract_controller('_required-out');

            $D->file_in_template = 'max/error404.php';
            $this->load_template('site-template.php');

        }

    }

?>