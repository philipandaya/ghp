<?php
$email_notifications = $K->EMAIL_NOTIFICATION_PAYPAL;

function Array2Str($kvsep, $entrysep, $a) {
	$str = "";
	foreach ($a as $k=>$v) {
		$str .= "{$k}{$kvsep}{$v}{$entrysep}";
	}
	return $str;
}

$req = 'cmd=_notify-validate';
$fullipnA = array();
 
foreach ($_POST as $key => $value) {
	$fullipnA[$key] = $value; 
	$encodedvalue = urlencode(stripslashes($value));
	$req .= "&$key=$encodedvalue";
}

$fullipn = Array2Str(" : ", "\n", $fullipnA);

$url = $K->URL_ACTION_PAYPAL_IPN;

//$url = 'https://sandbox.paypal.com/cgi-bin/webscr'; // in case use sandbox
// $url = 'https://paypal.com/cgi-bin/webscr';	// in live

/********************************************/
//Enable if your site uses https

//$url = 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr'; // in case use sandbox
//$url = 'https://ipnpb.paypal.com/cgi-bin/webscr'; // in live

/********************************************/

$curl_result = $curl_err = '';
$fp = curl_init();
curl_setopt($fp, CURLOPT_URL,$url);
curl_setopt($fp, CURLOPT_RETURNTRANSFER,1);
curl_setopt($fp, CURLOPT_POST, 1);
curl_setopt($fp, CURLOPT_POSTFIELDS, $req);
curl_setopt($fp, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded", "Content-Length: " . strlen($req)));
curl_setopt($fp, CURLOPT_HEADER , 0); 
curl_setopt($fp, CURLOPT_VERBOSE, 1);
curl_setopt($fp, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($fp, CURLOPT_TIMEOUT, 30);
 
$response = curl_exec($fp);
$curl_err = curl_error($fp);
curl_close($fp);

 
// Variables received by Paypal
if (isset($_POST['payment_status'])) {

    $payment_status = $_POST['payment_status'];
    
    // REMOVE COMMENTS /**/ IF USSING "https"
    /*if (strcmp ($response, "VERIFIED") == 0) */
    {
        // Check the status of the order
        if ($payment_status != "Completed")	{
            if ($K->MAIL_WITH_PHPMAILER) @sendMail_PHPMailer($email_notifications, 'Payment declined', "The payment was not accepted by paypal - Payment Status: $payment_status");
            else @sendEmail($email_notifications, 'Payment declined', "The payment was not accepted by paypal - Payment Status: $payment_status");
            exit;
        }
        
        // Variables received by Paypal
        $item_name = isset($_POST['item_name']) ? $_POST['item_name'] : '';
        $payment_status = isset($_POST['payment_status']) ? $_POST['payment_status'] : '';
        $payment_amount = isset($_POST['mc_gross']) ? $_POST['mc_gross'] : '';
        $payment_currency = isset($_POST['mc_currency']) ? $_POST['mc_currency'] : '';
        $txn_id = isset($_POST['txn_id']) ? $_POST['txn_id'] : '';
        $receiver_email = isset($_POST['receiver_email']) ? $_POST['receiver_email'] : '';
        $payer_email = isset($_POST['payer_email']) ? $_POST['payer_email'] : '';
        $txn_type = isset($_POST['txn_type']) ? $_POST['txn_type'] : '';
        $pending_reason = isset($_POST['pending_reason']) ? $_POST['pending_reason'] : '';
        $payment_type = isset($_POST['payment_type']) ? $_POST['payment_type'] : '';
        $custom = isset($_POST['custom']) ? $_POST['custom'] : '';
        $invoice = isset($_POST['invoice']) ? $_POST['invoice'] : '';
        
        // Buyer information
        $first_name = isset($_POST['first_name']) ? $_POST['first_name'] : '';
        $last_name = isset($_POST['last_name']) ? $_POST['last_name'] : '';
        $address_name = isset($_POST['address_name']) ? $_POST['address_name'] : '';
        $address_country = isset($_POST['address_country']) ? $_POST['address_country'] : '';
        $address_country_code = isset($_POST['address_country_code']) ? $_POST['address_country_code'] : '';
        $address_zip = isset($_POST['address_zip']) ? $_POST['address_zip'] : '';
        $address_state = isset($_POST['address_state']) ? $_POST['address_state'] : '';
        $address_city = isset($_POST['address_city']) ? $_POST['address_city'] : '';
        $address_street = isset($_POST['address_street']) ? $_POST['address_street'] : '';
        
        if ($K->MAIL_WITH_PHPMAILER) @sendMail_PHPMailer($email_notifications, 'New payment was successfully', "New payment was successfully recieved from $payer_email");
        else @sendEmail($email_notifications, 'New payment was successfully', "New payment was successfully recieved from $payer_email");
    
        $more_info = explode(":", $custom);
        $codecompany = $more_info[0];
        $codeuser = $more_info[1];
        $idplan = $more_info[2];
        $time_plan = $more_info[3];
        $days_add = 30;
        if ($time_plan == 1) $days_add = 31;
        if ($time_plan == 2) $days_add = 365;
        
        $theplan = $this->db2->fetch_field("SELECT settings FROM plans WHERE idplan=".$idplan." LIMIT 1");

        $this->db2->query("INSERT INTO pays SET codecompany='".$codecompany."', codeuser='".$codeuser."', whendate='".time()."', txn_id='".$txn_id."', item_name='".$item_name."', payment_status='".$payment_status."', payment_amount='".$payment_amount."', payment_currency='".$payment_currency."', payer_email='".$payer_email."', payment_type='".$payment_type."', custom='".$custom."', invoice='".$invoice."', first_name='".$first_name."', last_name='".$last_name."', address_name='".$address_name."', address_country='".$address_country."', address_country_code='".$address_country_code."', address_zip='".$address_zip."', address_state='".$address_state."', address_city='".$address_city."', address_street='".$address_street."', infoplan='".$theplan."'");
        
        /**************************/

        $json1 = json_decode($theplan);
        $p_storage = $json1->storage;
        $p_max_users = $json1->max_user;
        $p_sup_videos = $json1->post_types->video;  
        $p_sup_audios = $json1->post_types->audio;
        
        $p_with_cdomain = 0;
        if ($K->WITH_CUST_DOM) {
            if (isset($json1->cdomain)) { $p_with_cdomain = $json1->cdomain; }
        }
        
        /**************************/
        
        $theplan_company = $this->db2->fetch_field("SELECT theplan FROM companies WHERE code='".$codecompany."' LIMIT 1");  
        $json2 = json_decode($theplan_company);
        
        $storage = $json2->storage;
        $num_days = $json2->days;
        $init = $json2->init;
        
        $the_today = time();
        $one_day = 60 * 60 * 24;
        $total_time = $init + ($num_days * $one_day);
        
        $missing_days = 0;

        if ($total_time > $the_today) $missing_days = round(($total_time - $the_today)/$one_day);
        
        
        $plan_end = array('storage' => $p_storage, 'max_user' => $p_max_users, 'post_types' => array('video' => $p_sup_videos, 'audio' => $p_sup_audios), 'days' => ($missing_days + $days_add), 'plan' => $idplan, 'cdomain' => $p_with_cdomain, 'init' => time());

        $this->db2->query("UPDATE companies SET theplan='".json_encode($plan_end)."' WHERE code='".$codecompany."' LIMIT 1"); 
        

    }
    
    // REMOVE COMMENTS /**/ IF USSING "https"
    /* 
    else {
         //the transaction is invalid I can NOT charge the client. 
        if ($K->MAIL_WITH_PHPMAILER) sendEmailPHPMailer($email_notifications, 'Invalid payment', "Invalid payment - $fullipn");
        else sendEmail($email_notifications, 'Invalid payment', "Invalid payment - $fullipn");
    }
    */
} else {
    echo('Error'); die();
}
?>