<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /****************************************************************/    
    /****************************************************************/

    $D->me = $this->user->info;

    $D->qsql = '';
	$D->USER_PER_PAGE = $K->ITEMS_PER_PAGE;
	$D->pageCurrent = 1;
	if ($this->param('p')) $D->pageCurrent = $this->param('p');

	$D->totalitems = $this->db2->fetch_field('SELECT count(id) FROM users_pending WHERE idcompany='.$this->user->info->idcompany.' '.$D->qsql);

	$D->start = ($D->pageCurrent-1) * $D->USER_PER_PAGE;

    /**** Pagination ****/

    $D->url_list = $K->SITE_URL.'admin/users/pending/';

    $D->totalPag = ceil($D->totalitems/$D->USER_PER_PAGE);
    if ($D->totalPag == 0) $D->totalPag = 1;
    if ($D->totalPag < $D->pageCurrent) $this->globalRedirect($D->url_list);
    $D->pagVisibles = 2;

    if ($D->totalPag > (2 * $D->pagVisibles) + 1) {

        $D->firstPage = $D->pageCurrent - $D->pagVisibles;
        if ($D->firstPage < 1) $D->firstPage = 1;

        $D->lastPage = $D->firstPage + (2 * $D->pagVisibles);
        if ($D->lastPage > $D->totalPag) $D->lastPage = $D->totalPag;

        if ($D->lastPage - $D->firstPage < (2 * $D->pagVisibles) + 1) $D->firstPage = $D->lastPage - (2 * $D->pagVisibles);

    } else {

        $D->firstPage = 1;
        $D->lastPage = $D->totalPag;

    }

    /********************/

    $items = $this->db2->fetch_all("SELECT * FROM users_pending WHERE idcompany=".$this->user->info->idcompany." ".$D->qsql." ORDER BY user_username ASC LIMIT ".$D->start.",".$D->USER_PER_PAGE);

    $D->numusers = count($items);

    $D->html_items = '';

    foreach ($items as $oneitem) {
        $D->one = $oneitem;

        if (empty($oneitem->avatar) || $oneitem->avatar == $K->DEFAULT_AVATAR_USER) {
            $avatar_tmp_name = pathinfo($K->{'AVATAR_USER_TMP_'.$oneitem->gender}, PATHINFO_FILENAME);
            $avatar_tmp_extension = pathinfo($K->{'AVATAR_USER_TMP_'.$oneitem->gender}, PATHINFO_EXTENSION);
            $D->one->avatar = getImageMisc($avatar_tmp_name.'_min2.'.$avatar_tmp_extension);
        } else {
            $D->one->avatar = $K->STORAGE_URL_AVATARS.'min2/'.$D->one->code.'/'.$oneitem->avatar;
        }

        $D->one->allname = stripslashes($oneitem->firstname).' '.stripslashes($oneitem->lastname);
        $D->one->username = stripslashes($oneitem->user_username);

        $D->html_items .= $this->load_template('ones/one-user-pending-list-admin.php', FALSE);
    }

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_users_pending';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-users-pending.php';

		} else {

            $for_load = 'max/admin-users-pending.php';

		}

        $D->titlePhantom = $this->lang('admin_users_pending_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_users_pending_title_page');    	

        $D->file_in_template = 'max/admin-users-pending.php';
        $this->load_template('dashboard-template.php');

	}

?>