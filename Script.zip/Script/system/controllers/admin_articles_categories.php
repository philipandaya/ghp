<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');

	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /****************************************************************/    
    /****************************************************************/

    $items = $this->db2->fetch_all("SELECT * FROM articles_cat WHERE idcompany=".$this->user->info->idcompany." AND idfather=0 ORDER BY name ASC");

    $D->html_items = '';

    foreach ($items as $oneitem) {
        $D->one = $oneitem;
        $D->one->name = stripslashes($oneitem->name);
        $D->html_items .= $this->load_template('ones/one-category-article-admin.php', FALSE);
    }

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_articles_categories';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-articles-categories.php';

		} else {

            $for_load = 'max/admin-articles-categories.php';

		}

        $D->titlePhantom = $this->lang('admin_articles_categories_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_articles_categories_title_page');    	

        $D->file_in_template = 'max/admin-articles-categories.php';
        $this->load_template('dashboard-template.php');

	}

?>