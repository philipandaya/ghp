<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');
    
    $this->load_extract_controller('_info-company-dash');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');

    /****************************************************************/    
    /****************************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->codeproduct = '';
	if ($this->param('p')) $D->codeproduct = $this->param('p');
    $D->codeproduct = $the_sanitaze->str_nohtml($D->codeproduct);
    if (empty($D->codeproduct)) $this->globalRedirect($K->SITE_URL.'admin/products');

    $info_product = $this->db2->fetch("SELECT idproduct FROM products WHERE idcompany=".$this->user->info->idcompany." AND code='".$D->codeproduct."' LIMIT 1");

    if (!$info_product) $this->globalRedirect($K->SITE_URL.'admin/products');

    $D->me = $this->user->info;

    $info_product = $this->db2->fetch("SELECT * FROM products WHERE idcompany=".$this->user->info->idcompany." AND code='".$D->codeproduct."' LIMIT 1");
    
    $D->idproduct = $info_product->idproduct;
    $D->name = stripslashes($info_product->name);
    $D->description = stripslashes($info_product->description);
    $D->idcategory = $info_product->idcategory;
    $D->idsubcategory = $info_product->idsubcategory;
    $D->location = stripslashes($info_product->location);
    $D->currency = $info_product->currency;
    $D->price = $info_product->price;
    $D->type_product = $info_product->type_product;
    $D->status = $info_product->status;
    
    $D->currencies = '';
    $currencies = $this->db2->fetch_all("SELECT * FROM currencies_companies WHERE idcompany=".$this->user->info->idcompany." ORDER BY code_iso ASC");
    if ($currencies) {
        foreach ($currencies as $onecurrency) {
            $D->currencies .= '<option value="'.$onecurrency->idcurrency.'"'.($D->currency == $onecurrency->idcurrency ? 'selected' : '').'>'.$onecurrency->code_iso.' ('.$onecurrency->symbol.')</option>';
        }
    }

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_products';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-products-edit.php';

		} else {

            $for_load = 'max/admin-products-edit.php';

		}

        $D->titlePhantom = $this->lang('admin_products_title_page').' | '.$D->name;

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_products_title_page').' | '.$D->name;    	

        $D->file_in_template = 'max/admin-products-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>