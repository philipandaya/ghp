<?php 
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
    
    $this->load_extract_controller('_info-company-dash');
    
    if (!$D->sett_comp_mod_marketplace) $this->globalRedirect('dashboard');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');


    $the_sanitaze = new sanitize(); // init sanitaze
	$D->codeproduct = '';
	if ($this->param('p')) $D->codeproduct = $this->param('p');
    $D->codeproduct = $the_sanitaze->str_nohtml($D->codeproduct);
    if (empty($D->codeproduct)) $this->globalRedirect($K->SITE_URL.'products');

    $info_product = $this->db2->fetch("SELECT * FROM products WHERE idsell=".$user->info->iduser." AND code='".$D->codeproduct."' LIMIT 1");

    if (!$info_product) $this->globalRedirect($K->SITE_URL.'products');

    $D->idproduct = $info_product->idproduct;
    $D->name = stripslashes($info_product->name);
    $D->description = stripslashes($info_product->description);
    $D->idcategory = $info_product->idcategory;
    $D->idsubcategory = $info_product->idsubcategory;
    $D->location = stripslashes($info_product->location);
    $D->currency = $info_product->currency;
    $D->price = $info_product->price;
    $D->type_product = $info_product->type_product;
    
    $D->photo = array();
    $photos_prod = $this->db2->fetch_all("SELECT * FROM products_images WHERE idproduct=".$D->idproduct);
    if ($photos_prod) {
        foreach ($photos_prod as $onephoto) {
            $D->photo[] = $onephoto->photo;
        }
    }
    
    
    $D->currencies = '';
    $currencies = $this->db2->fetch_all("SELECT * FROM currencies_companies WHERE idcompany=".$D->company_id." ORDER BY code_iso ASC");
    if ($currencies) {
        foreach ($currencies as $onecurrency) {
            $D->currencies .= '<option value="'.$onecurrency->idcurrency.'"'.($D->currency == $onecurrency->idcurrency ? 'selected' : '').'>'.$onecurrency->code_iso.' ('.$onecurrency->symbol.')</option>';
        }
    }

    $D->id_menu = 'opt_ml_products';
    
    $this->load_extract_controller('_load-menus');
    
    $this->load_extract_controller('_pre-dashboard');

    /****************************************************************************/

	if ($D->isPhantom) {

        $html = '';
		
        if ($D->layout_size == 'min') {
            $for_load = 'min/products-edit.php';
		} else {
            $for_load = 'max/products-edit.php';
		}

        $D->titlePhantom = $this->lang('dashboard_products_edit_title_page', array('#COMPANY#'=>$D->company_name));

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

        $D->page_title = $this->lang('dashboard_products_edit_title_page', array('#COMPANY#'=>$D->company_name));

        $D->file_in_template = 'max/products-edit.php';
        $this->load_template('dashboard-template.php');

    }

?>