<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    if (!$K->ALLOW_ADVERTISING_ON_USER_ACCOUNT) $this->globalRedirect('admin/general');

    $this->load_extract_controller('_info-company-dash');

    if ($D->type_account_company == 'free' && !$K->ALLOW_ADVERTISING_ON_FREE_ACCOUNT) $this->globalRedirect('admin/ads/dashboard');
    
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_ADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('admin.php');


    /************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->codeads = '';
	if ($this->param('a')) $D->codeads = $this->param('a');
    $D->codeads = $the_sanitaze->str_nohtml($D->codeads);
    if (strlen($D->codeads) != 11) $this->globalRedirect($K->SITE_URL.'admin/ads/dashboard');

    $theads = $this->db2->fetch("SELECT * FROM ads WHERE owner=0 AND idcompany=".$user->info->idcompany." AND idslot=1 AND code='".$D->codeads."' LIMIT 1");

    if (!$theads) $this->globalRedirect($K->SITE_URL.'admin/ads/dashboard');

    $D->idad = $theads->idad;
    $D->name = stripslashes($theads->name);
    $D->theurl = stripslashes($theads->theurl);
    $D->target = $theads->target;
    $D->thefile = $theads->thefile;
    $D->status = $theads->status;
    
    $D->type_ads = $theads->type_ads;
    $D->the_html  = stripslashes($theads->the_html);
    
    $D->text_type = $this->lang('admin_ads_dashboard_edit_type_ads_image');
    if ($D->type_ads == 2) $D->text_type = $this->lang('admin_ads_dashboard_edit_type_ads_html');
    

    /************************************************/


    $D->js_script_min = $this->designer->getStringJS('admin');

    $D->id_menu = 'opt_adm_adsdash';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/admin-ads-dashboard-edit.php';

		} else {

            $for_load = 'max/admin-ads-dashboard-edit.php';

		}

        $D->titlePhantom = $this->lang('admin_ads_dashboard_edit_title_page');

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('admin_ads_dashboard_edit_title_page');    	

        $D->file_in_template = 'max/admin-ads-dashboard-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>