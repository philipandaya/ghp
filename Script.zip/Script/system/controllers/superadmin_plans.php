<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');

	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /****************************************************************/    
    /****************************************************************/
    
    $D->plan_free = $this->db2->fetch_field("SELECT value FROM settings WHERE word='PLAN_FREE' LIMIT 1");
    $json = json_decode($D->plan_free);
    $D->max_users = $json->max_user;
    $D->num_days = $json->days;
    $D->sup_videos = $json->post_types->video;
    $D->sup_audios = $json->post_types->audio;
    
    $D->plan_1 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=1 LIMIT 1");
    $json1 = json_decode($D->plan_1->settings);
    $D->p1_name_plan = stripslashes($D->plan_1->name);
    $D->p1_price_monthly = $D->plan_1->monthly_price;
    $D->p1_price_annual = $D->plan_1->annual_price;
    $D->p1_max_users = $json1->max_user;
    $D->p1_sup_videos = $json1->post_types->video;
    $D->p1_sup_audios = $json1->post_types->audio;
    $D->p1_is_popular = $json1->popular;
    $D->p1_with_cdomain = $json1->cdomain;
    
    $D->plan_2 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=2 LIMIT 1");
    $json2 = json_decode($D->plan_2->settings);
    $D->p2_name_plan = stripslashes($D->plan_2->name);
    $D->p2_price_monthly = $D->plan_2->monthly_price;
    $D->p2_price_annual = $D->plan_2->annual_price;
    $D->p2_max_users = $json2->max_user;
    $D->p2_sup_videos = $json2->post_types->video;
    $D->p2_sup_audios = $json2->post_types->audio;
    $D->p2_is_popular = $json2->popular;
    $D->p2_with_cdomain = $json2->cdomain;
    
    $D->plan_3 = $this->db2->fetch("SELECT * FROM plans WHERE idplan=3 LIMIT 1");
    $json3 = json_decode($D->plan_3->settings);
    $D->p3_name_plan = stripslashes($D->plan_3->name);
    $D->p3_price_monthly = $D->plan_3->monthly_price;
    $D->p3_price_annual = $D->plan_3->annual_price;
    $D->p3_max_users = $json3->max_user;
    $D->p3_sup_videos = $json3->post_types->video;
    $D->p3_sup_audios = $json3->post_types->audio;
    $D->p3_is_popular = $json3->popular;
    $D->p3_with_cdomain = $json3->cdomain;

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_plans';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-plans.php';

		} else {

            $for_load = 'max/superadmin-plans.php';

		}

        $D->titlePhantom = $this->lang('superadmin_plans_title_page');

        $html .= $this->load_template($for_load, FALSE);

        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_plans_title_page');    	

        $D->file_in_template = 'max/superadmin-plans.php';
        $this->load_template('dashboard-template.php');

	}

?>