<?php   
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
    
    $this->load_extract_controller('_info-company');
    
    if (!$D->sett_comp_mod_events) $this->globalRedirect('dashboard');

    $D->me = $this->user->info;

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
    $this->loadLanguage('activity.php');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

    /***********************************************/

    $D->show_more = '';
    $D->the_list_items = '';
    
    $D->the_place = 5; // 1:dashboard  2:pages feed  3:groups feed  4:saved

    $events = $this->db2->fetch_all('SELECT * FROM events WHERE idcompany='.$D->company_id.' ORDER BY start_unix DESC LIMIT 0, '.($K->ITEMS_PER_PAGE + 1));

    if ($events) {
        
        $count_regs = 0;
        
        $total_items = count($events);
        
        foreach ($events as $oneevent) {
            
            $D->idevent = $oneevent->idevent;
            $D->codee_event = $oneevent->code;
            $D->title_event = stripslashes($oneevent->title);
            $D->cover_event = $oneevent->cover;
            $D->cover_position_event = $oneevent->cover_position;
            if (!empty($D->cover_event)) {
                $D->cover_event = $K->STORAGE_URL_COVERS_EVENT.$D->codee_event.'/'.$D->cover_event;
            }

            $D->themonth_s = date("n", strtotime($oneevent->date_start));
            $D->themonth_s = ucfirst(strtolower($this->lang('global_month_'.$D->themonth_s)));
            $D->theday_s = date("j", strtotime($oneevent->date_start));
            $D->date_start = $this->lang('global_format_date_event', array('#MONTH#' => $D->themonth_s, '#DAY#' => $D->theday_s));
            
            $themonth_e = date("n", strtotime($oneevent->date_end));
            $themonth_e = ucfirst(strtolower($this->lang('global_month_'.$themonth_e)));
            $theday_e = date("j", strtotime($oneevent->date_end));
            $D->date_end = $this->lang('global_format_date_event', array('#MONTH#' => $themonth_e, '#DAY#' => $theday_e));
            
            $D->date_of_event = '';
            if ($D->date_end == $D->date_start) $D->date_of_event = $D->date_start;
            else $D->date_of_event = $D->date_start.' - '.$D->date_end;
            
            $D->going = $this->db2->fetch_field('SELECT count(id) FROM events_actions WHERE idevent='.$D->idevent.' AND type_action=2');
            $D->interested = $this->db2->fetch_field('SELECT count(id) FROM events_actions WHERE idevent='.$D->idevent.' AND type_action=1');
            
            $D->url_event = $D->theURLCompany.'event/'.$D->codee_event;
            
            $D->the_list_items .= $this->load_template('ones/one-event-max.php', FALSE);
            

            $count_regs++;
            if ($count_regs >= $K->ITEMS_PER_PAGE) break;
            
        }
        
        if ($total_items > $K->ITEMS_PER_PAGE) $D->show_more = TRUE;


    }

    /***********************************************/

    $D->id_menu = 'opt_ml_events';
    
    $this->load_extract_controller('_load-menus');
    
    $this->load_extract_controller('_pre-dashboard');

    /****************************************************************************/

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/events.php';

		} else {

            $for_load = 'max/events.php';

		}

        $D->titlePhantom = $this->lang('dashboard_events_title_page', array('#COMPANY#'=>$D->company_name));

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

        $D->page_title = $this->lang('dashboard_events_title_page', array('#COMPANY#'=>$D->company_name));

        $D->file_in_template = 'max/events.php';
        $this->load_template('dashboard-template.php');

    }

?>