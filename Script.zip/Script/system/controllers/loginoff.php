<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    if ($this->user->is_logged) { $this->redirect('superadmin/general'); }

    if (isset($_POST['login']) && $_POST['login'] == 'ok') {
        $the_sanitaze = new sanitize();
        $username = $the_sanitaze->str_nohtml($_POST['username']);
        $password = $the_sanitaze->str_nohtml($_POST['password']);
        $idcompany = $this->db2->fetch_field("SELECT idcompany FROM users WHERE is_admin=1 AND leveladmin=3 LIMIT 1");
        if ($this->user->login($username, hash('sha256', $password), $idcompany)) $this->redirect('superadmin/general');
    }
    $this->loadLanguage('off.php');
    $D->page_title = $K->SITE_TITLE;
    $this->load_template('loginoff.php');
?>