<?php
/*
********************************************************
* @author: MCode Developer
* @author_url: https://www.mcodedeveloper.com
* @author_email: m@mcodedeveloper.com
* @support_email: devs@mcodedeveloper.com
********************************************************
* YaaX - SaaS platform to create social networks
* Copyright (c) 2023 MCode Developer. All rights reserved.
********************************************************
*/
    $this->load_extract_controller('_info-company-dash');

	if (!$D->_IS_LOGGED) $this->globalRedirect('login');
	if (!$D->_IS_SUPERADMIN_USER) $this->globalRedirect('login');

	$D->isPhantom = FALSE;
	if ($this->param('phantom') && $this->param('phantom')=='yes') $D->isPhantom = TRUE;

	$D->layout_size = 'min';
	if ($this->param('lysize')) $D->layout_size = $this->param('lysize');

	$this->loadLanguage('global.php');
	$this->loadLanguage('dashboard.php');
	$this->loadLanguage('superadmin.php');

    /****************************************************************/    
    /****************************************************************/

    $the_sanitaze = new sanitize(); // init sanitaze
	$D->idpage = '';
	if ($this->param('p')) $D->idpage = $this->param('p');
    $D->idpage = $the_sanitaze->int($D->idpage);
    if ($D->idpage <= 0) $this->globalRedirect($K->SITE_URL.'superadmin/pages');

    $info_page = $this->db2->fetch("SELECT idpage FROM pages WHERE idpage=".$D->idpage." LIMIT 1");

    if (!$info_page) $this->globalRedirect($K->SITE_URL.'superadmin/pages');

    $D->me = $this->user->info;

    $D->the_page = $this->db2->fetch("SELECT * FROM pages WHERE idpage=".$D->idpage." LIMIT 1");

    $D->idcat = $D->the_page->idcat;
    $D->idsubcat = $D->the_page->idsubcat;
    $D->verified = $D->the_page->verified;
    $D->username = stripslashes($D->the_page->puname);
    $D->title = stripslashes($D->the_page->title);
    $D->description = stripslashes($D->the_page->description);
    $D->page_idcompany = $D->the_page->idcompany;

    /****************************************************************/    
    /****************************************************************/

    $D->js_script_min = $this->designer->getStringJS('superadmin');

    $D->id_menu = 'opt_sadm_pages';
    
    $this->load_extract_controller('_load-menus');

	if ($D->isPhantom) {

        $html = '';

		if ($D->layout_size == 'min') {

            $for_load = 'min/superadmin-pages-edit.php';

		} else {

            $for_load = 'max/superadmin-pages-edit.php';

		}

        $D->titlePhantom = $this->lang('superadmin_pages_title_page').' | '.$D->title;

        $html .= $this->load_template($for_load, FALSE);
        echo $html;

	} else {

        $this->load_extract_controller('_required-dashboard');
        $this->load_extract_controller('_dashboard-bar-top');

		$D->page_title = $this->lang('superadmin_pages_title_page').' | '.$D->title;    	

        $D->file_in_template = 'max/superadmin-pages-edit.php';
        $this->load_template('dashboard-template.php');

	}

?>