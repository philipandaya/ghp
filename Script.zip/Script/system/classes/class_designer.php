<?php
class designer
{

    /*=================================================================================*/

    public function createMenuActivity($menu_items)
    {
        global $D;
        
        if (!is_array($menu_items)) return '';

        $html_block = '<div>';

        foreach ($menu_items as $item) {
            $html_block .= $this->createOptionMenuActivity($item);
        }
        
        $html_block .= '</div>';
        
        return $html_block;        
    }

    public function createOptionMenuActivity($item)
    {
        global $K;
		
		if (isset($item['status']) && $item['status'] == 'hide') $cadstatus = 'style="display:none;"';
		else $cadstatus = '';
        
        $the_option = '<div id="'.$item['id_option'].'" '.$cadstatus.'>';
        $the_option .= (isset($item['url']) && !empty($item['url'])) ? '<a href="'.$K->SITE_URL.$item['url'].'" rel="'.$item['rel'].'" target="'.$item['target'].'">' : '';
        $the_option .= '<div class="opc-menu-activity">'.$item['text_option'].'</div>';
        $the_option .= (isset($item['url']) && !empty($item['url'])) ? '</a>' : '';
        $the_option .= '</div>';

        return $the_option;
    }

    /*=================================================================================*/
    
    public function getMetaData()
    {
        global $K;
        $html = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />'."\n";
        $html .= '    <meta name="keywords" content="'.$K->SITE_TITLE.', '.$K->SEO_KEYWORDS .'">'."\n";
        $html .= '    <meta name="description" content="'.$K->SITE_TITLE.', '.$K->SEO_DESCRIPTION .'">'."\n";
        $html .= '    <meta name="author" content="'.$K->COMPANY.'">'."\n";

        return $html;
    }
    
    /*=================================================================================*/
    
    public function loadJSData()
    {
        global $K;
        
        $html = '';
        $html .= '    <script type="text/javascript"> var _SITE_URL = "'. $K->SITE_URL .'"; </script>'."\n";
        $html .= '    <script type="text/javascript"> var _STORAGE_URL = "'. $K->STORAGE_URL .'"; </script>'."\n";
        $html .= '    <script type="text/javascript"> var _THEME = "'. $K->THEME .'"; </script>'."\n";
        $files_location = $K->SITE_URL.'themes/'.$K->THEME.'/js/';
        
        foreach ($this->base_files as $f) {
            $html .= '    <script type="text/javascript" src="'.$files_location.$f.'.js?v='.$K->VERSION.'"></script>'."\n";
        }
        
        foreach ($this->base_string_js as $stringjs) {
            $html .= '    <script type="text/javascript">'.$stringjs.'</script>'."\n";
        }
    
        return $html;
    }
    
    /*=================================================================================*/
    
    public function loadCSSData()
    {
        global $K;
        
        $html = '';
        $files_location = $K->SITE_URL.'themes/'.$K->THEME.'/css/';
        
        foreach ($this->base_files as $f ) {
            $html .= '    <link href="'. $files_location . $f .'.css?v='. $K->VERSION .'" type="text/css" rel="stylesheet" media="all" />'."\n";
        }

        return $html;
    }
    
    /*=================================================================================*/
        
    public function getJSData($js_nologin = array(), $js_login = array())
    {
        global $D;
        
        if ($D->_IS_LOGGED) {
            $this->base_files = $js_login;
        } else {
            $this->base_files = $js_nologin;
        }

        if (isset($D->base_files_js) && is_array($D->base_files_js)) {
            foreach ($D->base_files_js as $onejs) {
                $this->base_files[] = $onejs;
            }
        }
        
        $this->base_string_js = array();

        if (isset($D->string_js) && is_array($D->string_js)) {
            foreach ($D->string_js as $onecadjs) {
                $this->base_string_js[] = $onecadjs;
            }
        }
        
        return $this->loadJSData();
    }
    
    /*=================================================================================*/
    
    public function getCSSData($css_nologin = array(), $css_login = array())
    {
        global $D;
        
        if ($D->_IS_LOGGED) {
            $this->base_files = $css_login;
        } else {
            $this->base_files = $css_nologin;
        }

        if (isset($D->base_files_css) && is_array($D->base_files_css)) {
            foreach ($D->base_files_css as $onecss) {
                $this->base_files[] = $onecss;
            }
        }
    
        return $this->loadCSSData();
    }
    
    /*=================================================================================*/
    
    public function boxAlert($title, $text, $txtbclose, $closebtn=TRUE)
    {
        $html = '<div id="box_alert"><div id="inside_box_alert"><div class="box_title"><div id="space_title">'.$title.'</div>';
        if ($closebtn) $html .= '<div id="space_close">X</div>';
        $html .= '<div class="clear"></div></div><div class="box_msg">'.$text.'</div><div id="box_bottom"><span id="bclose_alert">'.$txtbclose.'</span></div></div></div>';
        return $html;
    }

    /*=================================================================================*/

    public function boxConfirm($title, $text, $txtconfirm, $txtcancel, $closebtn=TRUE)
    {
        $html = '<div id="box_confirm"><div id="inside_box_confirm"><div class="box_title"><div id="space_title">'.$title.'</div>';
        if ($closebtn) $html .= '<div id="space_close">X</div>';
        $html .= '<div class="clear"></div></div><div class="box_msg">'.$text.'</div><div id="box_bottom"><span id="b_cancel">'.$txtcancel.'</span><span id="b_ok">'.$txtconfirm.'</span></div></div></div>';
        return $html;
    }
    
    /*=================================================================================*/
        
    public function getStringJS($namejs)
    {
        global $K;
        $stringJS = '<script type="text/javascript" src="'.$K->SITE_URL.'themes/'.$K->THEME.'/js/'.$namejs.'.js?v='.$K->VERSION.'"></script>'."\n";
        return $stringJS;
    }

    /*=================================================================================*/

}
?>